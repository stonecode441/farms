import javax.swing.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//switch allows a variable to be tested for quality against a list of value








        // if a statement = performs a block of code if it's condition evaluate to be true
//        int age = 75;
//        if(age>=75) {
//            System.out.println("ok Tee");
//        }
//        else if(age>=18) {
//            System.out.println("you an adult");
//        }
//        else {
//            System.out.println("you are not an adult");
        }


        //       String name = JOptionPane.showInputDialog("Enter your name");
//       JOptionPane.showMessageDialog(null,"Hello "+name);
//   simple gui
//       int age  = Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
//       JOptionPane.showMessageDialog(null,"you are "+age+" years old");
//
//        double height = Double.parseDouble(JOptionPane.showInputDialog("Enter your height"));
//        JOptionPane.showMessageDialog(null,"you are "+height+" cm tall");
//




        //expressions
        /*int friends = 10;
        friends = friends +1;
         double friends = 10;
         friends = (double) friends /3;
        friends++;
        System.out.println(friends);
         */
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("what is your name?");
//        String name = scanner.nextLine();
//        System.out.println("How old how are you?");
//        int age = scanner.nextInt();
//        scanner.nextLine();
//        System.out.println("what food do you like");
//        String food = scanner.nextLine();
//        System.out.println("what state are you from");
//        String State = scanner.nextLine();
//        System.out.println("what is your mother's name");
//        String motherName = scanner.nextLine();
//
//        System.out.println("Hello "+name);
//        System.out.println("Your are "+age+" years old");
//        System.out.println("you like "+food);
//        System.out.println("you are from "+State);
//        System.out.println("your mother's name is"+motherName);
        //int age = 23;
//        long age = 1234846736737L;
    //float age = 3.14F;
//    double age = 3.23;
//    boolean z = true;
//    char seem = '@';
//    String name = "James";

        //swap two variables;
//        String x = "water";
//        String y = "Blue";
//        String temp;
//
//        temp = x;
//        x=y;
//        y=temp;
//        System.out.println("x: "+y);
//        System.out.println("y: "+x);

    }
