package com.stargrade.fams.domain.setting.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class Setting extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String settingId;
    @OneToOne
    private User user;
    private Boolean smsNotificationEnabled;
    private Boolean emailNotificationEnabled;
    private Boolean inAppNotificationEnabled;
    private Boolean subscribedToSecurityAlert;
    private Boolean darkModeEnabled;
}
