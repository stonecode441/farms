package com.stargrade.fams.domain.usermanagement.service.impl;

import com.stargrade.fams.domain.usermanagement.model.Token;
import com.stargrade.fams.domain.usermanagement.service.TokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TokenServiceImpl implements TokenService {
    private final RedisTemplate<String, Token> redisTemplate;

    @Override
    public Token getUserToken(String userId) {
        return redisTemplate.opsForValue().get(userId);
    }

    @Override
    public void saveUserToken(String userId, Token token) {
        redisTemplate.opsForValue().set(userId, token);
    }

    @Override
    public Boolean deleteToken(String userId) {
        if(this.getUserToken(userId) != null) {
            return redisTemplate.delete(userId);
        }
        return true;
    }
}
