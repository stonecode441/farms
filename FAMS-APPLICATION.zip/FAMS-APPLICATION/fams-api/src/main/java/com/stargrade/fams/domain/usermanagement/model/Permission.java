package com.stargrade.fams.domain.usermanagement.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Permission extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String permissionId;
    @Column(unique = true, nullable = false, updatable = false)
    private String name;
    private String description;

    public Permission(String permissionId, String name, String description) {
        this.permissionId = permissionId;
        this.name = name;
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Permission permission = (Permission) o;
        return getId().equals(permission.getId()) &&
                getPermissionId().equals(permission.getPermissionId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPermissionId(), getName());
    }
}
