/**
 * Created By MisterJames
 */


package com.stargrade.fams.api.role;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class RoleDto implements Serializable {
    private String roleId;
    private String roleName;
    private Boolean isActive;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
    private String description;
}
