package com.stargrade.fams.domain.usermanagement.service.impl;

import com.cloudinary.Cloudinary;
import com.cloudinary.Transformation;
import com.stargrade.fams.api.admin.ChangeRoleRequestDto;
import com.stargrade.fams.api.building.AddOccupantsRequestDto;
import com.stargrade.fams.api.membersetting.ChangePasswordRequestDto;
import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.usermanagement.*;
import com.stargrade.fams.api.userprofile.AddProfilePhotoRequestDto;
import com.stargrade.fams.api.userprofile.UpdateProfileRequestDto;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.base.util.Validator;
import com.stargrade.fams.domain.unit.service.UnitService;
import com.stargrade.fams.domain.usermanagement.model.*;
import com.stargrade.fams.domain.usermanagement.repository.PendingUserRepository;
import com.stargrade.fams.domain.usermanagement.repository.UserRepository;
import com.stargrade.fams.domain.usermanagement.service.RoleService;
import com.stargrade.fams.domain.usermanagement.service.TokenService;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import com.stargrade.fams.api.util.UserManagementObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.email.EmailBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PendingUserRepository pendingUserRepository;
    private final JwtServiceImpl jwtService;
    private final TokenService tokenService;
    private final RoleService roleService;
    private final Cloudinary cloudinary;
    private final PasswordEncoder passwordEncoder;
    private final UserManagementObjectMapper mapper;
    private final Mailer mailer;
    private final TemplateEngine templateEngine;
    private final UnitService unitService;

    @Value("${fams.invite.expiry-in-days:10}")
    private Long inviteExpiryInDays;

    @Value("${fams.media.upload.directory:fams-upload}")
    private String uploadDir;

    @Value("${mail.smt.sendAsync:true}")
    private Boolean async;

    @Value("${mail.smt.sender:FAMS}")
    private String senderName;

    @Value("${mail.smt.senderEmail:}")
    private String senderEmail;

    @Value("${mail.smt.passwordResetSubj:FAMS - USER PASSWORD RESET}")
    private String passwordResetSubject;

    @Value("${fams.password.reset.url:}")
    private String passwordResetUrl;

    @Value("${fams.user.invite.url:}")
    private String userInviteUrl;

    @Override
    public AuthenticationDto authenticate(AuthenticationRequestDto authenticationRequest) {
        var defaultErrorMessage = "Invalid username/password";
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getEmailAddress(), authenticationRequest.getPassword()));
        if (!authentication.isAuthenticated()) {
            log.debug("Authentication failed");
            throw new UsernameNotFoundException(defaultErrorMessage);
        }

        var user = userRepository.findByEmailAddressAndIsDisabledFalseAndDeletedAtIsNull(authenticationRequest.getEmailAddress());
        if (user.isEmpty())
            throw new UsernameNotFoundException(defaultErrorMessage);

        return generateTokenForUser(user.get());
    }

    AuthenticationDto generateTokenForUser(User appUser) {
        var userDetails = new CustomUserDetails(appUser.getEmailAddress(), appUser.getPasswordHash(), new ArrayList<>());
        var jwtToken = jwtService.generateToken(appUser.getUserId(), userDetails);
        revokeExistingToken(appUser);
        saveUserToken(appUser, jwtToken);
        return new AuthenticationDto(jwtToken, jwtService.extractExpiration(jwtToken));
    }

    void revokeExistingToken(User appUser) {
        var existingToken = tokenService.getUserToken(appUser.getUserId());
        if (existingToken == null)
            return;
        var isTokenDeleted = tokenService.deleteToken(appUser.getUserId());
        log.debug("User {} token delete status: {}", appUser.getUserId(), isTokenDeleted);
    }

    void saveUserToken(User appUser, String jwtToken) {
        tokenService.saveUserToken(appUser.getUserId(), new Token(jwtToken));
    }

    @Override
    public PendingUserDto createAccount(CreateAccountRequestDto createAccountRequestDto) {
        Optional<PendingUser> pendingUser = pendingUserRepository.findByEmailAddress(createAccountRequestDto.getEmailAddress());
        if (pendingUser.isPresent())
            throw new ValidationException(String.format("A user with email address: %s already has a pending invite", createAccountRequestDto.getEmailAddress()));

        RoleDto userRole = roleService.getRole(createAccountRequestDto.getRoleId());
        if (userRole.getRoleName().equalsIgnoreCase(DefaultRole.SUPER_ADMIN.name()))
            throw new ValidationException("You do not have access rights to create a super admin account");

        var unitId = createAccountRequestDto.getUnitId();
        var leaseStart = createAccountRequestDto.getLeaseStart();
        var leaseEnd = createAccountRequestDto.getLeaseEnd();
        if(!StringUtils.isEmpty(createAccountRequestDto.getUnitId())) {
            if(leaseStart == null || leaseEnd == null)
                throw new ValidationException("To add a member to a unit, lease start and lease end is required");
            unitService.getUnitByIdFromDb(createAccountRequestDto.getUnitId());
            if(!userRole.getRoleName().equalsIgnoreCase(DefaultRole.MEMBER.name()))
                throw new ValidationException("Units cannot be attached to non member roles");
        }

        var inviteCode = CodeGenerator.generateInviteCode();
        Optional<PendingUser> existingUserWithCode = pendingUserRepository.findByInviteCode(inviteCode);

        // Ensure codes generated are always unique just in case
        while (existingUserWithCode.isPresent()) {
            inviteCode = CodeGenerator.generateInviteCode();
        }

        PendingUser userInvitation = pendingUserRepository.save(new PendingUser(
                CodeGenerator.generateUUID(),
                userRole.getRoleId(),
                unitId,
                leaseStart,
                leaseEnd,
                createAccountRequestDto.getFirstName(),
                createAccountRequestDto.getLastName(),
                createAccountRequestDto.getEmailAddress(),
                inviteCode,
                LocalDate.now().plusDays(inviteExpiryInDays)
        ));

        this.sendUserInviteNotification(userInvitation, inviteCode);
        return mapper.toPendingUserDto(userInvitation);
    }

    @Override
    public PendingUserDto getInvitedUser(String inviteCode) {
        Optional<PendingUser> existingUserWithCode = pendingUserRepository.findByInviteCode(inviteCode);
        if (existingUserWithCode.isEmpty())
            throw new ValidationException(String.format("No user found with code: %s", inviteCode));
        PendingUser invitedUser = existingUserWithCode.get();
        if (LocalDate.now().isAfter(invitedUser.getCodeExpiryDate()))
            throw new ValidationException(String.format("Invite code expired for: %s", invitedUser.getEmailAddress()));
        return mapper.toPendingUserDto(invitedUser);
    }

    @Override
    public User getUserFromSession() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return getUserByEmailFromDb(authentication.getName());
    }

    User getUserByEmailFromDb(String emailAddress) {
        Optional<User> appUser = userRepository.findByEmailAddressAndIsDisabledFalseAndDeletedAtIsNull(emailAddress);
        if (appUser.isEmpty())
            throw new ValidationException(String.format("User with email address: %s not found", emailAddress));
        return appUser.get();
    }

    @Override
    public User getUserByIdFromDb(String userId) {
        Optional<User> user = userRepository.findByUserId(userId);
        if (user.isEmpty())
            throw new ValidationException(String.format("No user found with ID: %s", userId));
        return user.get();
    }

    @Override
    public UserDto getSignedInUser() {
        return mapper.toUserDto(getUserFromSession());
    }

    @Override
    public List<UserDto> getAllUsersByRole(String roleId, Integer pageNumber, Integer pageSize) {
        Role role = roleService.getDbRole(roleId);
        return userRepository.findAllByRoleAndDeletedAtIsNull(role, PageRequest.of(pageNumber, pageSize))
                .stream()
                .map(mapper::toUserDto)
                .collect(Collectors.toList());
    }

    @Override
    public UserDto getUser(String userId) {
        Optional<User> user = userRepository.findByUserId(userId);
        if (user.isEmpty())
            throw new ValidationException(String.format("No user found with ID: %s", userId));
        return mapper.toUserDto(user.get());
    }

    @Override
    public UserDto activateAccount(ActivateAccountRequestDto activateAccountRequestDto) throws FamsApplicationException {
        PendingUserDto invitedUser = this.getInvitedUser(activateAccountRequestDto.getInviteCode());

        if (!Validator.isPhoneNumberValid(activateAccountRequestDto.getPhoneNumber()))
            throw new ValidationException(String.format("Invalid phone number provided: %s", activateAccountRequestDto.getPhoneNumber()));

        if (!activateAccountRequestDto.getPassword().equals(activateAccountRequestDto.getConfirmPassword()))
            throw new ValidationException("Passwords do not match");

        Role role = roleService.getDbRole(invitedUser.getRoleId());
        User user = new User(CodeGenerator.generateUUID(), role, invitedUser.getFirstName(), invitedUser.getLastName(), activateAccountRequestDto.getDob(), invitedUser.getEmailAddress());
        user.setPhoneNumber(activateAccountRequestDto.getPhoneNumber());
        user.setPasswordHash(passwordEncoder.encode(activateAccountRequestDto.getPassword()));
        User createdUser = userRepository.save(user);
        try {
            if (activateAccountRequestDto.getBase64ProfilePhoto() != null)
                this.uploadUserImage(activateAccountRequestDto.getBase64ProfilePhoto(), createdUser);
        } catch (IOException fae) {
            throw new FamsApplicationException("Account activated successfully but image upload failed", fae);
        }
        pendingUserRepository.deleteByInviteCode(activateAccountRequestDto.getInviteCode());

        if(!StringUtils.isEmpty(invitedUser.getUnitId())) {
            AddOccupantsRequestDto addOccupantsRequestDto = new AddOccupantsRequestDto();
            addOccupantsRequestDto.setUnitId(invitedUser.getUnitId());
            addOccupantsRequestDto.setLeaseStart(invitedUser.getLeaseStart());
            addOccupantsRequestDto.setLeaseEnd(invitedUser.getLeaseEnd());
            addOccupantsRequestDto.setMembersIds(List.of(invitedUser.getUserId()));
            addOccupantsRequestDto.setPrimaryMemberId(invitedUser.getUserId());
            unitService.addOccupantsToUnit(invitedUser.getUnitId(), addOccupantsRequestDto);
        }
        return mapper.toUserDto(createdUser);
    }

    @Override
    public UserDto createUserInternal(
            String roleId, String firstName,
            String lastName, String emailAddress,
            String password, String confirmPassword) {
        if (!password.equals(confirmPassword))
            throw new ValidationException("Passwords do not match");

        Role role = roleService.getDbRole(roleId);
        User user = new User(CodeGenerator.generateUUID(), role, firstName, lastName, null, emailAddress);
        user.setPasswordHash(passwordEncoder.encode(password));
        return mapper.toUserDto(userRepository.save(user));
    }

    void uploadUserImage(String base64Image, User user) throws IOException {
        Map<String, Object> params = new HashMap<>();
        Map result;
        Objects.requireNonNull(base64Image, "To upload profile photo, a base 64 image is required");
        params.put("public_id", String.format("%s/profile/%s", uploadDir, user.getUserId()));
        params.put("transformation", new Transformation<>().width(200).height(200).crop("limit"));
        if (user.getProfilePhotoUrl() != null) params.put("overwrite", "true");
        result = cloudinary.uploader().upload(base64Image, params);
        user.setProfilePhotoFormat(result.get("format").toString());
        user.setProfilePhotoUrl(result.get("url").toString());
        userRepository.save(user);
    }

    @Override
    public boolean forgotPassword(ForgotPasswordRequestDto forgotPasswordRequest) {
        User appUser = this.getUserByEmailFromDb(forgotPasswordRequest.getEmailAddress());
        final String authToken = generateTokenForUser(appUser).getAuthToken();
        this.sendPasswordResetNotification(appUser, authToken);
        return true;
    }

    @Override
    public UserDto resetPassword(PasswordResetRequestDto passwordResetRequest) {
        if (!passwordResetRequest.getNewPassword().equals(passwordResetRequest.getConfirmNewPassword()))
            throw new ValidationException("Passwords entered do not match");
        User appUser = this.getUserFromSession();
        appUser.setPasswordHash(passwordEncoder.encode(passwordResetRequest.getConfirmNewPassword()));
        return mapper.toUserDto(userRepository.save(appUser));
    }

    void sendPasswordResetNotification(User customer, String userToken) {
        Context context = new Context();
        String url;
        if (passwordResetUrl.endsWith("/"))
            url = passwordResetUrl.substring(0, passwordResetUrl.length() - 1);
        else
            url = passwordResetUrl;
        context.setVariable("user", customer);
        context.setVariable("resetUrl", String.format("%s?at=%s", url, userToken));// TODO, this should be shortened/masked
        String content = templateEngine.process("password_reset_template", context);
        Email email = EmailBuilder.startingBlank()
                .from(senderName, senderEmail)
                .to(String.format("%s %s", customer.getFirstName(), customer.getLastName()), customer.getEmailAddress())
                .withSubject(passwordResetSubject)
                .withHTMLText(content).buildEmail();
        mailer.sendMail(email, async);
    }

    void sendUserInviteNotification(PendingUser customer, String inviteCode) {
        Context context = new Context();
        context.setVariable("user", customer);
        context.setVariable("inviteUrl", userInviteUrl);
        context.setVariable("inviteCode", inviteCode);
        String content = templateEngine.process("user_invite_template", context);
        Email email = EmailBuilder.startingBlank()
                .from(senderName, senderEmail)
                .to(String.format("%s %s", customer.getFirstName(), customer.getLastName()), customer.getEmailAddress())
                .withSubject(passwordResetSubject)
                .withHTMLText(content).buildEmail();
        mailer.sendMail(email, async);
    }

    @Override
    public UserDto updateProfile(UpdateProfileRequestDto updateProfileRequest) {
        User appUser = this.getUserFromSession();
        if (!StringUtils.isEmpty(updateProfileRequest.getPhoneNumber()))
            appUser.setPhoneNumber(updateProfileRequest.getPhoneNumber());
        if (updateProfileRequest.getDob() != null)
            appUser.setDob(updateProfileRequest.getDob());
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto addProfilePhoto(AddProfilePhotoRequestDto addProfilePhotoRequest) throws FamsApplicationException {
        User appUser = this.getUserFromSession();
        try {
            this.uploadUserImage(addProfilePhotoRequest.getBase64Image(), appUser);
        } catch (IOException fae) {
            throw new FamsApplicationException("Failed to add profile photo", fae);
        }
        return this.getSignedInUser();
    }

    @Override
    public UserDto removeProfilePhoto() {
        User appUser = this.getUserFromSession();
        appUser.setProfilePhotoUrl(null);
        appUser.setProfilePhotoFormat(null);
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto deactivateAccount(String userId) {
        User currentUser = this.getUserFromSession();
        if(currentUser.getUserId().equals(userId))
            throw new ValidationException("You cannot deactivate your own account");
        User appUser = this.getUserByIdFromDb(userId);
        appUser.setIsDisabled(true);
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto activateAccount(String userId) {
        User currentUser = this.getUserFromSession();
        if(currentUser.getUserId().equals(userId))
            throw new ValidationException("You cannot activate your own account");
        User appUser = this.getUserByIdFromDb(userId);
        appUser.setIsDisabled(false);
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto deleteAccount(String userId) {
        User currentUser = this.getUserFromSession();
        if(currentUser.getUserId().equals(userId))
            throw new ValidationException("You cannot delete your own account");
        User appUser = this.getUserByIdFromDb(userId);
        appUser.setDeletedAt(new Date());
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto changeRole(String userId, ChangeRoleRequestDto changeRoleRequest) {
        User currentUser = this.getUserFromSession();
        if(currentUser.getUserId().equals(userId))
            throw new ValidationException("You cannot change the role of your own account");
        User appUser = this.getUserByIdFromDb(userId);
        Role role = roleService.getDbRole(changeRoleRequest.getNewRole());
        appUser.setRole(role);
        return mapper.toUserDto(userRepository.save(appUser));
    }

    @Override
    public UserDto changePassword(ChangePasswordRequestDto changePasswordRequest) {
        if (!changePasswordRequest.getNewPassword().equals(changePasswordRequest.getConfirmNewPassword()))
            throw new ValidationException("Passwords entered do not match");

        User appUser = this.getUserFromSession();
        if(!passwordEncoder.matches(changePasswordRequest.getCurrentPassword(), appUser.getPasswordHash()))
            throw new ValidationException("Current password provided is incorrect");

        appUser.setPasswordHash(passwordEncoder.encode(changePasswordRequest.getConfirmNewPassword()));
        User updatedUser = userRepository.save(appUser);

        UserDto finalResponse = mapper.toUserDto(updatedUser);
        revokeExistingToken(updatedUser);
        return finalResponse;
    }
}