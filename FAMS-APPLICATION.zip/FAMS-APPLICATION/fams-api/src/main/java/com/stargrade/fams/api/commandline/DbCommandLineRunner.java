package com.stargrade.fams.api.commandline;

import com.stargrade.fams.api.permission.PermissionRequestDto;
import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.role.RoleRequestDto;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.usermanagement.model.DefaultRole;
import com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission;
import com.stargrade.fams.domain.usermanagement.model.Permission;
import com.stargrade.fams.domain.usermanagement.repository.PermissionRepository;
import com.stargrade.fams.domain.usermanagement.service.PermissionService;
import com.stargrade.fams.domain.usermanagement.service.RoleService;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class DbCommandLineRunner implements CommandLineRunner {
    private final RoleService roleService;
    private final PermissionService permissionService;
    private final PermissionRepository permissionRepository;
    private final UserService userService;

    @Override
    public void run(String... args) {
        if(roleService.getRowsCount() == 0) {
            log.info("DB command line runner has started it's operation");
            RoleRequestDto roleRequestDto = new RoleRequestDto();
            roleRequestDto.setRoleName(DefaultRole.SUPER_ADMIN.name());
            roleRequestDto.setDescription("Super user of the application");
            RoleDto roleDto = roleService.createRole(roleRequestDto);

            List<String> permissionIds = new ArrayList<>();
            for(MethodAccessPermission methodAccessPermission : MethodAccessPermission.values()) {
                Permission permission = permissionRepository.save(new Permission(CodeGenerator.generateUUID(), methodAccessPermission.name(), methodAccessPermission.getValue()));
                permissionIds.add(permission.getPermissionId());
            }

            PermissionRequestDto permissionRequestDto = new PermissionRequestDto();
            permissionRequestDto.setRoleId(roleDto.getRoleId());
            permissionRequestDto.setPermissionIds(permissionIds);
            permissionService.manageRolePermissions(permissionRequestDto, false);

            userService.createUserInternal(roleDto.getRoleId(), "Internal", "User", "superadmin@fams.com", "Password@123", "Password@123");
            log.info("DB command line runner has completed it's operation");
        }
    }
}
