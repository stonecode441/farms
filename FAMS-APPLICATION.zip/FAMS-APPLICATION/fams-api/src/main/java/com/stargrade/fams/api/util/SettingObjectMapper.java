package com.stargrade.fams.api.util;

import com.stargrade.fams.api.membersetting.MemberSettingDto;
import com.stargrade.fams.domain.setting.model.Setting;
import org.springframework.stereotype.Component;

@Component
public class SettingObjectMapper {
    public MemberSettingDto toMemberSettingDto(Setting setting){
        MemberSettingDto memberSettingDto = new MemberSettingDto();
        memberSettingDto.setMemberId(setting.getSettingId());
        memberSettingDto.setSmsNotificationEnabled(setting.getSmsNotificationEnabled());
        memberSettingDto.setEmailNotificationEnabled(setting.getEmailNotificationEnabled());
        memberSettingDto.setInAppNotificationEnabled(setting.getInAppNotificationEnabled());
        memberSettingDto.setSubscribedToSecurityAlert(setting.getSubscribedToSecurityAlert());
        memberSettingDto.setUpdatedAt(setting.getUpdatedAt());
        memberSettingDto.setCreatedAt(setting.getCreatedAt());
        memberSettingDto.setDarkModeEnabled(setting.getDarkModeEnabled());
        memberSettingDto.setDeletedAt(setting.getDeletedAt());

        return memberSettingDto;
    }
}
