package com.stargrade.fams.domain.unit.model;

import com.stargrade.fams.api.unit.UnitType;
import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Unit extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String unitId;
    private String unitNo;
    @Enumerated(value = EnumType.STRING)
    private UnitType unitType;
    private Integer unitSize;
    private Integer maxOccupants;
    private Integer rent;
    private LocalDate leaseStart;
    private LocalDate leaseEnd;
    private String primaryMemberFirstName;
    private String primaryMemberLastName;
    private String primaryMemberEmail;

    public Unit(String unitId, String unitNo, UnitType unitType, Integer unitSize, Integer maxOccupants, Integer rent) {
        this.unitId = unitId;
        this.unitNo = unitNo;
        this.unitType = unitType;
        this.unitSize = unitSize;
        this.maxOccupants = maxOccupants;
        this.rent = rent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Unit unit = (Unit) o;
        return getId().equals(unit.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUnitId());
    }
}
