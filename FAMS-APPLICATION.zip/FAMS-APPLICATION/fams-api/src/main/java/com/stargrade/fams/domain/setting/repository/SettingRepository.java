package com.stargrade.fams.domain.setting.repository;

import com.stargrade.fams.domain.setting.model.Setting;
import com.stargrade.fams.domain.usermanagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SettingRepository extends JpaRepository<Setting,Long> {
    Optional<Setting> findByUser(User user);
}
