package com.stargrade.fams.domain.contact.service;

import com.stargrade.fams.api.organization.ContactDto;
import com.stargrade.fams.domain.contact.model.Contact;

public interface ContactService {
    Contact createContact(ContactDto contactDto);
}
