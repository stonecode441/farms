package com.stargrade.fams.domain.invite.service.impl;

import com.stargrade.fams.api.invite.*;
import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.invite.model.Guest;
import com.stargrade.fams.domain.invite.model.Invite;
import com.stargrade.fams.domain.invite.model.InviteGuest;
import com.stargrade.fams.domain.invite.repository.GuestRepository;
import com.stargrade.fams.domain.invite.repository.InviteGuestRepository;
import com.stargrade.fams.domain.invite.repository.InviteRepository;
import com.stargrade.fams.domain.invite.service.InviteService;
import com.stargrade.fams.api.util.InviteObjectMapper;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitOccupant;
import com.stargrade.fams.domain.unit.service.UnitService;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InviteServiceImpl implements InviteService {
    private final InviteObjectMapper mapper;
    private final RedisTemplate<String, InviteCodeDto> redisTemplate;
    private final UserService userService;
    private final InviteRepository inviteRepository;
    private final GuestRepository guestRepository;
    private final InviteGuestRepository inviteGuestRepository;
    private final UnitService unitService;

    @Value("${invite.code.expiry.secs:300}")
    private Integer inviteCodeExpiryInSecs;

    InviteCodeDto getInviteCode(String userId) {
        return redisTemplate.opsForValue().get(userId);
    }

    void saveInviteCode(String userId, InviteCodeDto data) {
        redisTemplate.opsForValue().set(userId, data, Duration.ofSeconds(inviteCodeExpiryInSecs));
    }

    @Override
    public InviteCodeDto generateInviteCode() {
        UserDto signedInUser = userService.getSignedInUser();
        var code = String.format("FGUS-%s", CodeGenerator.generateCode(12));
        LocalDateTime expiry = LocalDateTime.now().plusSeconds(inviteCodeExpiryInSecs);
        InviteCodeDto generatedInvite = mapper.toInviteCodeDto(code, expiry);
        saveInviteCode(signedInUser.getUserId(), generatedInvite);
        return generatedInvite;
    }

    Guest getGuest(String phoneNumber) {
        Optional<Guest> guest = guestRepository.findByPhoneNo(phoneNumber);
        if (guest.isEmpty())
            throw new ValidationException(String.format("Guest with phone number: %s does not exist", phoneNumber));
        return guest.get();
    }

    Guest getGuestById(String id) {
        Optional<Guest> guest = guestRepository.findByGuestId(id);
        if (guest.isEmpty())
            throw new ValidationException(String.format("Guest with ID: %s does not exist", id));
        return guest.get();
    }

    @Override
    public InviteDto createInvite(InviteRequestDto inviteRequestDto) {
        User inviter = userService.getUserFromSession();

        if (inviteRequestDto.getAccessStartDate().isAfter(inviteRequestDto.getAccessEndDate()))
            throw new ValidationException("Invalid access date");

        List<UnitOccupant> occupantUnits = unitService.getOccupantUnits(inviter);
        if (occupantUnits == null || occupantUnits.isEmpty())
            throw new ValidationException("Occupant not assigned to a valid unit");
        List<UnitOccupant> selectedOccupantUnit = occupantUnits
                .stream()
                .filter(ou -> ou.getUnit().getUnitId().equals(inviteRequestDto.getUnitId()))
                .collect(Collectors.toList());
        if (selectedOccupantUnit.isEmpty())
            throw new ValidationException("Occupant not attached to specified unit");
        Unit occupantUnit = selectedOccupantUnit.get(0).getUnit();

        InviteCodeDto inviteCodeDto = getInviteCode(inviter.getUserId());
        if (LocalDateTime.now().isBefore(inviteCodeDto.getExpiresIn())) {
            // Code has not expired...
            var generatedCode = inviteCodeDto.getCode();
            if (inviteRepository.findByInviteCode(generatedCode).isPresent())
                throw new ValidationException("Code is tied to an existing invite");
            List<InvitedGuest> invitedGuests = inviteRequestDto.getInvitedGuest();
            Invite createdInvite = inviteRepository.save(new Invite(
                    CodeGenerator.generateUUID(),
                    occupantUnit,
                    inviter,
                    generatedCode,
                    invitedGuests.size() == 1,
                    inviteRequestDto.getAccessStartDate(),
                    inviteRequestDto.getAccessEndDate(),
                    inviteRequestDto.getInviteFrequency()
            ));

            List<Guest> unsavedGuests = new ArrayList<>();
            List<InviteGuest> unsavedInviteGuests = new ArrayList<>();
            invitedGuests.forEach(invitedGuest -> {
                try {
                    Guest guest = getGuest(invitedGuest.getPhoneNo());
                    unsavedInviteGuests.add(new InviteGuest(createdInvite, guest));
                } catch (ValidationException ignored) {
                    Guest guest = new Guest(
                            CodeGenerator.generateUUID(),
                            createdInvite,
                            invitedGuest.getFirstName(),
                            invitedGuest.getLastName(),
                            invitedGuest.getGender(),
                            invitedGuest.getPhoneNo(),
                            invitedGuest.getIsDissallowed()
                    );
                    unsavedGuests.add(guest);
                    unsavedInviteGuests.add(new InviteGuest(createdInvite, guest));
                }
            });
            guestRepository.saveAll(unsavedGuests);
            inviteGuestRepository.saveAll(unsavedInviteGuests);
            return mapper.toInviteDto(
                    createdInvite,
                    occupantUnit.getUnitNo(),
                    unsavedInviteGuests
                            .stream()
                            .map(r -> mapper.toInvitedGuest(
                                    r.getGuest(),
                                    r.getCheckedIn(),
                                    r.getCheckedOut()
                            ))
                            .collect(Collectors.toList())
            );
        }
        throw new ValidationException("Invalid/expired invite code");
    }

    Invite getInvite(String inviteId) {
        Optional<Invite> invite = inviteRepository.findByInviteIdAndDeletedAtIsNull(inviteId);
        if (invite.isEmpty())
            throw new ValidationException(String.format("Invite with id: %s does not exist", inviteId));
        return invite.get();
    }

    @Override
    public InviteDto updateInvite(String inviteId, UpdateInviteRequestDto updateInviteRequestDto) {
        User inviter = userService.getUserFromSession();

        Invite invite = getInvite(inviteId);

        if (!StringUtils.isEmpty(updateInviteRequestDto.getUnitId())) {
            List<UnitOccupant> occupantUnits = unitService.getOccupantUnits(inviter);
            if (occupantUnits == null || occupantUnits.isEmpty())
                throw new ValidationException("Occupant not assigned to a valid unit");
            List<UnitOccupant> selectedOccupantUnit = occupantUnits
                    .stream()
                    .filter(ou -> ou.getUnit().getUnitId().equals(updateInviteRequestDto.getUnitId()))
                    .collect(Collectors.toList());
            if (selectedOccupantUnit.isEmpty())
                throw new ValidationException("Occupant not attached to specified unit");
            invite.setUnit(selectedOccupantUnit.get(0).getUnit());
        }

        if (!StringUtils.isEmpty(updateInviteRequestDto.getInviteCode())) {
            InviteCodeDto inviteCodeDto = getInviteCode(inviter.getUserId());
            if (LocalDateTime.now().isBefore(inviteCodeDto.getExpiresIn())) {
                // Code has not expired...
                var generatedCode = inviteCodeDto.getCode();
                if (inviteRepository.findByInviteCode(generatedCode).isPresent())
                    throw new ValidationException("Code is tied to an existing invite");
                invite.setInviteCode(generatedCode);
            }
            throw new ValidationException("Invalid/expired invite code");
        }

        List<InviteGuest> inviteGuests = new ArrayList<>();
        if (updateInviteRequestDto.getInvitedGuest() != null && !updateInviteRequestDto.getInvitedGuest().isEmpty()) {
            List<InvitedGuest> invitedGuests = updateInviteRequestDto.getInvitedGuest();
            List<Guest> unsavedGuests = new ArrayList<>();
            inviteGuestRepository.deleteAllByInviteId(invite.getId());// Remove previous guests
            invitedGuests.forEach(invitedGuest -> {
                try {
                    Guest guest = getGuest(invitedGuest.getPhoneNo());
                    inviteGuests.add(new InviteGuest(invite, guest));
                } catch (ValidationException ignored) {
                    Guest guest = new Guest(
                            CodeGenerator.generateUUID(),
                            invite,
                            invitedGuest.getFirstName(),
                            invitedGuest.getLastName(),
                            invitedGuest.getGender(),
                            invitedGuest.getPhoneNo(),
                            invitedGuest.getIsDissallowed()
                    );
                    unsavedGuests.add(guest);
                    inviteGuests.add(new InviteGuest(invite, guest));
                }
            });
            guestRepository.saveAll(unsavedGuests);
            inviteGuestRepository.saveAll(inviteGuests);
            if (invitedGuests.size() > 1)
                invite.setIsAlone(false);
        } else {
            inviteGuests.addAll(inviteGuestRepository.findAllByInvite(invite));
        }

        if (updateInviteRequestDto.getAccessStartDate() != null) {
            invite.setAccessStartDate(updateInviteRequestDto.getAccessStartDate());
            if (invite.getAccessStartDate().isAfter(invite.getAccessEndDate()))
                throw new ValidationException("Invalid access date");
        }

        if (updateInviteRequestDto.getAccessEndDate() != null) {
            invite.setAccessEndDate(updateInviteRequestDto.getAccessEndDate());
            if (invite.getAccessStartDate().isAfter(invite.getAccessEndDate()))
                throw new ValidationException("Invalid access date");
        }

        if (updateInviteRequestDto.getInviteFrequency() != null)
            invite.setInviteFrequency(updateInviteRequestDto.getInviteFrequency());

        return mapper.toInviteDto(
                inviteRepository.save(invite),
                invite.getUnit().getUnitNo(),
                inviteGuests
                        .stream()
                        .map(r -> mapper.toInvitedGuest(
                                r.getGuest(),
                                r.getCheckedIn(),
                                r.getCheckedOut()
                        ))
                        .collect(Collectors.toList())
        );
    }

    @Override
    public InviteDto getAnInvite(String inviteId) {
        Invite invite = getInvite(inviteId);
        return mapper.toInviteDto(
                invite,
                invite.getUnit().getUnitNo(),
                inviteGuestRepository.findAllByInvite(invite)
                        .stream()
                        .map(r -> mapper.toInvitedGuest(
                                r.getGuest(),
                                r.getCheckedIn(),
                                r.getCheckedOut())
                        )
                        .collect(Collectors.toList())
        );
    }

    @Override
    public List<InviteDto> getAllInvites(Integer pageNo, Integer pageSize) {
        return inviteRepository.findAllByDeletedAtIsNull(PageRequest.of(pageNo, pageSize))
                .stream()
                .map(invite -> mapper.toInviteDto(
                        invite,
                        invite.getUnit().getUnitNo(),
                        inviteGuestRepository.findAllByInvite(invite)
                                .stream()
                                .map(r -> mapper.toInvitedGuest(
                                        r.getGuest(),
                                        r.getCheckedIn(),
                                        r.getCheckedOut()
                                ))
                                .collect(Collectors.toList())
                ))
                .collect(Collectors.toList());
    }

    @Override
    public InviteDto cancelInvite(String inviteId) {
        Invite invite = getInvite(inviteId);
        invite.setDeletedAt(new Date());
        Invite updatedInvite = inviteRepository.save(invite);
        return mapper.toInviteDto(updatedInvite, invite.getUnit().getUnitNo(), null);
    }

    @Override
    public InviteDto checkIn(String inviteId, String guestId) {
        Invite invite = getInvite(inviteId);
        Guest guest = getGuestById(guestId);
        if(LocalDate.now().isAfter(invite.getAccessEndDate()))
            throw new ValidationException("Invite access has expired");
        Optional<InviteGuest> inviteGuestOptional = inviteGuestRepository.findByInviteAndGuest(invite, guest);
        if(inviteGuestOptional.isEmpty())
            throw new ValidationException("Failed to retrieve guest invite");
        InviteGuest inviteGuest = inviteGuestOptional.get();
        inviteGuest.setCheckedIn(new Date());
        inviteGuestRepository.save(inviteGuest);
        return mapper.toInviteDto(
                invite,
                invite.getUnit().getUnitNo(),
                inviteGuestRepository.findAllByInvite(invite)
                        .stream()
                        .map(r -> mapper.toInvitedGuest(
                                r.getGuest(),
                                r.getCheckedIn(),
                                r.getCheckedOut()
                        ))
                        .collect(Collectors.toList())
        );
    }

    @Override
    public InviteDto checkOut(String inviteId, String guestId) {
        Invite invite = getInvite(inviteId);
        Guest guest = getGuestById(guestId);
        Optional<InviteGuest> inviteGuestOptional = inviteGuestRepository.findByInviteAndGuest(invite, guest);
        if(inviteGuestOptional.isEmpty())
            throw new ValidationException("Failed to retrieve guest invite");
        InviteGuest inviteGuest = inviteGuestOptional.get();
        inviteGuest.setCheckedOut(new Date());
        inviteGuestRepository.save(inviteGuest);
        return mapper.toInviteDto(
                invite,
                invite.getUnit().getUnitNo(),
                inviteGuestRepository.findAllByInvite(invite)
                        .stream()
                        .map(r -> mapper.toInvitedGuest(
                                r.getGuest(),
                                r.getCheckedIn(),
                                r.getCheckedOut()
                        ))
                        .collect(Collectors.toList())
        );
    }
}
