package com.stargrade.fams.domain.usermanagement.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Objects;

@Table(name = "app_user")
@Entity
@Getter
@Setter
@NoArgsConstructor
public class User extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String userId;
    @ManyToOne
    private Role role;
    private String firstName;
    private String lastName;
    private LocalDate dob;
    @Column(unique = true, nullable = false, updatable = false)
    private String emailAddress;
    private String passwordHash;
    private String phoneNumber;
    private String profilePhotoUrl;
    private String profilePhotoFormat;
    private Boolean isDisabled;

    public User(String userId, Role role, String firstName, String lastName, LocalDate dob, String emailAddress) {
        this.userId = userId;
        this.role = role;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.emailAddress = emailAddress;
        this.isDisabled = false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return getId().equals(user.getId()) &&
                getUserId().equals(user.getUserId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUserId(), getEmailAddress());
    }
}
