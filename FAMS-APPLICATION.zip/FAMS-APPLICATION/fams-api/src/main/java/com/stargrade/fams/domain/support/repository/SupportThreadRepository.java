package com.stargrade.fams.domain.support.repository;

import com.stargrade.fams.domain.support.model.Support;
import com.stargrade.fams.domain.support.model.SupportThread;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SupportThreadRepository extends JpaRepository<SupportThread,Long> {
    List<SupportThread> findAllBySupport(Support support);

    Optional<SupportThread> findByThreadId(String threadId);
}
