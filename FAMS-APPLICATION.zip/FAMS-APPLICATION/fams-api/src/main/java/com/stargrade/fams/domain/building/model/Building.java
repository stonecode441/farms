package com.stargrade.fams.domain.building.model;

import com.stargrade.fams.api.building.BuildingType;
import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.property.model.Property;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Building extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String buildingId;
    @ManyToOne
    private Property property;
    private String name;
    private Integer buildingSize;
    private Integer noOfFloors;
    @Enumerated(value = EnumType.STRING)
    private BuildingType buildingType;

    public Building(String buildingId, Property property, String name, Integer buildingSize, Integer noOfFloors, BuildingType buildingType) {
        this.buildingId = buildingId;
        this.property = property;
        this.name = name;
        this.buildingSize = buildingSize;
        this.noOfFloors = noOfFloors;
        this.buildingType = buildingType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Building building = (Building) o;
        return getId().equals(building.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getBuildingId(), getProperty().getPropertyId());
    }
}
