package com.stargrade.fams.domain.invite.model;

import com.stargrade.fams.api.invite.InviteFrequency;
import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Invite extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String inviteId;
    @ManyToOne
    private User inviter;
    @Column(unique = true)
    private String inviteCode;
    private Boolean isAlone;
    private LocalDate accessStartDate;
    private LocalDate accessEndDate;
    @Enumerated(value = EnumType.STRING)
    private InviteFrequency inviteFrequency;
    @ManyToOne
    private Unit unit;

    public Invite(String inviteId, Unit unit, User inviter, String inviteCode, Boolean isAlone, LocalDate accessStartDate, LocalDate accessEndDate, InviteFrequency inviteFrequency) {
        this.inviteId = inviteId;
        this.unit = unit;
        this.inviter = inviter;
        this.inviteCode = inviteCode;
        this.isAlone = isAlone;
        this.accessStartDate = accessStartDate;
        this.accessEndDate = accessEndDate;
        this.inviteFrequency = inviteFrequency;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Invite obj = (Invite) o;
        return getId().equals(obj.getId()) &&
                getInviteId().equals(obj.getInviteId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getInviteId(), getInviteCode());
    }
}
