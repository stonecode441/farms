package com.stargrade.fams.api.membersetting;

import lombok.Data;

import java.io.Serializable;

@Data
public class UpdateNotificationRequestDto implements Serializable {
    private Boolean smsNotificationEnabled;
    private Boolean emailNotificationEnabled;
    private Boolean inAppNotificationEnabled;
}
