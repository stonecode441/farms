package com.stargrade.fams.api.usermanagement;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

@Data
public class PendingUserDto implements Serializable {
    private String userId;
    private String roleId;
    private String unitId;
    private LocalDate leaseStart;
    private LocalDate leaseEnd;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String inviteCode;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
