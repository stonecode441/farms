package com.stargrade.fams.api.subscription;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.api.util.MockHelper;
import com.stargrade.fams.domain.subscription.service.SubscriptionService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/subscription")
@RestController
@RequiredArgsConstructor
public class SubscriptionController {
    private final SubscriptionService subscriptionService;

    @Operation(summary = "Create subscription")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> createSubscription(@Valid @RequestBody CreateSubscriptionRequestDto createSubscriptionRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription created successfully", subscriptionService.createSubscription(createSubscriptionRequest)));
    }

    @Operation(summary = "Get all subscriptions")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).GET_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<List<SubscriptionDto>>> getAllSubscriptions() {
        return ResponseEntity.ok(new ApiResponse<>("Subscriptions retrieved successfully", subscriptionService.getAllSubscriptions()));
    }

    @Operation(summary = "Get subscription")
    @GetMapping("/{subscriptionId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).GET_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> getSubscription(@PathVariable String subscriptionId) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription retrieved successfully", subscriptionService.getSubscription(subscriptionId)));
    }

    @Operation(summary = "Delete subscription")
    @DeleteMapping("/{subscriptionId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> deleteSubscription(@PathVariable String subscriptionId) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription deleted successfully", subscriptionService.deleteSubscription(subscriptionId)));
    }

    @Operation(summary = "Upgrade subscription")
    @PostMapping("/upgrade")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> upgradeSubscription(@Valid @RequestBody SubscriptionRequestDto upgradeExistingSubscriptionRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription upgraded successfully", subscriptionService.modifySubscription(upgradeExistingSubscriptionRequest)));
    }

    @Operation(summary = "Downgrade subscription")
    @PostMapping("/downgrade")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> downgradeSubscription(@Valid @RequestBody SubscriptionRequestDto downgradeExistingSubscriptionRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription downgraded successfully", subscriptionService.modifySubscription(downgradeExistingSubscriptionRequest)));
    }

    @Operation(summary = "Activate subscription")
    @PostMapping("/activate")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> activateSubscription(@Valid @RequestBody SubscriptionRequestDto activateSubscriptionRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription activated successfully", subscriptionService.activateSubscription(activateSubscriptionRequest)));
    }

    @Operation(summary = "Cancel subscription")
    @PostMapping("/cancel")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CANCEL_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> cancelSubscription(@Valid @RequestBody CancelSubscriptionRequestDto cancelSubscriptionRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription canceled successfully", subscriptionService.cancelSubscription(cancelSubscriptionRequest)));
    }

    @Operation(summary = "Re-activate subscription")
    @PostMapping("re-activate")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_SUBSCRIPTION)")
    public ResponseEntity<ApiResponse<SubscriptionDto>> reactivateSubscription(@Valid @RequestBody SubscriptionRequestDto reactivatSubscriptionRequestDto) {
        return ResponseEntity.ok(new ApiResponse<>("Subscription reactivated successfully", subscriptionService.activateSubscription(reactivatSubscriptionRequestDto)));
    }
}
