package com.stargrade.fams.api.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse<T> implements Serializable {
    private ResponseCode responseCode;
    private String message;
    private Boolean success;
    private T data;

    public ApiResponse(String message, T data) {
        this.responseCode = ResponseCode.SUCCESS;
        this.message = message;
        this.data = data;
        this.success = true;
    }

    public void withErrorMessage(String message) {
        this.responseCode = ResponseCode.FAILURE;
        this.message = message;
        this.success = false;
    }
}
