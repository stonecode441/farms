package com.stargrade.fams.api.property;

import com.stargrade.fams.api.organization.AddressDto;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;

@Data
public class PropertyRequestDto implements Serializable {
    @NotEmpty(message = "Property name is required")
    private String name;

    @NotNull(message = "Address is required")
    private AddressDto address;

    @NotNull(message = "Property Type is required")
    private PropertyType propertyType;

    private String imageName;

    private String base64Image;
}
