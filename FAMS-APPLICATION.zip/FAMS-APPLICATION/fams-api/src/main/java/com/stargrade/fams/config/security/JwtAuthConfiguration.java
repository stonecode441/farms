package com.stargrade.fams.config.security;

import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
@ConfigurationProperties(prefix = "fams.security.jwt")
public class JwtAuthConfiguration {
    private String secretKey = "234538792G567F4428461E4E6250675768126D597765643698127A2443111234";
    private Long expiration = 86400000L;
    private String authHeaderKey = "Authorization";
    private String authHeaderPrefix = "Bearer ";
}
