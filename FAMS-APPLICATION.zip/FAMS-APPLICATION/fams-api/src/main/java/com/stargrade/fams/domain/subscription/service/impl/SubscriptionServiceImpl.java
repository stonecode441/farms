package com.stargrade.fams.domain.subscription.service.impl;

import com.stargrade.fams.api.subscription.CancelSubscriptionRequestDto;
import com.stargrade.fams.api.subscription.CreateSubscriptionRequestDto;
import com.stargrade.fams.api.subscription.SubscriptionDto;
import com.stargrade.fams.api.subscription.SubscriptionRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.service.OrganizationService;
import com.stargrade.fams.domain.subscription.model.Subscription;
import com.stargrade.fams.domain.subscription.repository.SubscriptionRepository;
import com.stargrade.fams.domain.subscription.service.SubscriptionService;
import com.stargrade.fams.api.util.SubscriptionObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SubscriptionServiceImpl implements SubscriptionService {
    private final SubscriptionRepository subscriptionRepository;
    private final OrganizationService organizationService;
    private final SubscriptionObjectMapper mapper;

    @Override
    public SubscriptionDto createSubscription(CreateSubscriptionRequestDto createSubscriptionRequest) {
        Optional<Subscription> subscriptionOptional = subscriptionRepository.findByName(createSubscriptionRequest.getName());
        Subscription subscription;
        if(subscriptionOptional.isPresent()) {
            subscription = subscriptionOptional.get();
            subscription.setDescription(createSubscriptionRequest.getDescription());
            subscription.setPrice(createSubscriptionRequest.getPrice());
            subscription.setMinTenants(createSubscriptionRequest.getMinTenants());
            subscription.setMaxTenants(createSubscriptionRequest.getMaxTenants());
        }else {
            subscription = new Subscription(
                    CodeGenerator.generateUUID(),
                    createSubscriptionRequest.getName(),
                    createSubscriptionRequest.getDescription(),
                    createSubscriptionRequest.getPrice(),
                    createSubscriptionRequest.getMinTenants(),
                    createSubscriptionRequest.getMaxTenants()
            );
        }

        return mapper.toSubscriptionDto(subscriptionRepository.save(subscription));
    }

    @Override
    public List<SubscriptionDto> getAllSubscriptions() {
        return subscriptionRepository
                .findAllByDeletedAtIsNull()
                .stream()
                .map(mapper::toSubscriptionDto)
                .collect(Collectors.toList());
    }

    @Override
    public SubscriptionDto getSubscription(String subscriptionId) {
        return mapper.toSubscriptionDto(getSubscriptionByIdFromDb(subscriptionId));
    }

    Subscription getSubscriptionByIdFromDb(String subscriptionId) {
        Optional<Subscription> subscription = subscriptionRepository.findBySubscriptionIdAndDeletedAtIsNull(subscriptionId);
        if(subscription.isEmpty())
            throw new ValidationException(String.format("No subscription found with ID: %s", subscriptionId));
        return subscription.get();
    }

    @Override
    public SubscriptionDto deleteSubscription(String subscriptionId) {
        Subscription subscription = getSubscriptionByIdFromDb(subscriptionId);
        subscription.setDeletedAt(new Date());
        return mapper.toSubscriptionDto(subscriptionRepository.save(subscription));
    }

    @Override
    public SubscriptionDto activateSubscription(SubscriptionRequestDto subscriptionRequestDto) {
        Subscription subscription = getSubscriptionByIdFromDb(subscriptionRequestDto.getSubscriptionId());
        Organization organization = organizationService.getOrganizationById(subscriptionRequestDto.getOrganizationId());
//        TODO validate payment ref from Paystack and check if successful before activation
        organizationService.activateOrganizationSubscription(organization, subscription);
        return mapper.toSubscriptionDto(subscription);
    }

    @Override
    public SubscriptionDto modifySubscription(SubscriptionRequestDto subscriptionRequestDto) {
        Subscription subscription = getSubscriptionByIdFromDb(subscriptionRequestDto.getSubscriptionId());
        Organization organization = organizationService.getOrganizationById(subscriptionRequestDto.getOrganizationId());
//        TODO validate payment ref from Paystack and check if successful before activation
        organizationService.changeOrganizationSubscription(organization, subscription);
        return mapper.toSubscriptionDto(subscription);
    }

    @Override
    public SubscriptionDto cancelSubscription(CancelSubscriptionRequestDto cancelSubscriptionRequestDto) {
        Subscription subscription = getSubscriptionByIdFromDb(cancelSubscriptionRequestDto.getSubscriptionId());
        Organization organization = organizationService.getOrganizationById(cancelSubscriptionRequestDto.getOrganizationId());
//        TODO cancel subscription via Paystack API
        organizationService.deleteOrganizationSubscription(organization, subscription);
        return mapper.toSubscriptionDto(subscription);
    }
}
