package com.stargrade.fams.api.building;

import com.stargrade.fams.api.unit.UnitRequestDto;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CreateBuildingRequestDto implements Serializable {
    @NotEmpty(message = "Property name is required")
    private String name;

    @NotNull(message = "Building size is required")
    private Integer buildingSize;

    @NotNull(message = "Number of floors is required")
    private Integer noOfFloors;

    @NotNull(message = "Building type is required")
    private BuildingType buildingType;

    @NotNull(message = "Building units is required")
    private List<UnitRequestDto> units;
}
