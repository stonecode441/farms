package com.stargrade.fams.api.building;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
public class AddOccupantsRequestDto implements Serializable {
    @NotEmpty(message = "Unit ID is required")
    private String unitId;

    @NotNull(message = "Member IDs are required")
    private List<String> membersIds;

    @NotNull(message = "Lease start is required")
    private LocalDate leaseStart;

    @NotNull(message = "Lease end is required")
    private LocalDate leaseEnd;

    @NotEmpty(message = "Unit ID is required")
    private String primaryMemberId;
}
