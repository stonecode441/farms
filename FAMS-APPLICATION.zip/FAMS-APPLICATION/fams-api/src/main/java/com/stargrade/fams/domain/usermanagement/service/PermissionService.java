package com.stargrade.fams.domain.usermanagement.service;

import com.stargrade.fams.api.permission.PermissionDto;
import com.stargrade.fams.api.permission.PermissionRequestDto;
import com.stargrade.fams.api.permission.RolePermissionDto;

import java.util.List;

public interface PermissionService {
    List<PermissionDto> getAllPermissions();

    RolePermissionDto manageRolePermissions(PermissionRequestDto rolePermissionRequest, boolean isRemove);
}
