package com.stargrade.fams.domain.support.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Support extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String ticketId;
    @ManyToOne
    private User user;
    private Boolean isClosed;
    private Date closedAt;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Support support = (Support) o;
        return getId().equals(support.getId()) &&
                getTicketId().equals(support.getTicketId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTicketId(), getUser().getUserId());
    }
}
