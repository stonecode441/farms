/**
 * Created By MisterJames
 */


package com.stargrade.fams.api.permission;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
@Data
public class PermissionDto implements Serializable {
    private String permissionId;
    private String permissionName;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
    private String description;
}
