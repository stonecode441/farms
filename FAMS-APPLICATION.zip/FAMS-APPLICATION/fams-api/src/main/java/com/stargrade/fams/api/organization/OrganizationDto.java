package com.stargrade.fams.api.organization;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class OrganizationDto implements Serializable {
    private String id;
    private String name;
    private ContactDto contact;
    private AddressDto address;
    private Boolean isDisabled;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
