package com.stargrade.fams.domain.property.repository;

import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.property.model.Property;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PropertyRepository extends JpaRepository<Property, Long> {
    Optional<Property> findByPropertyIdAndOrganizationAndDeletedAtIsNull(String propertyId, Organization organization);

    Optional<Property> findByPropertyIdAndDeletedAtIsNull(String propertyId);

    List<Property> findAllByOrganizationAndDeletedAtIsNull(Organization organization);
}
