package com.stargrade.fams.api.util;

import com.stargrade.fams.api.invite.InviteCodeDto;
import com.stargrade.fams.api.invite.InviteDto;
import com.stargrade.fams.api.invite.InvitedGuest;
import com.stargrade.fams.domain.invite.model.Guest;
import com.stargrade.fams.domain.invite.model.Invite;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class InviteObjectMapper {
    public InviteCodeDto toInviteCodeDto(String code, LocalDateTime expiryDate) {
        InviteCodeDto inviteCodeDto = new InviteCodeDto();
        inviteCodeDto.setCode(code);
        inviteCodeDto.setExpiresIn(expiryDate);
        return inviteCodeDto;
    }

    public InvitedGuest toInvitedGuest(Guest guest, Date checkedInDate, Date checkedOutDate) {
        InvitedGuest invitedGuest = new InvitedGuest();
        invitedGuest.setFirstName(guest.getFirstName());
        invitedGuest.setLastName(guest.getLastName());
        invitedGuest.setPhoneNo(guest.getPhoneNo());
        invitedGuest.setGender(guest.getGender());
        invitedGuest.setIsDissallowed(guest.getIsDissallowed());
        invitedGuest.setId(guest.getGuestId());
        invitedGuest.setCheckedIn(checkedInDate);
        invitedGuest.setCheckedIn(checkedOutDate);
        return invitedGuest;
    }

    public InviteDto toInviteDto(Invite invite, String unitNo, List<InvitedGuest> invitedGuests) {
        InviteDto inviteDto = new InviteDto();
        inviteDto.setInviterId(invite.getInviter().getUserId());
        inviteDto.setUnitNo(unitNo);
        inviteDto.setInviteCode(invite.getInviteCode());
        inviteDto.setIsAlone(invite.getIsAlone());
        inviteDto.setAccessEndDate(invite.getAccessStartDate());
        inviteDto.setAccessEndDate(invite.getAccessEndDate());
        inviteDto.setInviteFrequency(invite.getInviteFrequency());
        inviteDto.setCreatedAt(invite.getCreatedAt());
        inviteDto.setUpdatedAt(invite.getUpdatedAt());
        inviteDto.setDeletedAt(invite.getDeletedAt());
        if(invitedGuests != null && !invitedGuests.isEmpty()) {
            inviteDto.setNoOfGuests(invitedGuests.size());
            inviteDto.setInvitedGuest(invitedGuests);
        }
        return inviteDto;
    }
}
