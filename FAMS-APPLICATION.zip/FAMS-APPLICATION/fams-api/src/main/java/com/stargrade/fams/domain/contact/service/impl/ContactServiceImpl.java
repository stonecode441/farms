package com.stargrade.fams.domain.contact.service.impl;

import com.stargrade.fams.api.organization.ContactDto;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.contact.model.Contact;
import com.stargrade.fams.domain.contact.repository.ContactRepository;
import com.stargrade.fams.domain.contact.service.ContactService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ContactServiceImpl implements ContactService {
    private final ContactRepository contactRepository;

    @Override
    public Contact createContact(ContactDto contactDto) {
        Optional<Contact> contact = contactRepository.findByEmail(contactDto.getEmail());
        return contact.orElseGet(() -> contactRepository.save(new Contact(
                CodeGenerator.generateUUID(),
                contactDto.getFirstName(),
                contactDto.getLastName(),
                contactDto.getEmail(),
                contactDto.getPhoneNumber())
        ));
    }
}
