package com.stargrade.fams.domain.property.repository;

import com.stargrade.fams.domain.property.model.Property;
import com.stargrade.fams.domain.property.model.PropertyImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PropertyImageRepository extends JpaRepository<PropertyImage, Long> {
    PropertyImage findFirstByPropertyOrderByIdDesc(Property property);
}
