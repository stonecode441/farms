package com.stargrade.fams.api.invite;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.invite.service.InviteService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/invites")
@RestController
@RequiredArgsConstructor
public class InviteController {
    private final InviteService inviteService;

    @Operation(summary = "Generate invite code")
    @GetMapping("/generate-code")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_INVITE)")
    public ResponseEntity<ApiResponse<InviteCodeDto>> generateInviteCode() {
        return ResponseEntity.ok(new ApiResponse<>("Invite code generated successfully", inviteService.generateInviteCode()));
    }

    @Operation(summary = "Create an invite")
    @PostMapping()
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_INVITE)")
    public ResponseEntity<ApiResponse<InviteDto>> createInvite(@Valid @RequestBody InviteRequestDto inviteRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Invite created successfully", inviteService.createInvite(inviteRequest)));
    }

    @Operation(summary = "Update an invite")
    @PutMapping("/{inviteId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).UPDATE_INVITE)")
    public ResponseEntity<ApiResponse<InviteDto>> updateInvite(@PathVariable String inviteId, @Valid @RequestBody UpdateInviteRequestDto updateInviteRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Invite updated successfully", inviteService.updateInvite(inviteId, updateInviteRequest)));
    }


    @Operation(summary = "Get an invite")
    @GetMapping("/{inviteId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_INVITE)")
    public ResponseEntity<ApiResponse<InviteDto>> getInvite(@PathVariable String inviteId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite created successfully", inviteService.getAnInvite(inviteId)));
    }

    @Operation(summary = "Get all invites")
    @GetMapping()
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_INVITE)")
    public ResponseEntity<ApiResponse<List<InviteDto>>> getAllInvites(@RequestParam(required = false, defaultValue = "0") Integer pageNumber, @RequestParam(required = false, defaultValue = "50") Integer pageSize) {
        return ResponseEntity.ok(new ApiResponse<>("Invites retrieved successfully", inviteService.getAllInvites(pageNumber, pageSize)));
    }


    @Operation(summary = "Cancel an invite")
    @PatchMapping("/cancel/{inviteId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CANCEL_INVITE)")
    public ResponseEntity<ApiResponse<InviteDto>> cancelInvite(@PathVariable String inviteId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite cancelled successfully", inviteService.cancelInvite(inviteId)));
    }

    @Operation(summary = "Check in")
    @PatchMapping("/check-in/{inviteId}/{guestId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CHECK_IN)")
    public ResponseEntity<ApiResponse<InviteDto>> checkIn(@PathVariable String inviteId, @PathVariable String guestId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite access granted successfully", inviteService.checkIn(inviteId, guestId)));
    }

    @Operation(summary = "Check out")
    @PatchMapping("/check-out/{inviteId}/{guestId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CHECK_OUT)")
    public ResponseEntity<ApiResponse<InviteDto>> checkOut(@PathVariable String inviteId, @PathVariable String guestId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite access modified successfully", inviteService.checkOut(inviteId, guestId)));
    }

    @Operation(summary = "Check in")
    @PatchMapping("/check-in/{inviteId}")
    public ResponseEntity<ApiResponse<InviteDto>> checkIn(@PathVariable String inviteId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite access granted successfully", mockHelper.toInviteDto()));
    }

    @Operation(summary = "Check out")
    @PatchMapping("/check-out/{inviteId}")
    public ResponseEntity<ApiResponse<InviteDto>> checkOut(@PathVariable String inviteId) {
        return ResponseEntity.ok(new ApiResponse<>("Invite access modified successfully", mockHelper.toInviteDto()));
    }
}
