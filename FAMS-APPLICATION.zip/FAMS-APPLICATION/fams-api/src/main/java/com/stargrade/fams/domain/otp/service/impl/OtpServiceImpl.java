package com.stargrade.fams.domain.otp.service.impl;

import com.stargrade.fams.api.otp.OtpDto;
import com.stargrade.fams.api.otp.SendOtpRequestDto;
import com.stargrade.fams.api.otp.ValidateOtpRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.otp.model.Otp;
import com.stargrade.fams.domain.otp.model.OtpOperation;
import com.stargrade.fams.domain.otp.service.OtpService;
import com.stargrade.fams.api.util.OtpObjectMapper;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.email.EmailBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {
    private final UserService userService;
    private final RedisTemplate<String, Otp> redisTemplate;
    private final OtpObjectMapper mapper;
    private final Mailer mailer;
    private final TemplateEngine templateEngine;

    @Value("${mail.smt.sendAsync:true}")
    private Boolean async;

    @Value("${mail.smt.sender:FAMS}")
    private String senderName;

    @Value("${mail.smt.senderEmail:}")
    private String senderEmail;

    @Value("${mail.smt.sendOTPSubj:FAMS - OTP REQUEST}")
    private String organizationInviteSubject;

    @Value("${fams.max.otp.lifetime.in.millis:300000}")// Default duration 5mins
    private Long maxOtpLifetimeInMillis;

    Otp getOtp(String code) {
        return redisTemplate.opsForValue().get(code);
    }

    void saveOtp(Otp otp) {
        Objects.requireNonNull(otp, "Otp cannot be null");
        if(StringUtils.isEmpty(otp.getCode()))
            throw new ValidationException("Otp code cannot be null");
        redisTemplate.opsForValue().set(otp.getCode(), otp, Duration.ofMillis(maxOtpLifetimeInMillis));
    }

    Boolean deleteOtp(String code) {
        if(this.getOtp(code) != null) {
            return redisTemplate.delete(code);
        }
        return true;
    }

    @Override
    public OtpDto sendOtp(SendOtpRequestDto sendOtpRequest) {
        OtpOperation otpOperation = getOtpOperation(sendOtpRequest.getOperation());
        User user = userService.getUserByIdFromDb(sendOtpRequest.getUserId());
        LocalDateTime currentDateTime = LocalDateTime.now();
        String code = CodeGenerator.generateCode(sendOtpRequest.getOtpLength());
        Otp otpFromRedis = getOtp(code);
        if(otpFromRedis != null) {
            LocalDateTime otpExpiry = otpFromRedis.getExpiry();
            if(currentDateTime.isBefore(otpExpiry)){
                // OTP has not expired
                sendOtp(sendOtpRequest);
            }else {
                // OTP has expired
                deleteOtp(code);
            }
        }

        LocalDateTime expiryDate = currentDateTime.plus(maxOtpLifetimeInMillis, ChronoUnit.MILLIS);
        Otp otp = new Otp(
                otpOperation,
                user.getUserId(),
                code,
                currentDateTime,
                expiryDate
        );

        saveOtp(otp);
        sendOtpToUser(user, code, Long.toString(maxOtpLifetimeInMillis/60/1000));
        return mapper.toOtpDto(otp);
    }

    public OtpOperation getOtpOperation(String operation) {
        try {
            return OtpOperation.valueOf(operation);
        }catch (IllegalArgumentException iae) {
            log.error("Failed to parse OTP operation", iae);
            throw new ValidationException(String.format("Invalid otp operation: %s", operation));
        }
    }

    void sendOtpToUser(User user, String oneTimePassword, String otpExpiryInMins) {
        Context context = new Context();
        context.setVariable("user", user);
        context.setVariable("otpCode", oneTimePassword);
        context.setVariable("otpCodeExpiryPeriod", otpExpiryInMins);
        String content = templateEngine.process("otp_template", context);
        Email email = EmailBuilder.startingBlank()
                .from(senderName, senderEmail)
                .to(String.format("%s %s", user.getFirstName(), user.getLastName()), user.getEmailAddress())
                .withSubject(organizationInviteSubject)
                .withHTMLText(content).buildEmail();
        mailer.sendMail(email, async);
    }

    @Override
    public Boolean validateOtp(ValidateOtpRequestDto validateOtpRequest) {
        User user = userService.getUserByIdFromDb(validateOtpRequest.getUserId());
        Otp otp = getOtp(validateOtpRequest.getOtp());
        var errorMessage = new StringBuilder("One time password validation failed");
        if(otp == null)
            throw new ValidationException(errorMessage.toString());
        if(StringUtils.isEmpty(otp.getCode()))
            throw new ValidationException(errorMessage.toString());
        if(!otp.getUserId().equals(user.getUserId()))
            throw new ValidationException(errorMessage.toString());
        return true;
    }
}
