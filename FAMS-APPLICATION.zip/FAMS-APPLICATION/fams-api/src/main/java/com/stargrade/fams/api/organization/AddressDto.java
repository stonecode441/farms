package com.stargrade.fams.api.organization;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class AddressDto implements Serializable {
    @NotEmpty(message = "City is required")
    private String city;

    @NotEmpty(message = "State is required")
    private String state;

    private String zipCode;

    @NotEmpty(message = "Country is required")
    private String country;

    @NotEmpty(message = "Country code is required")
    private String countryCode;

    @NotEmpty(message = "Address line is required")
    private String addressLine;
}
