package com.stargrade.fams.api.util;

import com.stargrade.fams.api.organization.OrganizationDto;
import com.stargrade.fams.api.util.AddressObjectMapper;
import com.stargrade.fams.api.util.ContactObjectMapper;
import com.stargrade.fams.domain.organization.model.Organization;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OrganizationObjectMapper {
    private final ContactObjectMapper contactObjectMapper;
    private final AddressObjectMapper addressObjectMapper;

    public OrganizationDto toOrganizationDto(Organization organization) {
        OrganizationDto organizationDto = new OrganizationDto();
        organizationDto.setId(organization.getOrganizationId());
        organizationDto.setIsDisabled(organization.getIsDisabled());
        organizationDto.setName(organization.getName());
        organizationDto.setContact(contactObjectMapper.toContactDto(organization.getContact()));
        organizationDto.setAddress(addressObjectMapper.toAddressDto(organization.getAddress()));
        organizationDto.setCreatedAt(organization.getCreatedAt());
        organizationDto.setUpdatedAt(organization.getUpdatedAt());
        organizationDto.setDeletedAt(organization.getDeletedAt());
        return organizationDto;
    }
}
