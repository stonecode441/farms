package com.stargrade.fams.api.building;

import com.stargrade.fams.api.unit.UnitDto;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class BuildingDto implements Serializable {
    private String id;
    private String propertyId;
    private String name;
    private Integer buildingSize;
    private Integer noOfFloors;
    private BuildingType buildingType;
    private List<UnitDto> units;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
