package com.stargrade.fams.api.otp;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class SendOtpRequestDto implements Serializable {
    @NotEmpty(message = "Operation is required")
    private String operation;
    @NotEmpty(message = "User ID is required")
    private String userId;
    private Integer otpLength;
}
