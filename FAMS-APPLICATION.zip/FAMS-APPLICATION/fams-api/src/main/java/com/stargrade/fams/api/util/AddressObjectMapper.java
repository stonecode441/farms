package com.stargrade.fams.api.util;

import com.stargrade.fams.api.organization.AddressDto;
import com.stargrade.fams.api.organization.ContactDto;
import com.stargrade.fams.domain.address.model.Address;
import com.stargrade.fams.domain.contact.model.Contact;
import org.springframework.stereotype.Component;

@Component
public class AddressObjectMapper {
    public AddressDto toAddressDto(Address address) {
        AddressDto addressDto = new AddressDto();
        addressDto.setAddressLine(address.getAddressLine());
        addressDto.setCity(address.getCity());
        addressDto.setCountry(address.getCountry());
        addressDto.setState(address.getState());
        addressDto.setCountryCode(address.getCountryCode());
        addressDto.setZipCode(address.getZipCode());
        return addressDto;
    }
}
