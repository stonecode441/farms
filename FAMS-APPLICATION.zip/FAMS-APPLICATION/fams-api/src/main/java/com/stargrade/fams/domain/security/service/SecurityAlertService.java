package com.stargrade.fams.domain.security.service;

import com.stargrade.fams.api.securityalert.SecurityAlertDto;
import com.stargrade.fams.api.securityalert.SecurityAlertRequestDto;

import java.util.List;

public interface SecurityAlertService {
    SecurityAlertDto createSecurityAlert(SecurityAlertRequestDto securityAlertRequestDto);

    SecurityAlertDto updateSecurityAlert(String alertId, SecurityAlertRequestDto updateSecurityAlertRequest);

    SecurityAlertDto deleteSecurityAlert(String alertId);

    SecurityAlertDto viewSecurityAlert(String alertId);

    List<SecurityAlertDto> viewUserSecurityAlerts();

    List<SecurityAlertDto> clearUserSecurityAlerts();
}
