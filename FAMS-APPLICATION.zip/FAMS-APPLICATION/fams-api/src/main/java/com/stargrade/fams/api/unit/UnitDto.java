package com.stargrade.fams.api.unit;

import com.stargrade.fams.api.usermanagement.UserDto;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Data
public class UnitDto implements Serializable {

    private String id;
    private String unitNo;
    private UnitType unitType;
    private Integer unitSize;
    private Integer maxOccupants;
    private Integer rent;
    private LocalDate leaseStart;
    private LocalDate leaseEnd;
    private String primaryMemberFirstName;
    private String primaryMemberLastName;
    private String primaryMemberEmail;
    private List<UserDto> currentOccupants;
    private List<LeaseRecord> leaseRecord;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

}
