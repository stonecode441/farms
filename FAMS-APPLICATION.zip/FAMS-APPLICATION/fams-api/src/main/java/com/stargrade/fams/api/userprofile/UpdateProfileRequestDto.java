package com.stargrade.fams.api.userprofile;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

@Data
public class UpdateProfileRequestDto implements Serializable {
    private String phoneNumber;
    private LocalDate dob;
}
