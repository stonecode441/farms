package com.stargrade.fams.domain.usermanagement.service;

import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.role.RoleRequestDto;
import com.stargrade.fams.domain.usermanagement.model.Role;

import java.util.List;

public interface RoleService {
    long getRowsCount();

    RoleDto createRole(RoleRequestDto createRoleRequest);

    List<RoleDto> getAllRoles();

    RoleDto getRole(String id);

    Role getDbRole(String id);

    RoleDto editRole(String roleId, RoleRequestDto editRoleRequest);

    RoleDto deactivateRole(String roleId);

    RoleDto activateRole(String roleId);
}
