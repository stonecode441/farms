package com.stargrade.fams.api.securityalert;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SecurityAlertRequestDto implements Serializable {
    @NotEmpty(message = "Message is required")
    private String message;
}
