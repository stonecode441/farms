/**
 * Created By MisterJames
 */


package com.stargrade.fams.api.permission;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class PermissionRequestDto implements Serializable {
    @NotEmpty(message = "Role ID is required")
    private String roleId;
    @NotNull(message = "Permission IDs should be provided")
    private List<String> permissionIds;
}
