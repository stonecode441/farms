package com.stargrade.fams.api.property;

import lombok.Data;

import java.io.Serializable;

@Data
public class PropertyImageDto implements Serializable {
    private String imageName = "default-image-url";
    private String imageUrl;
    private String imageFile;
}
