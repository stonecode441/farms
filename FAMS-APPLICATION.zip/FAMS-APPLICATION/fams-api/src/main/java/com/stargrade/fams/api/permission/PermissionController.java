/**
 * Created By MisterJames
 */

package com.stargrade.fams.api.permission;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.usermanagement.service.PermissionService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix:}/permission")
@RestController
@RequiredArgsConstructor
public class PermissionController {
    private final PermissionService permissionService;

    @Operation(summary = "View all permissions")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_PERMISSION)")
    public ResponseEntity<ApiResponse<List<PermissionDto>>> viewPermissions() {
        return ResponseEntity.ok(new ApiResponse<>("Permissions retrieved successfully", permissionService.getAllPermissions()));
    }

    @Operation(summary = "Add permission to role")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).ASSIGN_PERMISSION)")
    public ResponseEntity<ApiResponse<RolePermissionDto>> addPermission(@Valid @RequestBody PermissionRequestDto permissionRequestDto) {
        return ResponseEntity.ok(new ApiResponse<>("Permission added successfully", permissionService.manageRolePermissions(permissionRequestDto, false)));
    }

    @Operation(summary = "Remove a permission")
    @DeleteMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).ASSIGN_PERMISSION)")
    public ResponseEntity<ApiResponse<RolePermissionDto>> removePermissionFromRole(@Valid @RequestBody PermissionRequestDto permissionRequestDto) {
        return ResponseEntity.ok(new ApiResponse<>("Permission removed successfully", permissionService.manageRolePermissions(permissionRequestDto, true)));
    }
}
