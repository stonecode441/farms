package com.stargrade.fams.api.invite;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
public class InviteRequestDto implements Serializable {
    @NotEmpty(message = "Unit ID is required")
    private String unitId;
    @NotEmpty(message = "Invite code is required")
    private String inviteCode;
    @NotNull(message = "Invited guest is required")
    @Size(min = 1, message = "Invited guests cannot be empty")
    private List<InvitedGuest> invitedGuest;
    @NotNull(message = "Access end date is required")
    private LocalDate accessEndDate;
    @NotNull(message = "Access start date is required")
    private LocalDate accessStartDate;
    @NotNull(message = "Invite frequency is required")
    private InviteFrequency inviteFrequency;
}
