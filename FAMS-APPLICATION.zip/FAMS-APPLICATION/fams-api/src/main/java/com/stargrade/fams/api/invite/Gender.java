package com.stargrade.fams.api.invite;

import com.fasterxml.jackson.annotation.JsonValue;

public enum Gender {

    MALE("ML"), FEMALE("FL"), NON_BINARY("NB");
    private final String type;
    Gender(String type){this.type = type;}

    @JsonValue
    public String getType(){return type;}
}
