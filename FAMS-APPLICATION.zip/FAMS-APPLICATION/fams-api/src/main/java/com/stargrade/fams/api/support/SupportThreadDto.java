package com.stargrade.fams.api.support;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SupportThreadDto implements Serializable {
    private String threadId;
    private String message;
    private Date messageDate;
    private String reply;
    private Date replyDate;
}
