package com.stargrade.fams.api.usermanagement;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;

@Data
public class AuthenticationRequestDto implements Serializable {
    @NotEmpty(message = "Email address is required")
    private String emailAddress;

    @NotEmpty(message = "Password is required")
    @Size(min = 8, message = "Password cannot be less than eight (8) characters")
    private String password;
}
