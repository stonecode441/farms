package com.stargrade.fams.api.subscription;

import lombok.Data;

import java.io.Serializable;

@Data
public class SubscriptionRequestDto implements Serializable {
    private String organizationId;
    private String subscriptionId;
    private String paymentRef;
}
