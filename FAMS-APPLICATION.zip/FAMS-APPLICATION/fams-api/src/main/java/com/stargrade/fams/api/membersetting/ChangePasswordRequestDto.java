package com.stargrade.fams.api.membersetting;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ChangePasswordRequestDto implements Serializable {
    @NotEmpty(message = "Current password is required")
    private String currentPassword;

    @NotEmpty(message = "New password is required")
    private String newPassword;

    @NotEmpty(message = "Confirm new password field is required")
    private String confirmNewPassword;
}
