package com.stargrade.fams.api.building;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.building.service.BuildingService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RequestMapping("${app.route.prefix}/properties/{propertyId}/building")
@RestController
@RequiredArgsConstructor
public class BuildingController {
    private final BuildingService buildingService;

    @Operation(summary = "Create a building")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_BUILDING)")
    public ResponseEntity<ApiResponse<BuildingDto>> createBuilding(@PathVariable String propertyId, @Valid @RequestBody CreateBuildingRequestDto createBuildingRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Building created successfully", buildingService.createBuilding(propertyId, createBuildingRequest)));
    }

    @Operation(summary = "Update a building")
    @PutMapping("/{buildingId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).UPDATE_BUILDING)")
    public ResponseEntity<ApiResponse<BuildingDto>> updateBuilding(@PathVariable String propertyId, @PathVariable String buildingId, @Valid @RequestBody UpdateBuildingRequestDto updateBuildingRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Building updated successfully", buildingService.updateBuilding(propertyId, buildingId, updateBuildingRequest)));
    }

    @Operation(summary = "Add occupants")
    @PostMapping("/{buildingId}/occupants")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).UPDATE_BUILDING)")
    public ResponseEntity<ApiResponse<BuildingDto>> addOccupants(@PathVariable String propertyId, @PathVariable String buildingId, @Valid @RequestBody AddOccupantsRequestDto addOccupantsRequestDto) {
        return ResponseEntity.ok(new ApiResponse<>("Building updated successfully", buildingService.addOccupantsToBuilding(propertyId, buildingId, addOccupantsRequestDto)));
    }

    @Operation(summary = "Get a building")
    @GetMapping("/{buildingId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_BUILDING)")
    public ResponseEntity<ApiResponse<BuildingDto>> getBuilding(@PathVariable String propertyId, @PathVariable String buildingId) {
        return ResponseEntity.ok(new ApiResponse<>("Building retrieved successfully", buildingService.getBuilding(propertyId, buildingId)));
    }

    @Operation(summary = "Get a list of buildings")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_BUILDING)")
    public ResponseEntity<ApiResponse<List<BuildingDto>>> getListOfBuildings(@PathVariable String propertyId, @RequestParam(required = false, defaultValue = "0") Integer pageNumber, @RequestParam(required = false, defaultValue = "50") Integer pageSize) {
        return ResponseEntity.ok(new ApiResponse<>("Buildings retrieved successfully", buildingService.getAllBuildings(propertyId, pageNumber, pageSize)));
    }

    @Operation(summary = "Delete a Building")
    @DeleteMapping("/{buildingId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_BUILDING)")
    public ResponseEntity<ApiResponse<BuildingDto>> deleteBuilding(@PathVariable String propertyId, @PathVariable String buildingId) {
        return ResponseEntity.ok(new ApiResponse<>("Building deleted successfully", buildingService.deleteBuilding(propertyId, buildingId)));
    }
}
