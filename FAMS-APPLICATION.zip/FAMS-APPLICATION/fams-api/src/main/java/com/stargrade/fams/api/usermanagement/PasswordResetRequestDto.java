package com.stargrade.fams.api.usermanagement;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;

@Data
public class PasswordResetRequestDto implements Serializable {
    @NotEmpty(message = "New password cannot be null")
    @Size(min = 8, message = "Password cannot be less than eight (8) characters")
    private String newPassword;

    @NotEmpty(message = "Confirm password cannot be null")
    @Size(min = 8, message = "Confirm password cannot be less than eight (8) characters")
    private String confirmNewPassword;
}
