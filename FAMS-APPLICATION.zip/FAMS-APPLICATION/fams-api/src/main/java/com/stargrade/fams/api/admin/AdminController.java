package com.stargrade.fams.api.admin;

import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RequestMapping("${app.route.prefix}/admin")
@RestController
@RequiredArgsConstructor
public class AdminController {
    private final UserService userService;

    @Operation(summary = "Deactivate account")
    @PutMapping("/deactivate/{userId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_USER)")
    public ResponseEntity<ApiResponse<UserDto>> deactivateAccount(@PathVariable String userId) {
        return ResponseEntity.ok(new ApiResponse<>("Admin deactivated successfully", userService.deactivateAccount(userId)));
    }

    @Operation(summary = "Activate account")
    @PostMapping("/activate/{userId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_USER)")
    public ResponseEntity<ApiResponse<UserDto>> activateAccount(@PathVariable String userId) {
        return ResponseEntity.ok(new ApiResponse<>("Admin activated successfully", userService.activateAccount(userId)));
    }

    @Operation(summary = "Delete an account")
    @DeleteMapping("/{userId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_USER)")
    public ResponseEntity<ApiResponse<UserDto>> deleteAccount(@PathVariable String userId) {
        return ResponseEntity.ok(new ApiResponse<>("Admin account deleted successfully", userService.deleteAccount(userId)));
    }

    @Operation(summary = "Change role")
    @PutMapping("/change-role/{userId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_USER)")
    public ResponseEntity<ApiResponse<UserDto>> changeRole(@PathVariable String userId, @Valid @RequestBody ChangeRoleRequestDto changeRoleRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Admin role changed successfully", userService.changeRole(userId, changeRoleRequest)));
    }
}
