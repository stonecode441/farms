/**
 * Created By MisterJames
 */


package com.stargrade.fams.api.role;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
@Data
public class RoleRequestDto implements Serializable {
    @NotEmpty(message = "Role name is required")
    private String roleName;

    @NotEmpty(message = "Description is required")
    private String description;
}
