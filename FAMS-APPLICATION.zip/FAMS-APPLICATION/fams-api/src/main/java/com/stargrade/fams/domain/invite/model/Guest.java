package com.stargrade.fams.domain.invite.model;

import com.stargrade.fams.api.invite.Gender;
import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Guest extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String guestId;
    @ManyToOne
    private Invite invite;
    private String firstName;
    private String lastName;
    private Gender gender;
    @Column(unique = true)
    private String phoneNo;
    private Boolean isDissallowed;

    public Guest(String guestId, Invite invite, String firstName, String lastName, Gender gender, String phoneNo, Boolean isDissallowed) {
        this.guestId = guestId;
        this.invite = invite;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.phoneNo = phoneNo;
        this.isDissallowed = isDissallowed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Guest obj = (Guest) o;
        return getId().equals(obj.getId()) &&
                getGuestId().equals(obj.getGuestId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getGuestId(), getPhoneNo());
    }
}
