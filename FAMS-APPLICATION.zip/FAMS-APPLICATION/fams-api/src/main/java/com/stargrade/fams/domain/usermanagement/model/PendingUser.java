package com.stargrade.fams.domain.usermanagement.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class PendingUser extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String userId;
    @Column(nullable = false, updatable = false)
    private String roleId;
    @Column(nullable = false, updatable = false)
    private String unitId;
    private LocalDate leaseStart;
    private LocalDate leaseEnd;
    private String firstName;
    private String lastName;
    @Column(unique = true)
    private String emailAddress;
    @Column(unique = true)
    private String inviteCode;
    private LocalDate codeExpiryDate;

    public PendingUser(
            String userId, String roleId,
            String unitId, LocalDate leaseStart,
            LocalDate leaseEnd, String firstName,
            String lastName, String emailAddress,
            String inviteCode, LocalDate codeExpiryDate
    ) {
        this.userId = userId;
        this.roleId = roleId;
        this.unitId = unitId;
        this.leaseStart = leaseStart;
        this.leaseEnd = leaseEnd;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.inviteCode = inviteCode;
        this.codeExpiryDate = codeExpiryDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PendingUser pendingUser = (PendingUser) o;
        return getId().equals(pendingUser.getId()) &&
                getUserId().equals(pendingUser.getUserId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUserId(), getEmailAddress());
    }
}
