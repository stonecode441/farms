package com.stargrade.fams.api.property;

import com.stargrade.fams.api.organization.AddressDto;
import lombok.Data;

import java.io.Serializable;

@Data
public class UpdatePropertyRequestDto implements Serializable {
    private String name;

    private AddressDto address;

    private PropertyType propertyType;

    private String imageName;

    private String base64Image;
}
