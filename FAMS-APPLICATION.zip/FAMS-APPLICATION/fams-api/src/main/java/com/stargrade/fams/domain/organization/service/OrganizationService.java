package com.stargrade.fams.domain.organization.service;

import com.stargrade.fams.api.organization.OrganizationDto;
import com.stargrade.fams.api.organization.OrganizationRequestDto;
import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.model.OrganizationSubscription;
import com.stargrade.fams.domain.subscription.model.Subscription;

import java.util.List;

public interface OrganizationService {
    OrganizationDto inviteOrganization(OrganizationRequestDto organizationRequestDto);

    Organization getOrganizationById(String organizationId);

    OrganizationDto updateOrganization(String organizationId, OrganizationRequestDto organizationRequestDto);

    OrganizationDto deactivateOrganization(String organizationId);

    OrganizationDto activateOrganization(String organizationId);

    OrganizationDto viewOrganization(String organizationId);

    List<OrganizationDto> viewOrganizations(Integer pageNo, Integer pageSize);

    OrganizationDto deleteOrganization(String organizationId);

    OrganizationSubscription activateOrganizationSubscription(Organization organization, Subscription subscription);

    OrganizationSubscription changeOrganizationSubscription(Organization organization, Subscription subscription);

    void deleteOrganizationSubscription(Organization organization, Subscription subscription);

    void checkIfOrganizationSubscriptionSupportsMoreUnits(Organization organization, Long currentUnitCount);
}
