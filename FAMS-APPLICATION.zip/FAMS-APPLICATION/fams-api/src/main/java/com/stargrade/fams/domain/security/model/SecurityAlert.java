package com.stargrade.fams.domain.security.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.support.model.Support;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class SecurityAlert extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String alertId;
    @ManyToOne
    private User user;
    private String message;
    private Boolean isRead;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SecurityAlert securityAlert = (SecurityAlert) o;
        return getId().equals(securityAlert.getId()) &&
                getAlertId().equals(securityAlert.getAlertId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getAlertId(), getUser().getUserId());
    }
}
