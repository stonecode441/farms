package com.stargrade.fams.api.unit;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.unit.service.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/buildings/{buildingId}/units")
@RestController
@RequiredArgsConstructor
public class UnitController {
    private final UnitService unitService;

    @Operation(summary = "Create a unit")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_UNIT)")
    public ResponseEntity<ApiResponse<UnitDto>> createUnit(@PathVariable String buildingId, @Valid @RequestBody UnitRequestDto unitRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Unit created successfully", unitService.createUnit(buildingId, unitRequest)));
    }

    @Operation(summary = "Update a unit")
    @PutMapping("/{unitId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).UPDATE_UNIT)")
    public ResponseEntity<ApiResponse<UnitDto>> updateUnit(@PathVariable String buildingId, @PathVariable String unitId, @RequestBody UpdateUnitRequestDto updateUnitRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Unit updated successfully", unitService.updateUnit(buildingId, unitId, updateUnitRequest)));
    }

    @Operation(summary = "Get a unit")
    @GetMapping("/{unitId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_UNIT)")
    public ResponseEntity<ApiResponse<UnitDto>> getUnit(@PathVariable String buildingId, @PathVariable String unitId) {
        return ResponseEntity.ok(new ApiResponse<>("Unit retrieved successfully", unitService.getUnit(buildingId, unitId)));
    }

    @Operation(summary = "Get a list of units")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_UNIT)")
    public ResponseEntity<ApiResponse<List<UnitDto>>> getListOfUnits(@PathVariable String buildingId) {
        return ResponseEntity.ok(new ApiResponse<>("Units retrieved successfully", unitService.getAllUnits(buildingId)));
    }

    @Operation(summary = "Remove unit occupants")
    @DeleteMapping("/remove-occupants/{unitId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_UNIT)")
    public ResponseEntity<ApiResponse<Boolean>> removeUnitOccupants(@PathVariable String buildingId, @PathVariable String unitId) {
        return ResponseEntity.ok(new ApiResponse<>("Occupants removed from unit successfully", unitService.removeOccupantsFromUnit(buildingId, unitId)));
    }

    @Operation(summary = "Delete a unit")
    @DeleteMapping("/{unitId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_UNIT)")
    public ResponseEntity<ApiResponse<UnitDto>> deleteUnit(@PathVariable String buildingId, @PathVariable String unitId) {
        return ResponseEntity.ok(new ApiResponse<>("Unit deleted successfully", unitService.deleteUnit(buildingId, unitId)));
    }
}
