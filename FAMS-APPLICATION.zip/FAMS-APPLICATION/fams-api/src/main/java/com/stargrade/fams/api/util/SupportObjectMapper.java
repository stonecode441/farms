package com.stargrade.fams.api.util;

import com.stargrade.fams.api.support.SupportDto;
import com.stargrade.fams.api.support.SupportThreadDto;
import com.stargrade.fams.domain.support.model.Support;
import com.stargrade.fams.domain.support.model.SupportThread;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SupportObjectMapper {
    public SupportDto toSupportDto(Support support, List<SupportThreadDto> supportThreadDtoList) {
        SupportDto supportDto = new SupportDto();
        supportDto.setClosedAt(support.getClosedAt());
        supportDto.setCreatedAt(support.getCreatedAt());
        supportDto.setIsClosed(support.getIsClosed());
        supportDto.setTicketId(support.getTicketId());
        supportDto.setSupportThread(supportThreadDtoList);
        return supportDto;
    }

    public SupportThreadDto toSupportThreadDto(SupportThread supportThread) {
        SupportThreadDto supportThreadDto = new SupportThreadDto();
        supportThreadDto.setThreadId(supportThread.getMessage());
        supportThreadDto.setMessageDate(supportThread.getMessageDate());
        supportThreadDto.setReply(supportThread.getReply());
        supportThreadDto.setReplyDate(supportThread.getReplyDate());
        supportThreadDto.setThreadId(supportThread.getThreadId());
        return supportThreadDto;
    }
}
