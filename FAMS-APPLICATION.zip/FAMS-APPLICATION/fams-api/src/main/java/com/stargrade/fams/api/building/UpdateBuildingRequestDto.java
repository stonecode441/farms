package com.stargrade.fams.api.building;

import lombok.Data;

import java.io.Serializable;

@Data
public class UpdateBuildingRequestDto implements Serializable {
    private String name;
    private Integer buildingSize;
    private Integer noOfFloors;
    private BuildingType buildingType;
}
