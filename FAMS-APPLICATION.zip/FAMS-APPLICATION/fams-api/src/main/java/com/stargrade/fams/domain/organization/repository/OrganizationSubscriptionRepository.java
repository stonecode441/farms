package com.stargrade.fams.domain.organization.repository;

import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.model.OrganizationSubscription;
import com.stargrade.fams.domain.subscription.model.Subscription;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationSubscriptionRepository extends JpaRepository<OrganizationSubscription, Long> {
    Optional<OrganizationSubscription> findByOrganizationAndSubscription(Organization organization, Subscription subscription);

    Optional<OrganizationSubscription> findByOrganization(Organization organization);

    @Transactional
    @Modifying
    @Query("DELETE FROM OrganizationSubscription k WHERE k.organization.id =:organizationId")
    void deleteByOrganizationId(@Param("organizationId") Long organizationId);
}
