package com.stargrade.fams.api.membersetting;

import com.stargrade.fams.api.organization.AddressDto;
import com.stargrade.fams.api.organization.ContactDto;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class MemberSettingDto implements Serializable {
    private String memberId;
    private Boolean smsNotificationEnabled;
    private Boolean emailNotificationEnabled;
    private Boolean inAppNotificationEnabled;
    private Boolean subscribedToSecurityAlert;
    private Boolean darkModeEnabled;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
