package com.stargrade.fams.domain.base.exception;

public class FamsApplicationException extends Exception {
    public FamsApplicationException(String message) {
        super(message);
    }

    public FamsApplicationException(String message, Throwable cause) {
        super(message, cause);
    }
}
