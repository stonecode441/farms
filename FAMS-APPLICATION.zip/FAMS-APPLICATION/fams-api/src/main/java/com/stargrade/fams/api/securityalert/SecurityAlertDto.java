package com.stargrade.fams.api.securityalert;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SecurityAlertDto implements Serializable {
    private String alertId;
    private String userId;
    private String message;
    private Boolean isRead;
    private Date createdAt;
    private Date deletedAt;
}
