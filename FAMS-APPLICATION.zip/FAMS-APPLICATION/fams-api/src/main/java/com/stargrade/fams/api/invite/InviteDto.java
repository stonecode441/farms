package com.stargrade.fams.api.invite;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Data
public class InviteDto implements Serializable {
    private String id;
    private String inviterId;
    private String unitNo;
    private String inviteCode;
    private List<InvitedGuest> invitedGuest;
    private Boolean isAlone;
    private Integer noOfGuests;
    private LocalDate accessStartDate;
    private LocalDate accessEndDate;
    private InviteFrequency inviteFrequency;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
