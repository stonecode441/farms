package com.stargrade.fams.api.property;

import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.organization.AddressDto;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class PropertyDto implements Serializable {
    private String id;
    private String organizationId;
    private String name;
    private AddressDto address;
    private PropertyType propertyType;
    private PropertyImageDto  propertyImage;
    private List<BuildingDto> buildings;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
