package com.stargrade.fams.api.subscription;

import lombok.Data;

import java.io.Serializable;

@Data
public class CancelSubscriptionRequestDto implements Serializable {
    private String organizationId;
    private String subscriptionId;
}
