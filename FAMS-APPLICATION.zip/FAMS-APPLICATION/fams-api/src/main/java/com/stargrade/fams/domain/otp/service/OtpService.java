package com.stargrade.fams.domain.otp.service;

import com.stargrade.fams.api.otp.OtpDto;
import com.stargrade.fams.api.otp.SendOtpRequestDto;
import com.stargrade.fams.api.otp.ValidateOtpRequestDto;

public interface OtpService {
    OtpDto sendOtp(SendOtpRequestDto sendOtpRequest);

    Boolean validateOtp(ValidateOtpRequestDto validateOtpRequest);
}
