package com.stargrade.fams.api.util;

import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.property.PropertyDto;
import com.stargrade.fams.api.property.PropertyImageDto;
import com.stargrade.fams.api.util.AddressObjectMapper;
import com.stargrade.fams.domain.property.model.Property;
import com.stargrade.fams.domain.property.model.PropertyImage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class PropertyObjectMapper {
    private final AddressObjectMapper addressObjectMapper;

    public PropertyDto toPropertyDto(Property property, PropertyImage propertyImage, List<BuildingDto> buildingDtoList) {
        PropertyDto propertyDto = new PropertyDto();
        propertyDto.setId(property.getPropertyId());
        propertyDto.setOrganizationId(property.getOrganization().getOrganizationId());
        propertyDto.setAddress(addressObjectMapper.toAddressDto(property.getAddress()));
        propertyDto.setPropertyType(property.getPropertyType());

        PropertyImageDto propertyImageDto = new PropertyImageDto();
        propertyImageDto.setImageFile(propertyImage.getImageFormat());
        propertyImageDto.setImageUrl(propertyImage.getImageUrl());
        propertyImageDto.setImageName(propertyImage.getImageName());
        propertyDto.setPropertyImage(propertyImageDto);
        propertyDto.setBuildings(buildingDtoList);

        propertyDto.setPropertyType(property.getPropertyType());
        propertyDto.setCreatedAt(property.getCreatedAt());
        propertyDto.setUpdatedAt(property.getUpdatedAt());
        propertyDto.setDeletedAt(property.getDeletedAt());
        return propertyDto;
    }
}
