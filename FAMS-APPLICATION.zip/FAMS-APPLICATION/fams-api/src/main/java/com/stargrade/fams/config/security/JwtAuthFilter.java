package com.stargrade.fams.config.security;

import com.stargrade.fams.domain.usermanagement.service.TokenService;
import com.stargrade.fams.domain.usermanagement.service.impl.JwtServiceImpl;
import com.stargrade.fams.domain.usermanagement.service.impl.UserDetailsServiceImpl;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {
    private final JwtServiceImpl jwtService;
    private final UserDetailsServiceImpl userDetailsServiceImpl;
    private final TokenService tokenService;
    @Value("#{'${app.routes.paths-to-be-excluded:/authenticate,/swagger-ui/index.html}'.split(',')}")
    private List<String> pathsToBeExcluded;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        var authHeader = request.getHeader(jwtService.getJwtAuthConfiguration().getAuthHeaderKey());
        String token = null;
        String userEmailAddress = null;
        if(authHeader != null && authHeader.startsWith(jwtService.getJwtAuthConfiguration().getAuthHeaderPrefix())){
            token = authHeader.substring(7);
            userEmailAddress = jwtService.extractUsername(token);
        }

        var isTokenValid = !StringUtils.isEmpty(token);

        var storedToken = !uriContainsExcludedPath(request.getRequestURI()) ? tokenService.getUserToken(jwtService.extractUserId(token)) : null;
        if(storedToken == null)
            isTokenValid = false;
        if(userEmailAddress != null && SecurityContextHolder.getContext().getAuthentication() == null){
            UserDetails userDetails = userDetailsServiceImpl.loadUserByUsername(userEmailAddress);
            if(jwtService.validateToken(token, userDetails) && isTokenValid){
                UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            }
        }

        filterChain.doFilter(request, response);
    }

    boolean uriContainsExcludedPath(String uri) {
        for(String path : pathsToBeExcluded) {
            if(uri.toLowerCase().contains(path))
                return true;
        }
        return false;
    }
}
