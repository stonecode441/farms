package com.stargrade.fams.domain.usermanagement.service.impl;

import com.stargrade.fams.domain.usermanagement.model.CustomUserDetails;
import com.stargrade.fams.domain.usermanagement.model.RolePermission;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.repository.RolePermissionRepository;
import com.stargrade.fams.domain.usermanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository userRepository;
    private final RolePermissionRepository rolePermissionRepository;

    @Override
    public UserDetails loadUserByUsername(String emailAddress) throws UsernameNotFoundException {
        log.debug("LoadUserByUsername Process Begins...");
        Optional<User> user = userRepository.findByEmailAddressAndIsDisabledFalseAndDeletedAtIsNull(emailAddress);
        if(user.isEmpty()){
            log.error("Username not found: " + emailAddress);
            throw new UsernameNotFoundException("Invalid email address/password");
        }
        log.debug("User Authenticated Successfully..!!!");
        User appUser = user.get();
        List<RolePermission> rolePermissionList = rolePermissionRepository.findAllByRole(appUser.getRole());
        return new CustomUserDetails(appUser.getEmailAddress(), appUser.getPasswordHash(), rolePermissionList.stream().map(rp -> rp.getPermission().getName()).collect(Collectors.toList()));
    }
}
