package com.stargrade.fams.api.unit;

import com.fasterxml.jackson.annotation.JsonValue;

public enum UnitType {
    DEFAULT("DF"),
    OFFICE("OF"),
    BOOTH("BT"),
    STUDIO("ST"),
    ONE_BED("1B"),
    TWO_BED("2B"),
    THREE_BED("3B"),
    FOUR_BED("4B");

    private final String type;

    UnitType(String type) {this.type = type;}

    @JsonValue
    public String getType(){ return type;}
}
