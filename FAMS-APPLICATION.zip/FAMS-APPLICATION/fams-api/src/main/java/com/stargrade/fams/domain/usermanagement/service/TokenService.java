package com.stargrade.fams.domain.usermanagement.service;

import com.stargrade.fams.domain.usermanagement.model.Token;

public interface TokenService {
    Token getUserToken(String userId);

    void saveUserToken(String userId, Token token);

    Boolean deleteToken(String userId);
}
