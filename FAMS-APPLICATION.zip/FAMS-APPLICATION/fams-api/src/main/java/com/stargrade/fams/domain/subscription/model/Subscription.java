package com.stargrade.fams.domain.subscription.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Subscription extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String subscriptionId;
    @Column(unique = true)
    private String name;
    @Lob
    private String description;
    private BigDecimal price;
    private Integer minTenants;
    private Integer maxTenants;

    public Subscription(String subscriptionId, String name, String description, BigDecimal price, Integer minTenants, Integer maxTenants) {
        this.subscriptionId = subscriptionId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.minTenants = minTenants;
        this.maxTenants = maxTenants;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Subscription subscription = (Subscription) o;
        return getId().equals(subscription.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getSubscriptionId(), getName());
    }
}
