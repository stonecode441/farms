package com.stargrade.fams.domain.organization.model;

import com.stargrade.fams.domain.address.model.Address;
import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.contact.model.Contact;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Organization extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String organizationId;
    @Column(unique = true)
    private String name;
    @ManyToOne
    private Contact contact;
    @ManyToOne
    private Address address;
    private Boolean isDisabled;

    public Organization(String organizationId, String name, Contact contact, Address address) {
        this.organizationId = organizationId;
        this.name = name;
        this.contact = contact;
        this.address = address;
        this.isDisabled = true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Organization obj = (Organization) o;
        return getId().equals(obj.getId()) &&
                getOrganizationId().equals(obj.getOrganizationId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getOrganizationId(), getName());
    }
}
