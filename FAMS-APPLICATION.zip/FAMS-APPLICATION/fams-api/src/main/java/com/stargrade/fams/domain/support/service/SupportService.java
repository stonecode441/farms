package com.stargrade.fams.domain.support.service;

import com.stargrade.fams.api.support.SupportDto;
import com.stargrade.fams.api.support.SupportMessageRequestDto;


public interface SupportService {
    SupportDto createSupport(SupportMessageRequestDto supportMessageRequestDto);

    SupportDto viewSupport(String ticketId);

    SupportDto addMessageToTicket(String ticketId, SupportMessageRequestDto supportMessageRequestDto);

    SupportDto replyMessageInTicket(String ticketId, String threadId, SupportMessageRequestDto replyMessageRequest);

    SupportDto closeSupportRequest(String ticketId);
}
