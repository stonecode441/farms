package com.stargrade.fams.domain.property.service.impl;

import com.cloudinary.Cloudinary;
import com.cloudinary.Transformation;
import com.stargrade.fams.api.property.PropertyDto;
import com.stargrade.fams.api.property.PropertyRequestDto;
import com.stargrade.fams.api.property.UpdatePropertyRequestDto;
import com.stargrade.fams.domain.address.model.Address;
import com.stargrade.fams.domain.address.service.AddressService;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.building.service.BuildingService;
import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.service.OrganizationService;
import com.stargrade.fams.domain.property.model.Property;
import com.stargrade.fams.domain.property.model.PropertyImage;
import com.stargrade.fams.domain.property.repository.PropertyImageRepository;
import com.stargrade.fams.domain.property.repository.PropertyRepository;
import com.stargrade.fams.domain.property.service.PropertyService;
import com.stargrade.fams.api.util.PropertyObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PropertyServiceImpl implements PropertyService {
    private final PropertyRepository propertyRepository;
    private final OrganizationService organizationService;
    private final AddressService addressService;
    private BuildingService buildingService;
    private final PropertyObjectMapper mapper;
    private final Cloudinary cloudinary;
    private final PropertyImageRepository propertyImageRepository;

    public void setBuildingService(BuildingService buildingService) {
        this.buildingService = buildingService;
    }

    @Value("${fams.media.upload.directory:fams-upload}")
    private String uploadDir;

    @Override
    public PropertyDto createProperty(String organizationId, PropertyRequestDto createPropertyRequest) throws FamsApplicationException {
        Organization organization = organizationService.getOrganizationById(organizationId);
        Address address = addressService.createAddress(createPropertyRequest.getAddress());
        Property property = propertyRepository.save(new Property(
                CodeGenerator.generateUUID(),
                organization,
                createPropertyRequest.getName(),
                address,
                createPropertyRequest.getPropertyType()
        ));
        PropertyImage propertyImage = new PropertyImage();
        if(!StringUtils.isEmpty(createPropertyRequest.getBase64Image())) {
            try {
                propertyImage = this.uploadPropertyImage(
                        !StringUtils.isEmpty(
                                createPropertyRequest.getImageName()) ?
                                createPropertyRequest.getImageName() :
                                String.format("property-image-%s", property.getPropertyId()
                                ),
                        createPropertyRequest.getBase64Image(),
                        property
                );
            } catch (IOException fae) {
                throw new FamsApplicationException("Failed to upload property image", fae);
            }
        }
        return mapper.toPropertyDto(property, propertyImage, new ArrayList<>());
    }

    PropertyImage uploadPropertyImage(String imageName, String base64Image, Property property) throws IOException {
        Map<String, Object> params = new HashMap<>();
        Map result;
        Objects.requireNonNull(base64Image, "To upload photo, a base 64 image is required");
        params.put("public_id", String.format("%s/property/%s", uploadDir, property.getPropertyId()));
        params.put("transformation", new Transformation<>().width(200).height(200).crop("limit"));
        params.put("overwrite", "true");
        result = cloudinary.uploader().upload(base64Image, params);
        return propertyImageRepository.save(
                new PropertyImage(
                        CodeGenerator.generateUUID(),
                        imageName,
                        result.get("url").toString(),
                        result.get("format").toString(),
                        property)
        );
    }

    @Override
    public PropertyDto updateProperty(String organizationId, String propertyId, UpdatePropertyRequestDto updatePropertyRequest) throws FamsApplicationException {
        Organization organization = organizationService.getOrganizationById(organizationId);
        Optional<Property> propertyFromDb = propertyRepository.findByPropertyIdAndOrganizationAndDeletedAtIsNull(propertyId, organization);
        if(propertyFromDb.isEmpty())
            throw new ValidationException(String.format("Property with id: %s does not exist for organization: %s", propertyId, organization.getOrganizationId()));
        Property property = propertyFromDb.get();

        if(!StringUtils.isEmpty(updatePropertyRequest.getName()))
            property.setName(updatePropertyRequest.getName());
        if(updatePropertyRequest.getPropertyType() != null)
            property.setPropertyType(updatePropertyRequest.getPropertyType());
        if(updatePropertyRequest.getAddress() != null)
            property.setAddress(addressService.createAddress(updatePropertyRequest.getAddress()));

        if(!StringUtils.isEmpty(updatePropertyRequest.getBase64Image())) {
            try {
                this.uploadPropertyImage(
                        !StringUtils.isEmpty(
                                updatePropertyRequest.getImageName()) ?
                                updatePropertyRequest.getImageName() :
                                String.format("property-image-%s", property.getPropertyId()
                                ),
                        updatePropertyRequest.getBase64Image(),
                        property
                );
            } catch (IOException fae) {
                throw new FamsApplicationException("Failed to upload property image", fae);
            }
        }

        return getPropertyFull(propertyRepository.save(property));
    }

    PropertyDto getPropertyFull(Property property) {
        PropertyImage latestPropertyImage = propertyImageRepository.findFirstByPropertyOrderByIdDesc(property);
        return mapper.toPropertyDto(property, latestPropertyImage, buildingService.getAllBuildings(property));
    }

    @Override
    public PropertyDto getProperty(String organizationId, String propertyId) {
        Organization organization = organizationService.getOrganizationById(organizationId);
        Optional<Property> property = propertyRepository.findByPropertyIdAndOrganizationAndDeletedAtIsNull(propertyId, organization);
        if(property.isEmpty())
            throw new ValidationException(String.format("Property with id: %s does not exist for organization: %s", propertyId, organization.getOrganizationId()));

        return getPropertyFull(property.get());
    }

    @Override
    public List<PropertyDto> getAllProperties(String organizationId) {
        Organization organization = organizationService.getOrganizationById(organizationId);
        return propertyRepository.findAllByOrganizationAndDeletedAtIsNull(organization)
                .stream()
                .map(this::getPropertyFull)
                .collect(Collectors.toList());
    }

    @Override
    public PropertyDto deleteProperty(String organizationId, String propertyId) {
        Organization organization = organizationService.getOrganizationById(organizationId);
        Optional<Property> propertyFromDb = propertyRepository.findByPropertyIdAndOrganizationAndDeletedAtIsNull(propertyId, organization);
        if(propertyFromDb.isEmpty())
            throw new ValidationException(String.format("Property with id: %s does not exist for organization: %s", propertyId, organization.getOrganizationId()));

        Property property = propertyFromDb.get();
        property.setDeletedAt(new Date());
        return getPropertyFull(propertyRepository.save(property));
    }

    @Override
    public Property getPropertyByIdFromDb(String propertyId) {
        Optional<Property> property = propertyRepository.findByPropertyIdAndDeletedAtIsNull(propertyId);
        if(property.isEmpty())
            throw new ValidationException(String.format("Property with id: %s does not exist", propertyId));
        return property.get();
    }
}
