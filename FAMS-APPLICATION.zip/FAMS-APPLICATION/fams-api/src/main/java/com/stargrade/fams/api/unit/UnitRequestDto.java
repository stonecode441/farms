package com.stargrade.fams.api.unit;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

@Data
public class UnitRequestDto implements Serializable {
    @NotEmpty(message = "Unit no is required")
    private String unitNo;

    @NotNull(message = "Unit type is required")
    private UnitType unitType;

    @NotNull(message = "Unit size is required")
    private Integer unitSize;

    @NotNull(message = "Unit type is required")
    private Integer maxOccupants;

    @NotNull(message = "Unit type is required")
    private Integer rent;
}
