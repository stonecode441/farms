package com.stargrade.fams.domain.invite.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"invite_id", "guest_id"}))
@Entity
@Getter
@Setter
@NoArgsConstructor
public class InviteGuest extends BaseEntity {
    @ManyToOne
    private Invite invite;
    @ManyToOne
    private Guest guest;
    private Date checkedIn;
    private Date checkedOut;

    public InviteGuest(Invite invite, Guest guest) {
        this.invite = invite;
        this.guest = guest;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InviteGuest inviteGuest = (InviteGuest) o;
        return getId().equals(inviteGuest.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getInvite().getInviteId(), getGuest().getGuestId());
    }
}
