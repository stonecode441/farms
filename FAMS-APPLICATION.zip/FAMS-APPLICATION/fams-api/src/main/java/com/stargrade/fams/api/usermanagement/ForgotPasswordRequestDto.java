package com.stargrade.fams.api.usermanagement;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ForgotPasswordRequestDto implements Serializable {
    @NotEmpty(message = "Email address is required")
    private String emailAddress;
}
