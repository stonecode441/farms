package com.stargrade.fams.api.usermanagement;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import com.stargrade.fams.domain.usermanagement.service.impl.AccountUploadService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RequestMapping("${app.route.prefix}/user")
@RestController
@RequiredArgsConstructor
public class UserManagementController {
    private final UserService userService;
    private final AccountUploadService accountUploadService;

    @Value("${app.downloads.dir:fams-backend/downloads}")
    private String downloadsDir;

    @Value("${app.downloads.sample.create-user.template.file.name:Sample upload document.xlsx}")
    private String sampleCreateUserTemplateFileName;

    @Operation(summary = "Authenticate")
    @PostMapping("/authenticate")
    public ResponseEntity<ApiResponse<AuthenticationDto>> authenticate(@Valid @RequestBody AuthenticationRequestDto authenticationRequest) {
        return ResponseEntity.ok(new ApiResponse<>("User authentication successful", userService.authenticate(authenticationRequest)));
    }

    @Operation(summary = "Create User Account")
    @PostMapping("/create")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_USER)")
    public ResponseEntity<ApiResponse<PendingUserDto>> createAccount(@Valid @RequestBody CreateAccountRequestDto createAccountRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Account created successfully", userService.createAccount(createAccountRequest)));
    }

    @Operation(summary = "Create Multiple User Accounts")
    @PostMapping("/create-multiple")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_USER)")
    public ResponseEntity<?> bulkContactUpload(@RequestPart("uploadedDoc") MultipartFile uploadedDoc) throws FamsApplicationException {
        accountUploadService.sendForProcessing(uploadedDoc);
        return new ResponseEntity<>(new ApiResponse<>("Request submitted successfully. Account invites are being sent in the background", null), HttpStatus.OK);
    }

    @Operation(summary = "View sample document format for creating multiple user accounts")
    @GetMapping("/create-multiple/sample")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_USER)")
    public ResponseEntity<?> viewBulkUploadTemplate() throws FamsApplicationException {
        File file;
        Path path;
        ByteArrayResource resource;

        try {
            path = Paths.get(downloadsDir).resolve(sampleCreateUserTemplateFileName);
            file = new UrlResource(path.toUri()).getFile();
            resource = new ByteArrayResource(Files.readAllBytes(path));
        }catch (IOException ex) {
            ex.printStackTrace();
            throw new FamsApplicationException(ex.getMessage());
        }

        if(file.exists())
            return ResponseEntity.ok()
                    .contentLength(file.length())
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        else throw new FamsApplicationException("An error occurred while retrieving bulk upload template design - File does not exist");
    }

    @Operation(summary = "Get invited user details by code")
    @GetMapping("/invited/{inviteCode}")
    public ResponseEntity<ApiResponse<PendingUserDto>> getInvitedUserDetailsByCode(@PathVariable String inviteCode) {
        return ResponseEntity.ok(new ApiResponse<>("invited user successfully", userService.getInvitedUser(inviteCode)));
    }

    @Operation(summary = "Activate Account")
    @PostMapping("/activate")
    public ResponseEntity<ApiResponse<UserDto>> activateAccount(@RequestParam String inviteCode, @Valid @RequestBody ActivateAccountRequestDto activateAccountRequest) throws FamsApplicationException {
        return ResponseEntity.ok(new ApiResponse<>("Account activated successfully", userService.activateAccount(activateAccountRequest)));
    }

    @Operation(summary = "Forgot Password")
    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<?>> forgotPassword(@RequestBody ForgotPasswordRequestDto forgotPasswordRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Password reset initiated successfully", userService.forgotPassword(forgotPasswordRequest)));
    }

    @Operation(summary = "Reset Password")
    @PostMapping("/password-reset")
    public ResponseEntity<ApiResponse<?>> passwordReset(@RequestBody PasswordResetRequestDto passwordResetRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Password reset successfully", userService.resetPassword(passwordResetRequest)));
    }

    @Operation(summary = "Get Signed In User")
    @GetMapping("/signed-in")
    public ResponseEntity<ApiResponse<UserDto>> getSignedInUser() {
        return ResponseEntity.ok(new ApiResponse<>("Organization activated successfully", userService.getSignedInUser()));
    }

    @Operation(summary = "Get All Users By Role")
    @GetMapping("/by-role/{roleId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_USER)")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllUsersByRole(@PathVariable String roleId, @RequestParam(required = false, defaultValue = "0") Integer pageNumber, @RequestParam(required = false, defaultValue = "100") Integer pageSize) {
        return ResponseEntity.ok(new ApiResponse<>("Users retrieved successfully", userService.getAllUsersByRole(roleId, pageNumber, pageSize)));
    }

    @Operation(summary = "Get User by Id")
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_USER)")
    public ResponseEntity<ApiResponse<UserDto>> getUserById(@PathVariable String id) {
        return ResponseEntity.ok(new ApiResponse<>("User retrieved successfully", userService.getUser(id)));
    }
}
