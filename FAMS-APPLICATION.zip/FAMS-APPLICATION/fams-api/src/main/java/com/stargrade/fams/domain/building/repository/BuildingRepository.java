package com.stargrade.fams.domain.building.repository;

import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.property.model.Property;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {
    List<Building> findAllByPropertyAndDeletedAtIsNull(Property property);

    Page<Building> findAllByPropertyAndDeletedAtIsNull(Property property, Pageable pageable);

    Optional<Building> findByBuildingIdAndPropertyAndDeletedAtIsNull(String buildingId, Property property);

    Optional<Building> findByBuildingIdAndDeletedAtIsNull(String buildingId);
}
