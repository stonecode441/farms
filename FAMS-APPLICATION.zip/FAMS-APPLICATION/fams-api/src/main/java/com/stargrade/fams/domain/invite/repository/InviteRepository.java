package com.stargrade.fams.domain.invite.repository;

import com.stargrade.fams.domain.invite.model.Invite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InviteRepository extends JpaRepository<Invite, Long> {
    Optional<Invite> findByInviteCode(String inviteCode);

    Optional<Invite> findByInviteIdAndDeletedAtIsNull(String inviteId);

    Page<Invite> findAllByDeletedAtIsNull(Pageable pageable);
}
