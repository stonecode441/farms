package com.stargrade.fams.api.securityalert;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.api.util.MockHelper;
import com.stargrade.fams.domain.security.service.SecurityAlertService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/security-alert")
@RestController
@RequiredArgsConstructor
public class SecurityAlertController {
    private final SecurityAlertService securityAlertService;

    @Operation(summary = "Create security alert")
    @PostMapping
    public ResponseEntity<ApiResponse<SecurityAlertDto>> createSecurityAlert(@Valid @RequestBody SecurityAlertRequestDto createSecurityAlertRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Security alert created successfully", securityAlertService.createSecurityAlert(createSecurityAlertRequest)));
    }

    @Operation(summary = "Update security alert")
    @PutMapping("/{alertId}")
    public ResponseEntity<ApiResponse<SecurityAlertDto>> updateSecurityAlert(@PathVariable String alertId, @Valid @RequestBody SecurityAlertRequestDto updateSecurityAlertRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Security alert updated successfully", securityAlertService.updateSecurityAlert( alertId,updateSecurityAlertRequest)));
    }

    @Operation(summary = "Delete security alert")
    @DeleteMapping("{alertId}")
    public ResponseEntity<ApiResponse<?>> deleteSecurityAlert(@PathVariable String alertId) {
        return ResponseEntity.ok(new ApiResponse<>("Security alert deleted successfully", securityAlertService.deleteSecurityAlert(alertId)));
    }

    @Operation(summary = "View security alert")
    @GetMapping("{alertId}")
    public ResponseEntity<ApiResponse<SecurityAlertDto>> viewSecurityAlert(@PathVariable String alertId) {
        return ResponseEntity.ok(new ApiResponse<>("Security alert retrieved successfully", securityAlertService.viewSecurityAlert(alertId)));
    }

    @Operation(summary = "View all security alerts for user")
    @GetMapping
    public ResponseEntity<ApiResponse<List<SecurityAlertDto>>> viewUserSecurityAlerts() {
        return ResponseEntity.ok(new ApiResponse<>("Security alerts retrieved successfully", securityAlertService.viewUserSecurityAlerts()));
    }

    @Operation(summary = "Clear security alerts for user")
    @DeleteMapping("/clear")
    public ResponseEntity<ApiResponse<List<SecurityAlertDto>>> clearUserSecurityAlerts() {
        return ResponseEntity.ok(new ApiResponse<>("Security alerts retrieved successfully", securityAlertService.clearUserSecurityAlerts()));
    }
}
