package com.stargrade.fams.domain.usermanagement.service.impl;

import com.stargrade.fams.domain.usermanagement.repository.UserRepository;
import com.stargrade.fams.domain.usermanagement.service.TokenService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class LogoutServiceImpl implements LogoutHandler {
    private final JwtServiceImpl jwtService;
    private final UserRepository userRepository;
    private final TokenService tokenService;

    public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        final var authHeader = request.getHeader(jwtService.getJwtAuthConfiguration().getAuthHeaderKey());
        final String jwtToken;
        if(authHeader == null || !authHeader.startsWith("Bearer "))
            return;
        jwtToken = authHeader.substring(7);
        var tokenUserEmail = jwtService.extractUsername(jwtToken);
        var user = userRepository.findByEmailAddressAndIsDisabledFalseAndDeletedAtIsNull(tokenUserEmail);
        if(user.isEmpty())
            return;
        var appUser = user.get();
        var isTokenDeleted = tokenService.deleteToken(appUser.getUserId());
        log.debug("Token deleted for user: {} -> {}", appUser.getUserId(), isTokenDeleted);
        SecurityContextHolder.clearContext();
    }
}