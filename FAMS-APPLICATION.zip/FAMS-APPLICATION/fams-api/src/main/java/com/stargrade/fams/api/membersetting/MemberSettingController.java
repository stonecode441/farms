package com.stargrade.fams.api.membersetting;

import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.api.util.MockHelper;
import com.stargrade.fams.domain.setting.service.SettingService;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("${app.route.prefix}/member-setting")
@RestController
@RequiredArgsConstructor
public class MemberSettingController {
    private final UserService userService;
    private final SettingService settingService;

    @Operation(summary = "Change password")
    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<UserDto>> changePassword(@Valid @RequestBody ChangePasswordRequestDto changePasswordRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Password changed successfully", userService.changePassword(changePasswordRequest)));
    }

    @Operation(summary = "Update notification settings")
    @PutMapping("/update-notification-settings")
    public ResponseEntity<ApiResponse<MemberSettingDto>> updateNotificationSettings(@RequestBody UpdateNotificationRequestDto updateNotificationRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Notification updated successfully", settingService.updateNotificationSettings(updateNotificationRequest)));
    }

    @Operation(summary = "Toggle dark mode", description = "Supported action is one of: ON/OFF")
    @PostMapping("/toggle-dark-mode/{action}")
    public ResponseEntity<ApiResponse<MemberSettingDto>> toggleDarkMode(@PathVariable String action) {
        return ResponseEntity.ok(new ApiResponse<>("Preference updated successfully", settingService.toggleDarkMode(action)));
    }

    @Operation(summary = "Toggle security alert", description = "Supported action is one of: ON/OFF")
    @PostMapping("/toggle-security-alert/{action}")
    public ResponseEntity<ApiResponse<MemberSettingDto>> toggleSecurityAlert(@PathVariable String action) {
        return ResponseEntity.ok(new ApiResponse<>("Security alert settings updated successfully", settingService.toggleSecurityAlert(action)));
    }
}
