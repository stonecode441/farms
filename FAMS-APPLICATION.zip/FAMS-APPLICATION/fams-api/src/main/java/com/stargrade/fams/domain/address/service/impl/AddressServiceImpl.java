package com.stargrade.fams.domain.address.service.impl;

import com.stargrade.fams.api.organization.AddressDto;
import com.stargrade.fams.domain.address.model.Address;
import com.stargrade.fams.domain.address.repository.AddressRepository;
import com.stargrade.fams.domain.address.service.AddressService;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AddressServiceImpl implements AddressService {
    private final AddressRepository addressRepository;

    @Override
    public Address createAddress(AddressDto addressDto) {
        Optional<Address> address = addressRepository.findByAddressLine(addressDto.getAddressLine());
        return address.orElseGet(() -> addressRepository.save(new Address(
                CodeGenerator.generateUUID(),
                addressDto.getCity(),
                addressDto.getState(),
                addressDto.getZipCode(),
                addressDto.getCountry(),
                addressDto.getCountryCode(),
                addressDto.getAddressLine())
        ));
    }
}
