package com.stargrade.fams.domain.property.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class PropertyImage extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String imageId;
    private String imageName;
    private String imageUrl;
    private String imageFormat;
    @ManyToOne
    private Property property;

    public PropertyImage(String imageId, String imageName, String imageUrl, String imageFormat, Property property) {
        this.imageId = imageId;
        this.imageName = imageName;
        this.imageUrl = imageUrl;
        this.imageFormat = imageFormat;
        this.property = property;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PropertyImage propertyImage = (PropertyImage) o;
        return getId().equals(propertyImage.getId()) &&
                getImageId().equals(propertyImage.getImageId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getImageId(), getProperty().getPropertyId(), getImageUrl(), getCreatedAt());
    }
}
