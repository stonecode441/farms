package com.stargrade.fams.api.util;

import com.stargrade.fams.api.otp.OtpDto;
import com.stargrade.fams.domain.otp.model.Otp;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.ZoneId;

@Component
@RequiredArgsConstructor
public class OtpObjectMapper {
    public OtpDto toOtpDto(Otp otp) {
        OtpDto otpDto = new OtpDto();
        otpDto.setOperation(otp.getOperation().name());
        otpDto.setUserId(otp.getUserId());
        otpDto.setCreatedAt(Date.from(otp.getCreatedAt().atZone(ZoneId.systemDefault()).toInstant()));
        otpDto.setExpiryDate(Date.from(otp.getExpiry().atZone(ZoneId.systemDefault()).toInstant()));
        return otpDto;
    }
}
