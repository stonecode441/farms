package com.stargrade.fams.domain.usermanagement.model;

public enum MethodAccessPermission {
    //    Role & Permissions
    VIEW_ROLE("Ability to view roles"),
    CREATE_ROLE("Ability to create new roles"),
    EDIT_ROLE("Ability to edit roles"),
    VIEW_PERMISSION("Ability to view permissions"),
    ASSIGN_PERMISSION("Ability to assign permissions"),

    //    User
    VIEW_USER("Ability to view all users on the platform"),
    ASSIGN_USER_ROLE("Ability to assign role to user"),
    EDIT_USER("Ability to edit a user"),
    DELETE_USER("Ability to delete a user"),
    CREATE_USER("Ability to create a user"),

    //    Organization
    INVITE_ORGANIZATION("Ability to invite an organization"),
    MODIFY_ORGANIZATION("Ability to modify an organization"),
    DELETE_ORGANIZATION("Ability to delete an organization"),
    VIEW_ORGANIZATION("Ability to view an organization"),

    //    Property
    CREATE_PROPERTY("Ability to create a property"),
    UPDATE_PROPERTY("Ability to update a property"),
    DELETE_PROPERTY("Ability to delete a property"),
    VIEW_PROPERTY("Ability to view a property"),

    //    Building
    CREATE_BUILDING("Ability to create a building"),
    UPDATE_BUILDING("Ability to update a building"),
    DELETE_BUILDING("Ability to delete a building"),
    VIEW_BUILDING("Ability to view a building"),

    //    Unit
    CREATE_UNIT("Ability to create a unit"),
    UPDATE_UNIT("Ability to update a unit"),
    DELETE_UNIT("Ability to delete a unit"),
    VIEW_UNIT("Ability to view a unit"),

    //    Invite
    CREATE_INVITE("Ability to create an invite"),
    UPDATE_INVITE("Ability to update an invite"),
    VIEW_INVITE("Ability to get an unit"),
    CANCEL_INVITE("Ability to cancel an unit"),
    CHECK_IN("Ability to check in a guest"),
    CHECK_OUT("Ability to check out a guest"),

    //    Subcription
    CREATE_SUBSCRIPTION("Ability to create a subscription"),
    GET_SUBSCRIPTION("Ability to get subscription"),
    DELETE_SUBSCRIPTION("Ability to delete subscription"),
    MODIFY_SUBSCRIPTION("Ability to modify subscription"),
    CANCEL_SUBSCRIPTION("Ability to cancel subscription"),

    //    Support
    CREATE_SUPPORT_TICKET("Ability to create support ticket"),
    GET_SUPPORT_TICKET("Ability to get support ticket"),
    CLOSE_SUPPORT_TICKET("Ability to close a support ticket");

    private final String value;

    MethodAccessPermission(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}