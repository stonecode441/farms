package com.stargrade.fams.domain.unit.service;

import com.stargrade.fams.api.building.AddOccupantsRequestDto;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.api.unit.UnitRequestDto;
import com.stargrade.fams.api.unit.UpdateUnitRequestDto;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitLeaseRecord;
import com.stargrade.fams.domain.unit.model.UnitOccupant;
import com.stargrade.fams.domain.usermanagement.model.User;

import java.util.List;

public interface UnitService {
    List<UnitOccupant> getAllUnitOccupants(Unit unit);

    List<UnitOccupant> getOccupantUnits(User occupant);

    List<UnitLeaseRecord> getAllUnitLeaseRecord(Unit unit);

    List<Unit> createUnits(List<UnitRequestDto> unitRequestList);

    Unit getUnitByIdFromDb(String unitId);

    List<UnitOccupant> addOccupantsToUnit(String unitId, AddOccupantsRequestDto addOccupantsRequest);

    boolean removeOccupantsFromUnit(String buildingId, String unitId);

    UnitDto createUnit(String buildingId, UnitRequestDto unitRequest);

    UnitDto updateUnit(String buildingId, String unitId, UpdateUnitRequestDto updateUnitRequest);

    UnitDto getUnit(String buildingId, String unitId);

    List<UnitDto> getAllUnits(String buildingId);

    UnitDto deleteUnit(String buildingId, String unitId);
}
