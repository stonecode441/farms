package com.stargrade.fams.api.usermanagement;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

@Data
public class ActivateAccountRequestDto implements Serializable {
    @NotEmpty(message = "Invite code is required")
    private String inviteCode;

    @NotEmpty(message = "Phone number code is required")
    private String phoneNumber;

    private LocalDate dob;

    private String base64ProfilePhoto;

    @NotEmpty(message = "Password is required")
    @Size(min = 8, message = "Password cannot be less than eight (8) characters")
    private String password;

    @NotEmpty(message = "Confirm password is required")
    @Size(min = 8, message = "Confirm password cannot be less than eight (8) characters")
    private String confirmPassword;
}
