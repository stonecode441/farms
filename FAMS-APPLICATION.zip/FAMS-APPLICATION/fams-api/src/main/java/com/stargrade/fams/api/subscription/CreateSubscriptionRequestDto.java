package com.stargrade.fams.api.subscription;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class CreateSubscriptionRequestDto implements Serializable {
    @NotEmpty(message = "Name is required")
    private String name;
    private String description;
    @NotNull(message = "Price is required")
    private BigDecimal price;
    @NotNull(message = "Min tenants is required")
    @Min(value = 1, message = "Min tenants must be a value greater than zero (0)")
    private Integer minTenants;
    @NotNull(message = "Max tenants is required")
    @Min(value = 1, message = "Max tenants must be a value greater than zero (0)")
    private Integer maxTenants;
}
