package com.stargrade.fams.api.otp;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class OtpDto implements Serializable {
    private String operation;
    private String userId;
    private Date createdAt;
    private Date expiryDate;
}
