package com.stargrade.fams.domain.property.service;

import com.stargrade.fams.api.property.PropertyDto;
import com.stargrade.fams.api.property.PropertyRequestDto;
import com.stargrade.fams.api.property.UpdatePropertyRequestDto;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.property.model.Property;

import java.util.List;

public interface PropertyService {
    PropertyDto createProperty(String organizationId, PropertyRequestDto createPropertyRequest) throws FamsApplicationException;

    PropertyDto updateProperty(String organizationId, String propertyId, UpdatePropertyRequestDto updatePropertyRequest) throws FamsApplicationException;

    PropertyDto getProperty(String organizationId, String propertyId);

    List<PropertyDto> getAllProperties(String organizationId);

    PropertyDto deleteProperty(String organizationId, String propertyId);

    Property getPropertyByIdFromDb(String propertyId);
}
