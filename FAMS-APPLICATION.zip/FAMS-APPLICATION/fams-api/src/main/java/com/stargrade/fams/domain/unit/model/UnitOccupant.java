package com.stargrade.fams.domain.unit.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"unit_id", "occupant_id"}))
@Entity
@Getter
@Setter
@NoArgsConstructor
public class UnitOccupant extends BaseEntity {
    @ManyToOne
    private Unit unit;
    @ManyToOne
    private User occupant;

    public UnitOccupant(Unit unit, User occupant) {
        this.unit = unit;
        this.occupant = occupant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UnitOccupant unitOccupant = (UnitOccupant) o;
        return getId().equals(unitOccupant.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUnit().getUnitId(), getOccupant().getUserId());
    }
}
