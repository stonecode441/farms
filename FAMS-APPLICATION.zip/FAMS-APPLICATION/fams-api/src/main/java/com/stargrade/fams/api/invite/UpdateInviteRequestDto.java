package com.stargrade.fams.api.invite;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
public class UpdateInviteRequestDto implements Serializable {
    private String unitId;
    private String inviteCode;
    private List<InvitedGuest> invitedGuest;
    private LocalDate accessEndDate;
    private LocalDate accessStartDate;
    private InviteFrequency inviteFrequency;
}
