package com.stargrade.fams.domain.usermanagement.service.impl;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.stargrade.fams.api.usermanagement.CreateAccountRequestDto;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.UrlResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class AccountUploadService {
    public String type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private String[] fileUploadHeaders = {"First Name", "Last Name", "Email Address", "Role ID", "Unit ID", "Lease Start", "Lease End"};

    @Value("${app.uploads.dir:fams-backend/uploads}")
    private String uploadsDir;

    @Value("${aws.s3.bucket.name:custom_bucket_name}")
    private String bucketName;

    private final AmazonS3Service amazonS3Service;
    private final UserService userService;

    boolean hasExcelFormat(MultipartFile file) {
        return type.equals(file.getContentType());
    }

    void verifyExcelFormat(MultipartFile inputFile) throws IOException {
        InputStream inputStream = inputFile.getInputStream();
        Workbook workbook = new XSSFWorkbook(inputStream);

        Sheet sheet = workbook.getSheetAt(0);
        Row firstRow = sheet.getRow(0);
        int expectedCellCount = fileUploadHeaders.length;
        System.out.println("Row count: "+ firstRow.getPhysicalNumberOfCells());
        if(firstRow.getPhysicalNumberOfCells() != expectedCellCount) {
            workbook.close();
            throw new IOException("Invalid document upload format");
        }else {
            workbook.close();
        }
    }

    private File convertMultipartToFile(MultipartFile multipartFile, String fileName) throws IOException {
        File folder = new File(uploadsDir);
        if(!folder.exists())
            log.info("Folder creation status"+ folder.mkdir());
        Path path = Paths.get(uploadsDir).resolve(fileName);
        File file = new UrlResource(path.toUri()).getFile();
        try (OutputStream os = new FileOutputStream(file)) {
            os.write(multipartFile.getBytes());
        }
        return file;
    }

    public void sendForProcessing(MultipartFile multipartFile) throws FamsApplicationException {
        boolean hasFormat = this.hasExcelFormat(multipartFile);
        if (!hasFormat)
            throw new FamsApplicationException("Invalid document format. Supported formats are: CSV, XLSX, XLS");
        try {
            this.verifyExcelFormat(multipartFile);
        } catch (IOException e) {
            e.printStackTrace();
            throw new FamsApplicationException("Invalid document format. Please refer to sample document for supported format");
        }

        try {
            Map<String, String> metadata = new HashMap<>();
            metadata.put("Content-Type", multipartFile.getContentType());
            metadata.put("Content-Length", String.valueOf(multipartFile.getSize()));

            String path = String.format("%s/%s", bucketName, UUID.randomUUID());
            String fileName = String.format("%s", multipartFile.getOriginalFilename());

            PutObjectResult putObjectResult = amazonS3Service.upload(path, fileName, Optional.of(metadata), multipartFile.getInputStream());
            log.info("File uploaded. File name: {}, path: {}, version ID: {}", fileName, path, putObjectResult.getMetadata().getVersionId());
        } catch (RuntimeException | IOException ex) {
            ex.printStackTrace();
            log.error("Upload to s3 failed: ", ex);
        }

        File file;
        try {
            file = this.convertMultipartToFile(multipartFile, multipartFile.getOriginalFilename());
        } catch (IOException e) {
            e.printStackTrace();
            throw new FamsApplicationException("An error occurred while uploading file");
        }

        try {
            List<CreateAccountRequestDto> invitesToBeSent = this.convertFileToDto(file);
            inviteAccounts(invitesToBeSent);
        } catch (IOException ioe) {
            log.error("Bad file format: ", ioe);
            throw new FamsApplicationException("Bulk upload failed: " + ioe.getMessage());
        }
    }

    public List<CreateAccountRequestDto> convertFileToDto(File inputFile) throws IOException {
        FileInputStream fis = new FileInputStream(inputFile);
        Workbook workbook = new XSSFWorkbook(fis);

        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rows = sheet.iterator();

        List<CreateAccountRequestDto> contactTransferDtos = new ArrayList<>();
        DataFormatter formatter = new DataFormatter();
        int rowNumber = 0;
        while (rows.hasNext()) {
            Row currentRow = rows.next();

            if (rowNumber == 0) {
                rowNumber++;
                continue;
            }

            Iterator<Cell> cellsInRow = currentRow.iterator();

            CreateAccountRequestDto createAccountRequestDto = new CreateAccountRequestDto();
            int cellIdx = 0;
            while (cellsInRow.hasNext()) {
                Cell currentCell = cellsInRow.next();
                String value = "";
                if(formatter.formatCellValue(currentCell) != null && !formatter.formatCellValue(currentCell).trim().isEmpty())
                    value = formatter.formatCellValue(currentCell).trim().equals("N/A") ? "" : formatter.formatCellValue(currentCell);
                switch (cellIdx) {
                    case 0:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All first names must be a valid value");
                        createAccountRequestDto.setFirstName(value);
                        break;
                    case 1:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All last names must be a valid value");
                        createAccountRequestDto.setLastName(value);
                        break;
                    case 2:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All role IDs must be a valid value");
                        createAccountRequestDto.setRoleId(value);
                        break;
                    case 3:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All unit IDs must be a valid value");
                        createAccountRequestDto.setUnitId(value);
                        break;
                    case 4:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All lease start must be a valid value");
                        createAccountRequestDto.setLeaseStart(LocalDate.parse(value));
                        break;
                    case 5:
                        if(!StringUtils.isEmpty(value))
                            throw new IOException("All lease end must be a valid value");
                        createAccountRequestDto.setLeaseStart(LocalDate.parse(value));
                        break;
                    default:
                        break;
                }
                cellIdx++;
            }
            contactTransferDtos.add(createAccountRequestDto);
        }
        workbook.close();
        return contactTransferDtos;
    }

    @Async
    public void inviteAccounts(List<CreateAccountRequestDto> invitesToBeSent) {
        invitesToBeSent.forEach(accountInvite -> {
            try {
                userService.createAccount(accountInvite);
            }catch (Exception ex) {
                log.error(String.format("Failed to invite account: %s", accountInvite.getEmailAddress()), ex);
            }
        });
    }
}
