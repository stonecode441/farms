package com.stargrade.fams.api.unit;

import lombok.Data;

import java.io.Serializable;

@Data
public class UpdateUnitRequestDto implements Serializable {
    private String unitNo;
    private UnitType unitType;
    private Integer unitSize;
    private Integer maxOccupants;
    private Integer rent;
}
