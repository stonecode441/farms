package com.stargrade.fams.api.property;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PropertyType {

    RESIDENTIAL("RS"),CLUB("CL"), FACILITY("FL"),OFFICE("OF");

    private final String type;

    PropertyType(String type) {
        this.type = type;
    }

    @JsonValue
    public String getType() {
        return type;
    }
}
