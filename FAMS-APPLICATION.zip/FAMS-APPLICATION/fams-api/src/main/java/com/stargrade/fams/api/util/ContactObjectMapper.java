package com.stargrade.fams.api.util;

import com.stargrade.fams.api.organization.ContactDto;
import com.stargrade.fams.domain.contact.model.Contact;
import org.springframework.stereotype.Component;

@Component
public class ContactObjectMapper {
    public ContactDto toContactDto(Contact contact) {
        ContactDto contactDto = new ContactDto();
        contactDto.setFirstName(contact.getFirstName());
        contactDto.setLastName(contact.getLastName());
        contactDto.setEmail(contact.getEmail());
        contactDto.setPhoneNumber(contact.getPhoneNumber());
        return contactDto;
    }
}
