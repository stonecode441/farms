package com.stargrade.fams.api.userprofile;

import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("${app.route.prefix}/user-profile")
@RestController
@RequiredArgsConstructor
public class UserProfileController {
    private final UserService userService;

    @Operation(summary = "Update profile")
    @PutMapping
    public ResponseEntity<ApiResponse<UserDto>> update(@RequestBody UpdateProfileRequestDto updateProfileRequest) {
        return ResponseEntity.ok(new ApiResponse<>("User profile updated successfully", userService.updateProfile(updateProfileRequest)));
    }

    @Operation(summary = "Add profile photo")
    @PostMapping("/add-profile-photo")
    public ResponseEntity<ApiResponse<UserDto>> addProfilePhoto(@Valid @RequestBody AddProfilePhotoRequestDto addProfilePhotoRequest) throws FamsApplicationException {
        return ResponseEntity.ok(new ApiResponse<>("Profile photo added successfully", userService.addProfilePhoto(addProfilePhotoRequest)));
    }

    @Operation(summary = "Remove profile photo")
    @DeleteMapping("/remove-profile-photo")
    public ResponseEntity<ApiResponse<UserDto>> removeProfilePhoto() {
        return ResponseEntity.ok(new ApiResponse<>("Profile photo removed successfully", userService.removeProfilePhoto()));
    }
}
