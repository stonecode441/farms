package com.stargrade.fams.api.userprofile;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class AddProfilePhotoRequestDto implements Serializable {
    @NotEmpty(message = "Base 64 Image is required")
    private String base64Image;
}
