package com.stargrade.fams.api.subscription;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class SubscriptionDto implements Serializable {
    private String subscriptionId;
    private String name;
    private String description;
    private BigDecimal price;
    private Integer minTenants;
    private Integer maxTenants;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
