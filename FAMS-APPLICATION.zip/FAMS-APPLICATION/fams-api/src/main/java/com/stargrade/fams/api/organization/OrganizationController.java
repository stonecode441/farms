package com.stargrade.fams.api.organization;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.organization.service.OrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/organizations")
@RestController
@RequiredArgsConstructor
public class OrganizationController {
    private final OrganizationService organizationService;

    @Operation(summary = "Invite an organization")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).INVITE_ORGANIZATION)")
    public ResponseEntity<ApiResponse<OrganizationDto>> inviteOrganization(@Valid @RequestBody OrganizationRequestDto organizationRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Organization invited successfully", organizationService.inviteOrganization(organizationRequest)));
    }

    @Operation(summary = "Update an organization")
    @PutMapping("/{organizationId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_ORGANIZATION)")
    public ResponseEntity<ApiResponse<OrganizationDto>> updateOrganization(@PathVariable String organizationId, @Valid @RequestBody OrganizationRequestDto organizationRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Organization updated successfully", organizationService.updateOrganization(organizationId, organizationRequest)));
    }

    @Operation(summary = "Deactivate an organization")
    @PatchMapping("/deactivate/{organizationId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).MODIFY_ORGANIZATION)")
    public ResponseEntity<ApiResponse<OrganizationDto>> deactivateOrganization(@PathVariable String organizationId) {
        return ResponseEntity.ok(new ApiResponse<>("Organization deactivated successfully", organizationService.deactivateOrganization(organizationId)));
    }

    @Operation(summary = "Activate an organization")
    @PatchMapping("/activate/{organizationId}")
    public ResponseEntity<ApiResponse<OrganizationDto>> activateOrganization(@PathVariable String organizationId) {
        return ResponseEntity.ok(new ApiResponse<>("Organization activated successfully", organizationService.activateOrganization(organizationId)));
    }

    @Operation(summary = "View an organization")
    @GetMapping("/{organizationId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_ORGANIZATION)")
    public ResponseEntity<ApiResponse<OrganizationDto>> viewOrganization(@PathVariable String organizationId) {
        return ResponseEntity.ok(new ApiResponse<>("Organization retrieved successfully", organizationService.viewOrganization(organizationId)));
    }

    @Operation(summary = "View a list of organizations")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_ORGANIZATION)")
    public ResponseEntity<ApiResponse<List<OrganizationDto>>> viewOrganizations(@RequestParam(required = false) Integer pageNumber, @RequestParam(required = false) Integer pageSize) {
        return ResponseEntity.ok(new ApiResponse<>("Organization retrieved successfully", organizationService.viewOrganizations(pageNumber, pageSize)));
    }

    @Operation(summary = "Delete an organization")
    @DeleteMapping("/{organizationId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_ORGANIZATION)")
    public ResponseEntity<ApiResponse<OrganizationDto>> deleteOrganization(@PathVariable String organizationId) {
        return ResponseEntity.ok(new ApiResponse<>("Organization deleted successfully", organizationService.deleteOrganization(organizationId)));
    }
}
