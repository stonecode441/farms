package com.stargrade.fams.domain.contact.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.organization.model.Organization;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Contact extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String contactId;
    private String firstName;
    private String lastName;
    @Column(unique = true)
    private String email;
    private String phoneNumber;

    public Contact(String contactId, String firstName, String lastName, String email, String phoneNumber) {
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact obj = (Contact) o;
        return getId().equals(obj.getId()) &&
                getContactId().equals(obj.getContactId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getContactId(), getEmail());
    }
}
