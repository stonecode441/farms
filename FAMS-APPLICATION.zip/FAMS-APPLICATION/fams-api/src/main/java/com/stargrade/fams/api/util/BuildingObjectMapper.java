package com.stargrade.fams.api.util;

import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.domain.building.model.Building;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BuildingObjectMapper {
    public BuildingDto toBuildingDto(Building building, List<UnitDto> unitDtoList) {
        BuildingDto buildingDto = new BuildingDto();
        buildingDto.setId(building.getBuildingId());
        buildingDto.setBuildingSize(building.getBuildingSize());
        buildingDto.setBuildingType(building.getBuildingType());
        buildingDto.setName(building.getName());
        buildingDto.setPropertyId(building.getProperty().getPropertyId());
        buildingDto.setNoOfFloors(building.getNoOfFloors());
        buildingDto.setUnits(unitDtoList);
        buildingDto.setCreatedAt(building.getCreatedAt());
        buildingDto.setUpdatedAt(building.getUpdatedAt());
        buildingDto.setDeletedAt(building.getDeletedAt());
        return buildingDto;
    }
}
