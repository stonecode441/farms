package com.stargrade.fams.api.otp;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ValidateOtpRequestDto implements Serializable {
    @NotEmpty(message = "OTP is required")
    private String otp;
    @NotEmpty(message = "User ID is required")
    private String userId;
}
