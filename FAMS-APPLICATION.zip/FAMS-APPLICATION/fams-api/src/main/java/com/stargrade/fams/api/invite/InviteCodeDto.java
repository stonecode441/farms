package com.stargrade.fams.api.invite;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class InviteCodeDto implements Serializable {
    private String code;
    private LocalDateTime expiresIn;
}
