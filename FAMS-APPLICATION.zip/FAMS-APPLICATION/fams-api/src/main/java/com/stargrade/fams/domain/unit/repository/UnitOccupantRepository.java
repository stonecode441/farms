package com.stargrade.fams.domain.unit.repository;

import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitOccupant;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UnitOccupantRepository extends JpaRepository<UnitOccupant, Long> {
    List<UnitOccupant> findAllByUnit(Unit unit);

    List<UnitOccupant> findAllByOccupant(User occupant);

    @Transactional
    @Modifying
    @Query("DELETE FROM UnitOccupant k WHERE k.unit.id =:unitId")
    void deleteAllByUnitId(@Param("unitId") Long unitId);
}
