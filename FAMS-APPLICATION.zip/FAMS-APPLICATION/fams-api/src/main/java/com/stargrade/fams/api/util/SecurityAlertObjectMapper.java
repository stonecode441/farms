package com.stargrade.fams.api.util;

import com.stargrade.fams.api.securityalert.SecurityAlertDto;
import com.stargrade.fams.domain.security.model.SecurityAlert;
import org.springframework.stereotype.Component;

@Component
public class SecurityAlertObjectMapper {
    public SecurityAlertDto toSecurityAlertDto(SecurityAlert securityAlert){
        SecurityAlertDto securityAlertDto = new SecurityAlertDto();
        securityAlertDto.setAlertId(securityAlert.getAlertId());
        securityAlertDto.setCreatedAt(securityAlert.getCreatedAt());
        securityAlertDto.setDeletedAt(securityAlert.getDeletedAt());
        securityAlertDto.setIsRead(securityAlert.getIsRead());
        securityAlertDto.setMessage(securityAlert.getMessage());
        securityAlertDto.setUserId(securityAlert.getUser().getUserId());
        return securityAlertDto;

    }
}
