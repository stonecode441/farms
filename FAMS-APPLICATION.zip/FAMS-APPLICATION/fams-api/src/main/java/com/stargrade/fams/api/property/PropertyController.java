package com.stargrade.fams.api.property;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.property.service.PropertyService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/organizations/{organizationId}/properties")
@RestController
@RequiredArgsConstructor
public class PropertyController {
    private final PropertyService propertyService;

    @Operation(summary = "Create a property")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_PROPERTY)")
    public ResponseEntity<ApiResponse<PropertyDto>> createProperty(@PathVariable String organizationId, @Valid @RequestBody PropertyRequestDto createPropertyRequest) throws FamsApplicationException {
        return ResponseEntity.ok(new ApiResponse<>("Property created successfully", propertyService.createProperty(organizationId, createPropertyRequest)));
    }

    @Operation(summary = "Update a property")
    @PutMapping("/{propertyId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).UPDATE_PROPERTY)")
    public ResponseEntity<ApiResponse<PropertyDto>> updateProperty(@PathVariable String organizationId, @PathVariable String propertyId, @Valid @RequestBody UpdatePropertyRequestDto updatePropertyRequest) throws FamsApplicationException {
        return ResponseEntity.ok(new ApiResponse<>("Property updated successfully", propertyService.updateProperty(organizationId, propertyId, updatePropertyRequest)));
    }

    @Operation(summary = "Get a property")
    @GetMapping("/{propertyId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_PROPERTY)")
    public ResponseEntity<ApiResponse<PropertyDto>> getProperty(@PathVariable String organizationId, @PathVariable String propertyId) {
        return ResponseEntity.ok(new ApiResponse<>("Property retrieved successfully", propertyService.getProperty(organizationId, propertyId)));
    }

    @Operation(summary = "Get a list of properties")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_PROPERTY)")
    public ResponseEntity<ApiResponse<List<PropertyDto>>> getListOfProperties(@PathVariable String organizationId) {
        return ResponseEntity.ok(new ApiResponse<>("Properties retrieved successfully", propertyService.getAllProperties(organizationId)));
    }

    @Operation(summary = "Delete a property")
    @DeleteMapping("/{propertyId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).DELETE_PROPERTY)")
    public ResponseEntity<ApiResponse<PropertyDto>> deleteProperty(@PathVariable String organizationId, @PathVariable String propertyId) {
        return ResponseEntity.ok(new ApiResponse<>("Property deleted successfully", propertyService.deleteProperty(organizationId, propertyId)));
    }
}
