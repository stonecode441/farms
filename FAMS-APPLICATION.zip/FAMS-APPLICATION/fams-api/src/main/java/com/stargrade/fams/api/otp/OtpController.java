package com.stargrade.fams.api.otp;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.otp.service.OtpService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("${app.route.prefix}/otp")
@RestController
@RequiredArgsConstructor
public class OtpController {
    private final OtpService otpService;

    @Operation(summary = "Send one time password")
    @PostMapping
    public ResponseEntity<ApiResponse<OtpDto>> sendOtp(@Valid @RequestBody SendOtpRequestDto sendOtpRequest) {
        return ResponseEntity.ok(new ApiResponse<>("OTP sent out successfully", otpService.sendOtp(sendOtpRequest)));
    }

    @Operation(summary = "Validate one time password")
    @PostMapping("/validate")
    public ResponseEntity<ApiResponse<Boolean>> validateOtp(@Valid @RequestBody ValidateOtpRequestDto validateOtpRequest) {
        return ResponseEntity.ok(new ApiResponse<>("OTP validated successfully", otpService.validateOtp(validateOtpRequest)));
    }
}
