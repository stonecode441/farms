package com.stargrade.fams.api.support;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.io.Serializable;

@Data
public class SupportMessageRequestDto implements Serializable {
    @NotEmpty(message = "Support message is required")
    private String message;
}
