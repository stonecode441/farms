package com.stargrade.fams.api.util;

import com.stargrade.fams.api.unit.LeaseRecord;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitLeaseRecord;
import com.stargrade.fams.domain.usermanagement.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UnitObjectMapper {
    private final UserManagementObjectMapper userManagementObjectMapper;

    public UnitDto toUnitDto(Unit unit, List<User> currentOccupants, List<UnitLeaseRecord> leaseRecordList) {
        UnitDto unitDto = new UnitDto();
        unitDto.setId(unit.getUnitId());
        unitDto.setUnitNo(unit.getUnitNo());
        unitDto.setUnitSize(unit.getUnitSize());
        unitDto.setMaxOccupants(unit.getMaxOccupants());
        unitDto.setLeaseStart(unit.getLeaseStart());
        unitDto.setLeaseEnd(unit.getLeaseEnd());
        unitDto.setRent(unitDto.getRent());
        unitDto.setPrimaryMemberEmail(unit.getPrimaryMemberEmail());
        unitDto.setPrimaryMemberFirstName(unit.getPrimaryMemberFirstName());
        unitDto.setPrimaryMemberLastName(unit.getPrimaryMemberLastName());

        if(currentOccupants != null && !currentOccupants.isEmpty()) {
            unitDto.setCurrentOccupants(
                    currentOccupants
                            .stream()
                            .map(userManagementObjectMapper::toUserDto)
                            .collect(Collectors.toList())
            );
        }

        if (leaseRecordList != null && !leaseRecordList.isEmpty()) {
            unitDto.setLeaseRecord(
                    leaseRecordList
                            .stream()
                            .map(lr -> {
                                List<UnitLeaseRecord> filteredTenantList = filterLeaseRecordByTenant(leaseRecordList, lr.getTenant());
                                return new LeaseRecord(
                                        lr.getStartDate(),
                                        lr.getEndDate(),
                                        filteredTenantList
                                                .stream()
                                                .map(ftl -> userManagementObjectMapper.toUserDto(ftl.getTenant()))
                                                .collect(Collectors.toList())
                                );
                            })
                            .collect(Collectors.toList())
            );
        }

        unitDto.setCreatedAt(unit.getCreatedAt());
        unitDto.setUpdatedAt(unit.getUpdatedAt());
        unitDto.setDeletedAt(unit.getDeletedAt());

        return unitDto;
    }

    List<UnitLeaseRecord> filterLeaseRecordByTenant(List<UnitLeaseRecord> leaseRecordList, User tenant) {
        return leaseRecordList.stream().filter(lr -> lr.getTenant().equals(tenant)).collect(Collectors.toList());
    }
}
