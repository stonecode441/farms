package com.stargrade.fams.api.support;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class SupportDto implements Serializable {
    private String ticketId;
    private List<SupportThreadDto> supportThread;
    private Boolean isClosed;
    private Date createdAt;
    private Date closedAt;
}
