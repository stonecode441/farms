package com.stargrade.fams.domain.usermanagement.model;

public enum DefaultRole {
    SUPER_ADMIN, ADMIN, SECURITY, MEMBER
}
