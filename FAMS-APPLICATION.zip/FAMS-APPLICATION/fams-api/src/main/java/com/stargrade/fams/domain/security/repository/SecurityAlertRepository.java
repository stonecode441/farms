package com.stargrade.fams.domain.security.repository;

import com.stargrade.fams.domain.security.model.SecurityAlert;
import com.stargrade.fams.domain.usermanagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SecurityAlertRepository extends JpaRepository<SecurityAlert,Long> {
    Optional<SecurityAlert> findByAlertId(String alertId);

    List<SecurityAlert> findAllByUserAndDeletedAtIsNull(User user);

    @Query("UPDATE SecurityAlert k SET k.deletedAt = current_timestamp WHERE k.user =:user")
    void deleteAllByUser(@Param("user") User user);
}
