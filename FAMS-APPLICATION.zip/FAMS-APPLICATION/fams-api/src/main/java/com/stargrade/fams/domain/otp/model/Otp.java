package com.stargrade.fams.domain.otp.model;

import com.stargrade.fams.domain.usermanagement.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Otp {
    private OtpOperation operation;
    private String userId;
    private String code;
    private LocalDateTime createdAt;
    private LocalDateTime expiry;
}
