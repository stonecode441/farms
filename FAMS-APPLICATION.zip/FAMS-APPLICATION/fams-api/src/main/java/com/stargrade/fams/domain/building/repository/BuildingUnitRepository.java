package com.stargrade.fams.domain.building.repository;

import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.building.model.BuildingUnit;
import com.stargrade.fams.domain.unit.model.Unit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BuildingUnitRepository extends JpaRepository<BuildingUnit, Long> {
    List<BuildingUnit> findAllByBuilding(Building building);

    Optional<BuildingUnit> findByBuildingAndUnit(Building building, Unit unit);

    @Query("SELECT COUNT(k) from BuildingUnit k WHERE k.building.property.organization.id =:organizationId")
    Long countAllByOrganization(@Param("organizationId") String organizationId);
}
