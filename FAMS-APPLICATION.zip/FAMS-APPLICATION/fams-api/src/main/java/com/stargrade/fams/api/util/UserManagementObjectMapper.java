package com.stargrade.fams.api.util;

import com.stargrade.fams.api.permission.PermissionDto;
import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.usermanagement.PendingUserDto;
import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.domain.usermanagement.model.PendingUser;
import com.stargrade.fams.domain.usermanagement.model.Permission;
import com.stargrade.fams.domain.usermanagement.model.Role;
import com.stargrade.fams.domain.usermanagement.model.User;
import org.springframework.stereotype.Component;

@Component
public class UserManagementObjectMapper {
    public PermissionDto toPermissionDto(Permission permission) {
        PermissionDto permissionDto = new PermissionDto();
        permissionDto.setPermissionId(permission.getPermissionId());
        permissionDto.setPermissionName(permission.getName());
        permissionDto.setDescription(permission.getDescription());
        permissionDto.setCreatedAt(permission.getCreatedAt());
        permissionDto.setUpdatedAt(permission.getUpdatedAt());
        permissionDto.setDeletedAt(permission.getDeletedAt());
        return permissionDto;
    }

    public RoleDto toRoleDto(Role role) {
        RoleDto roleDto = new RoleDto();
        roleDto.setRoleId(role.getRoleId());
        roleDto.setRoleName(role.getRoleName());
        roleDto.setDescription(role.getDescription());
        roleDto.setIsActive(role.getIsActive());
        roleDto.setCreatedAt(role.getCreatedAt());
        roleDto.setUpdatedAt(role.getUpdatedAt());
        roleDto.setDeletedAt(role.getDeletedAt());
        return roleDto;
    }

    public PendingUserDto toPendingUserDto(PendingUser pendingUser) {
        PendingUserDto pendingUserDto = new PendingUserDto();
        pendingUserDto.setUserId(pendingUser.getUserId());
        pendingUserDto.setRoleId(pendingUser.getRoleId());
        pendingUserDto.setUnitId(pendingUser.getUnitId());
        pendingUserDto.setLeaseStart(pendingUser.getLeaseStart());
        pendingUserDto.setLeaseEnd(pendingUser.getLeaseEnd());
        pendingUserDto.setInviteCode(pendingUser.getInviteCode());
        pendingUserDto.setEmailAddress(pendingUser.getEmailAddress());
        pendingUserDto.setFirstName(pendingUser.getFirstName());
        pendingUserDto.setLastName(pendingUser.getLastName());
        pendingUserDto.setCreatedAt(pendingUser.getCreatedAt());
        pendingUserDto.setUpdatedAt(pendingUser.getUpdatedAt());
        pendingUserDto.setDeletedAt(pendingUser.getDeletedAt());
        return pendingUserDto;
    }

    public UserDto toUserDto(User user) {
        UserDto userDto = new UserDto();
        userDto.setUserId(user.getUserId());
        userDto.setDob(user.getDob());
        userDto.setRole(this.toRoleDto(user.getRole()));
        userDto.setEmailAddress(user.getEmailAddress());
        userDto.setProfilePhotoFormat(user.getProfilePhotoFormat());
        userDto.setProfilePhotoUrl(user.getProfilePhotoUrl());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setIsDisabled(user.getIsDisabled());
        userDto.setPhoneNumber(user.getPhoneNumber());
        userDto.setCreatedAt(user.getCreatedAt());
        userDto.setUpdatedAt(user.getUpdatedAt());
        userDto.setDeletedAt(user.getDeletedAt());
        return userDto;
    }
}
