package com.stargrade.fams.domain.usermanagement.service.impl;

import com.stargrade.fams.api.permission.PermissionDto;
import com.stargrade.fams.api.permission.PermissionRequestDto;
import com.stargrade.fams.api.permission.RolePermissionDto;
import com.stargrade.fams.domain.usermanagement.model.Permission;
import com.stargrade.fams.domain.usermanagement.model.Role;
import com.stargrade.fams.domain.usermanagement.model.RolePermission;
import com.stargrade.fams.domain.usermanagement.repository.PermissionRepository;
import com.stargrade.fams.domain.usermanagement.repository.RolePermissionRepository;
import com.stargrade.fams.domain.usermanagement.service.PermissionService;
import com.stargrade.fams.domain.usermanagement.service.RoleService;
import com.stargrade.fams.api.util.UserManagementObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PermissionServiceImpl implements PermissionService {
    private final PermissionRepository permissionRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final RoleService roleService;
    private final UserManagementObjectMapper mapper;

    @Override
    public List<PermissionDto> getAllPermissions() {
        return permissionRepository
                .findAll()
                .stream()
                .map(mapper::toPermissionDto)
                .collect(Collectors.toList());
    }

    @Override
    public RolePermissionDto manageRolePermissions(PermissionRequestDto rolePermissionRequest, boolean isRemove) {
        Role role = roleService.getDbRole(rolePermissionRequest.getRoleId());
        List<Permission> permissionList = new ArrayList<>();
        for(var permissionId : rolePermissionRequest.getPermissionIds()) {
            Optional<Permission> permission = permissionRepository.findByPermissionIdAndDeletedAtIsNull(permissionId);
            // Skip invalid permission IDs
            permission.ifPresent(permissionList::add);
        }

        return !isRemove ?
                this.addRolePermissions(permissionList, role) :
                this.removeRolePermissions(permissionList, role);
    }

    RolePermissionDto addRolePermissions(List<Permission> permissionList, Role role) {
        permissionList.forEach(p -> {
            Optional<RolePermission> rolePermission = rolePermissionRepository.findByRoleAndPermission(role, p);
            if(rolePermission.isEmpty())
                rolePermissionRepository.save(new RolePermission(role, p));
        });

        return new RolePermissionDto(
                role.getRoleName(),
                permissionList
                        .stream()
                        .map(mapper::toPermissionDto)
                        .collect(Collectors.toList())
        );
    }

    RolePermissionDto removeRolePermissions(List<Permission> permissionList, Role role) {
        permissionList.forEach(p -> {
            Optional<RolePermission> rolePermission = rolePermissionRepository.findByRoleAndPermission(role, p);
            rolePermission.ifPresent(rolePermissionRepository::delete);
        });

        return new RolePermissionDto(
                role.getRoleName(),
                rolePermissionRepository.findAllByRole(role)
                        .stream()
                        .map(rp -> mapper.toPermissionDto(rp.getPermission()))
                        .collect(Collectors.toList())
        );
    }
}
