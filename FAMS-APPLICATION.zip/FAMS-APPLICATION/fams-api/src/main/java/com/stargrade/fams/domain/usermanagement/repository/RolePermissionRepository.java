package com.stargrade.fams.domain.usermanagement.repository;

import com.stargrade.fams.domain.usermanagement.model.Permission;
import com.stargrade.fams.domain.usermanagement.model.Role;
import com.stargrade.fams.domain.usermanagement.model.RolePermission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RolePermissionRepository extends JpaRepository<RolePermission, Long> {
    List<RolePermission> findAllByRole(Role role);

    Optional<RolePermission> findByRoleAndPermission(Role role, Permission permission);
}
