package com.stargrade.fams.domain.setting.service.impl;

import com.stargrade.fams.api.membersetting.MemberSettingDto;
import com.stargrade.fams.api.membersetting.UpdateNotificationRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.setting.model.Setting;
import com.stargrade.fams.domain.setting.repository.SettingRepository;
import com.stargrade.fams.domain.setting.service.SettingService;
import com.stargrade.fams.api.util.SettingObjectMapper;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class SettingServiceImpl implements SettingService {
    private final SettingRepository settingRepository;
    private final UserService userService;
    private final SettingObjectMapper mapper;

    Setting getUserSetting() {
        User signedInUser = userService.getUserFromSession();
        Optional<Setting> memberSettingFromDb = settingRepository.findByUser(signedInUser);
        if(memberSettingFromDb.isEmpty())
            throw new ValidationException(String.format("No setting found for user with Id: %s ", signedInUser.getUserId()));
        return memberSettingFromDb.get();
    }

    @Override
    public MemberSettingDto updateNotificationSettings(UpdateNotificationRequestDto updateNotificationRequest){
        Setting setting = getUserSetting();
        setting.setEmailNotificationEnabled(updateNotificationRequest.getEmailNotificationEnabled());
        setting.setInAppNotificationEnabled(updateNotificationRequest.getInAppNotificationEnabled());
        setting.setSmsNotificationEnabled(updateNotificationRequest.getSmsNotificationEnabled());

        return mapper.toMemberSettingDto(settingRepository.save(setting));
    }

    @Override
    public MemberSettingDto toggleDarkMode(String action) {
        if(StringUtils.isEmpty(action))
            throw new ValidationException("Action cannot be null");
        if(action.equalsIgnoreCase("ON") || action.equalsIgnoreCase("OFF"))
            throw new ValidationException("Invalid action provided");

        Setting setting = getUserSetting();
        setting.setDarkModeEnabled(action.equalsIgnoreCase("ON"));

        return mapper.toMemberSettingDto(settingRepository.save(setting));
    }

    @Override
    public MemberSettingDto toggleSecurityAlert(String action) {
        if(StringUtils.isEmpty(action))
            throw new ValidationException("Action cannot be null");
        if(action.equalsIgnoreCase("ON") || action.equalsIgnoreCase("OFF"))
            throw new ValidationException("Invalid action provided");

        Setting setting = getUserSetting();
        setting.setSubscribedToSecurityAlert(action.equalsIgnoreCase("ON"));

        return mapper.toMemberSettingDto(settingRepository.save(setting));
    }
}
