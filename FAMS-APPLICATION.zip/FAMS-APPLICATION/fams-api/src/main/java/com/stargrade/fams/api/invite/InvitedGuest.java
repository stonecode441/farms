package com.stargrade.fams.api.invite;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class InvitedGuest implements Serializable {
    private String id;
    private String firstName;
    private String lastName;
    private Gender gender;
    private String phoneNo;
    private Boolean isDissallowed;
    private Date checkedIn;
    private Date checkedOut;
}
