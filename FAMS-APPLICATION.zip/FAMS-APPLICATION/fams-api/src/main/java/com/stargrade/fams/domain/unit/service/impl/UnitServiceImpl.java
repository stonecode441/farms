package com.stargrade.fams.domain.unit.service.impl;

import com.stargrade.fams.api.building.AddOccupantsRequestDto;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.api.unit.UnitRequestDto;
import com.stargrade.fams.api.unit.UpdateUnitRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.building.model.BuildingUnit;
import com.stargrade.fams.domain.building.service.BuildingService;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitLeaseRecord;
import com.stargrade.fams.domain.unit.model.UnitOccupant;
import com.stargrade.fams.domain.unit.repository.UnitLeaseRecordRepository;
import com.stargrade.fams.domain.unit.repository.UnitOccupantRepository;
import com.stargrade.fams.domain.unit.repository.UnitRepository;
import com.stargrade.fams.domain.unit.service.UnitService;
import com.stargrade.fams.api.util.UnitObjectMapper;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UnitServiceImpl implements UnitService {
    private final UnitRepository unitRepository;
    private final UnitOccupantRepository unitOccupantRepository;
    private final UnitLeaseRecordRepository unitLeaseRecordRepository;
    private final UnitObjectMapper unitObjectMapper;
    private UserService userService;
    private final BuildingService buildingService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public List<UnitOccupant> getAllUnitOccupants(Unit unit) {
        Objects.requireNonNull(unit, "Unit cannot be null");
        return unitOccupantRepository.findAllByUnit(unit);
    }

    @Override
    public List<UnitOccupant> getOccupantUnits(User occupant) {
        Objects.requireNonNull(occupant, "Occupant cannot be null");
        return unitOccupantRepository.findAllByOccupant(occupant);
    }

    @Override
    public List<UnitLeaseRecord> getAllUnitLeaseRecord(Unit unit) {
        Objects.requireNonNull(unit, "Unit cannot be null");
        return unitLeaseRecordRepository.findAllByUnit(unit);
    }

    @Override
    public List<Unit> createUnits(List<UnitRequestDto> unitRequestList) {
        Objects.requireNonNull(unitRequestList, "List of units are required");
        List<Unit> createdUnits = new ArrayList<>();
        unitRequestList.forEach(u -> {
            Unit unit = unitRepository.save(new Unit(CodeGenerator.generateUUID(), u.getUnitNo(), u.getUnitType(), u.getUnitSize(), u.getMaxOccupants(), u.getRent()));
            createdUnits.add(unit);
        });
        return createdUnits;
    }

    @Override
    public Unit getUnitByIdFromDb(String unitId) {
        Optional<Unit> unit = unitRepository.findByUnitIdAndDeletedAtIsNull(unitId);
        if(unit.isEmpty())
            throw new ValidationException(String.format("Unit with id: %s does not exist", unitId));
        return unit.get();
    }

    @Override
    public List<UnitOccupant> addOccupantsToUnit(String unitId, AddOccupantsRequestDto addOccupantsRequest) {
        Unit unit = getUnitByIdFromDb(unitId);
        List<String> unitMembers = addOccupantsRequest.getMembersIds();
        if(!unitMembers.contains(addOccupantsRequest.getPrimaryMemberId()))
            throw new ValidationException("Primary member not present in unit members list");

        List<UnitOccupant> unitOccupants = new ArrayList<>();
        unitMembers.forEach(member -> {
            try {
                User occupant = userService.getUserByIdFromDb(member);
                unitOccupants.add(new UnitOccupant(unit, occupant));
            }catch (ValidationException ve) {
                log.error("Validation Exception: ", ve);
            }
        });

        unit.setLeaseStart(addOccupantsRequest.getLeaseStart());
        unit.setLeaseEnd(addOccupantsRequest.getLeaseEnd());

        User primaryMember = userService.getUserByIdFromDb(addOccupantsRequest.getPrimaryMemberId());
        unit.setPrimaryMemberEmail(primaryMember.getEmailAddress());
        unit.setPrimaryMemberFirstName(primaryMember.getFirstName());
        unit.setPrimaryMemberLastName(primaryMember.getLastName());
        unitRepository.save(unit);

        return unitOccupants;
    }

    @Override
    public boolean removeOccupantsFromUnit(String buildingId, String unitId) {
        buildingService.getBuildingByIdFromDb(buildingId);
        Unit unit = getUnitByIdFromDb(unitId);
        List<UnitOccupant> unitOccupants = getAllUnitOccupants(unit);

        unitOccupantRepository.deleteAllByUnitId(unit.getId());
        unit.setLeaseStart(null);
        unit.setLeaseEnd(null);
        unit.setPrimaryMemberEmail(null);
        unit.setPrimaryMemberFirstName(null);
        unit.setPrimaryMemberLastName(null);
        unitRepository.save(unit);

        List<UnitLeaseRecord> unitLeaseRecordList = new ArrayList<>();
        unitOccupants.forEach(unitOccupant -> {
            unitLeaseRecordList.add(new UnitLeaseRecord(unit.getLeaseStart(), unit.getLeaseEnd(), unitOccupant.getUnit(), unitOccupant.getOccupant()));
        });
        unitLeaseRecordRepository.saveAll(unitLeaseRecordList);

        return true;
    }

    @Override
    public UnitDto createUnit(String buildingId, UnitRequestDto unitRequest) {
        Building building = buildingService.getBuildingByIdFromDb(buildingId);
        Unit unit = unitRepository.save(new Unit(
                CodeGenerator.generateUUID(),
                unitRequest.getUnitNo(),
                unitRequest.getUnitType(),
                unitRequest.getUnitSize(),
                unitRequest.getMaxOccupants(),
                unitRequest.getRent()
        ));
        buildingService.createBuildingUnit(building, unit);
        return unitObjectMapper.toUnitDto(unit, new ArrayList<>(), new ArrayList<>());
    }

    @Override
    public UnitDto updateUnit(String buildingId, String unitId, UpdateUnitRequestDto updateUnitRequest) {
        Unit unit = getUnitByIdFromDb(unitId);
        buildingService.getBuildingUnit(buildingId, unit);

        if(!StringUtils.isEmpty(updateUnitRequest.getUnitNo()))
            unit.setUnitNo(updateUnitRequest.getUnitNo());
        if(updateUnitRequest.getUnitSize() != null)
            unit.setUnitSize(updateUnitRequest.getUnitSize());
        if(updateUnitRequest.getUnitType() != null)
            unit.setUnitType(updateUnitRequest.getUnitType());
        if(updateUnitRequest.getRent() != null)
            unit.setRent(updateUnitRequest.getRent());
        if(updateUnitRequest.getMaxOccupants() != null)
            unit.setMaxOccupants(updateUnitRequest.getMaxOccupants());

        return getDetailedUnit(unitRepository.save(unit));
    }

    UnitDto getDetailedUnit(Unit unit) {
        return unitObjectMapper.toUnitDto(
                unit,
                getAllUnitOccupants(unit)
                        .stream()
                        .map(UnitOccupant::getOccupant)
                        .collect(Collectors.toList()),
                getAllUnitLeaseRecord(unit)
        );
    }

    @Override
    public UnitDto getUnit(String buildingId, String unitId) {
        Unit unit = getUnitByIdFromDb(unitId);
        buildingService.getBuildingUnit(buildingId, unit);
        return getDetailedUnit(unit);
    }

    @Override
    public List<UnitDto> getAllUnits(String buildingId) {
        List<BuildingUnit> buildingUnits = buildingService.getAllBuildingUnits(buildingId);
        return buildingUnits
                .stream()
                .map(bu -> getDetailedUnit(bu.getUnit()))
                .collect(Collectors.toList());
    }

    @Override
    public UnitDto deleteUnit(String buildingId, String unitId) {
        Unit unit = getUnitByIdFromDb(unitId);
        buildingService.getBuildingUnit(buildingId, unit);
        unit.setDeletedAt(new Date());
        return unitObjectMapper.toUnitDto(
                unitRepository.save(unit),
                new ArrayList<>(),
                new ArrayList<>()
        );
    }
}