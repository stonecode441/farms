package com.stargrade.fams.api.util;

import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.building.BuildingType;
import com.stargrade.fams.api.invite.InviteCodeDto;
import com.stargrade.fams.api.invite.InviteDto;
import com.stargrade.fams.api.invite.InviteFrequency;
import com.stargrade.fams.api.invite.InvitedGuest;
import com.stargrade.fams.api.membersetting.MemberSettingDto;
import com.stargrade.fams.api.organization.AddressDto;
import com.stargrade.fams.api.organization.ContactDto;
import com.stargrade.fams.api.organization.OrganizationDto;
import com.stargrade.fams.api.otp.OtpDto;
import com.stargrade.fams.api.permission.PermissionDto;
import com.stargrade.fams.api.property.PropertyDto;
import com.stargrade.fams.api.property.PropertyImageDto;
import com.stargrade.fams.api.property.PropertyType;
import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.securityalert.SecurityAlertDto;
import com.stargrade.fams.api.subscription.SubscriptionDto;
import com.stargrade.fams.api.support.SupportDto;
import com.stargrade.fams.api.support.SupportThreadDto;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.api.unit.UnitType;
import com.stargrade.fams.api.usermanagement.AuthenticationDto;
import com.stargrade.fams.api.usermanagement.PendingUserDto;
import com.stargrade.fams.api.usermanagement.UserDto;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Component
public class MockHelper {
    public BuildingDto toBuildingDto() {
        BuildingDto buildingDto = new BuildingDto();
        buildingDto.setName("Test Building");
        buildingDto.setBuildingSize(10000);
        buildingDto.setPropertyId("BUILDING-12RF");
        buildingDto.setNoOfFloors(4);
        buildingDto.setBuildingType(BuildingType.HOUSE);
        buildingDto.setCreatedAt(new Date());
        buildingDto.setUpdatedAt(new Date());
        buildingDto.setDeletedAt(new Date());
        return buildingDto;
    }

    public InviteCodeDto generateInviteCode() {
        InviteCodeDto inviteCodeDto = new InviteCodeDto();
        inviteCodeDto.setCode("FIV-1234");
        inviteCodeDto.setExpiresIn(LocalDateTime.now());
        return inviteCodeDto;
    }

    public InviteDto toInviteDto() {
        InviteDto inviteDto = new InviteDto();
        inviteDto.setInviterId("1");
        inviteDto.setInviteCode("ST2345TR");
        inviteDto.setUnitNo("1A");
        inviteDto.setInvitedGuest(List.of(new InvitedGuest()));
        inviteDto.setIsAlone(true);
        inviteDto.setAccessStartDate(LocalDate.now());
        inviteDto.setAccessEndDate(LocalDate.now());
        inviteDto.setInviteFrequency(InviteFrequency.ONCE);
        inviteDto.setCreatedAt(new Date());
        inviteDto.setUpdatedAt(new Date());
        inviteDto.setDeletedAt(new Date());
        return inviteDto;
    }

    public OrganizationDto toOrganizationDto() {
        OrganizationDto organizationDto = new OrganizationDto();
        organizationDto.setName("Test Organization");
        organizationDto.setIsDisabled(false);
        organizationDto.setCreatedAt(new Date());
        organizationDto.setUpdatedAt(new Date());
        organizationDto.setDeletedAt(new Date());
        organizationDto.setContact(new ContactDto());
        organizationDto.setAddress(new AddressDto());
        return organizationDto;
    }

    public PermissionDto toPermissionDto() {
        PermissionDto permissionDto = new PermissionDto();
        permissionDto.setPermissionName("CAN_INVITE_VISITORS");
        permissionDto.setDescription("User can invite visitors");
        permissionDto.setUpdatedAt(new Date());
        permissionDto.setDeletedAt(new Date());
        return permissionDto;
    }

    public PropertyDto toPropertyDto() {
        PropertyDto propertyDto = new PropertyDto();
        propertyDto.setName("Hepzibah Courts");
        propertyDto.setCreatedAt(new Date());
        propertyDto.setUpdatedAt(new Date());
        propertyDto.setDeletedAt(new Date());
        propertyDto.setPropertyType(PropertyType.RESIDENTIAL);
        propertyDto.setAddress(new AddressDto());
        propertyDto.setPropertyImage(new PropertyImageDto());
        return propertyDto;
    }

    public RoleDto toRoleDto() {
        RoleDto roleDto = new RoleDto();
        roleDto.setRoleName("ADMIN");
        roleDto.setUpdatedAt(new Date());
        roleDto.setDeletedAt(new Date());
        roleDto.setDescription("This is the admin user of the app");
        return roleDto;
    }

    public SubscriptionDto toSubscriptionDto() {
        SubscriptionDto subscriptionDto = new SubscriptionDto();
        subscriptionDto.setSubscriptionId("SUB-11312");
        subscriptionDto.setPrice(new BigDecimal(10000));
        subscriptionDto.setMinTenants(1);
        subscriptionDto.setMaxTenants(100);
        subscriptionDto.setDescription("1 to 100 tenants");
        subscriptionDto.setCreatedAt(new Date());
        subscriptionDto.setUpdatedAt(new Date());
        return subscriptionDto;
    }

    public UnitDto toUnitDto() {
        UnitDto unitDto = new UnitDto();
        unitDto.setUnitNo("1A");
        unitDto.setUnitType(UnitType.DEFAULT);
        unitDto.setUnitSize(1250);
        unitDto.setMaxOccupants(4);
        unitDto.setRent(2_000_000);
        unitDto.setLeaseStart(LocalDate.parse("2024-09-11"));
        unitDto.setLeaseEnd(LocalDate.parse("2023-09-11"));
        unitDto.setPrimaryMemberFirstName("Matt");
        unitDto.setPrimaryMemberLastName("Damon");
        unitDto.setPrimaryMemberEmail("mat.damon@gmail.com");
        unitDto.setCreatedAt(new Date());
        unitDto.setUpdatedAt(new Date());
        unitDto.setDeletedAt(new Date());
        return unitDto;
    }

    public AuthenticationDto toLoginDto() {
        AuthenticationDto authenticationDto = new AuthenticationDto();
        authenticationDto.setAuthToken("AEF+234E.EDRFS==");
        return authenticationDto;
    }

    public UserDto toUserDto() {
        UserDto userDto = new UserDto();

        RoleDto roleDto = new RoleDto();
        roleDto.setRoleId("FM-RM1");
        roleDto.setRoleName("ADMIN");
        roleDto.setDescription("Admin user in FAMS application");
        roleDto.setCreatedAt(new Date());
        userDto.setRole(roleDto);

        userDto.setUserId("fams-001");
        userDto.setCreatedAt(new Date());
        userDto.setProfilePhotoUrl("https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_960_720.png");
        userDto.setProfilePhotoFormat("png");
        userDto.setFirstName("John");
        userDto.setLastName("Doe");
        userDto.setEmailAddress("john.doe@gmail.com");
        userDto.setDob(LocalDate.parse("1984-09-11"));
        return userDto;
    }

    public PendingUserDto toPendingUserDto() {
        PendingUserDto pendingUserDto = new PendingUserDto();
        pendingUserDto.setUserId("fams-001");
        pendingUserDto.setInviteCode("121212");
        pendingUserDto.setCreatedAt(new Date());
        pendingUserDto.setFirstName("John");
        pendingUserDto.setLastName("Doe");
        pendingUserDto.setEmailAddress("john.doe@gmail.com");
        return pendingUserDto;
    }

    public MemberSettingDto toMemberSettingDto() {
        MemberSettingDto memberSettingDto = new MemberSettingDto();
        memberSettingDto.setMemberId("fams-001");
        memberSettingDto.setDarkModeEnabled(false);
        memberSettingDto.setEmailNotificationEnabled(true);
        memberSettingDto.setSmsNotificationEnabled(false);
        memberSettingDto.setInAppNotificationEnabled(true);
        memberSettingDto.setSubscribedToSecurityAlert(false);
        memberSettingDto.setCreatedAt(new Date());
        memberSettingDto.setUpdatedAt(new Date());
        return memberSettingDto;
    }

    public SupportDto toSupportDto() {
        SupportDto supportDto = new SupportDto();
        supportDto.setCreatedAt(new Date());
        supportDto.setIsClosed(false);
        SupportThreadDto supportThreadDto = new SupportThreadDto();
        supportThreadDto.setThreadId("SUPP-101-FE");
        supportThreadDto.setMessage("Test");
        supportThreadDto.setMessageDate(new Date());
        supportDto.setSupportThread(List.of(supportThreadDto));
        return supportDto;
    }

    public OtpDto toOtpDto() {
        OtpDto otpDto = new OtpDto();
        otpDto.setCreatedAt(new Date());
        otpDto.setUserId("fams-001");
        otpDto.setExpiryDate(new Date());
        otpDto.setOperation("ACCOUNT_REGISTRATION");
        return otpDto;
    }

    public SecurityAlertDto toSecurityAlertDto() {
        SecurityAlertDto securityAlertDto = new SecurityAlertDto();
        securityAlertDto.setAlertId("fams-sa-001");
        securityAlertDto.setCreatedAt(new Date());
        securityAlertDto.setUserId("fams-001");
        securityAlertDto.setMessage("Test message");
        securityAlertDto.setIsRead(false);
        return securityAlertDto;
    }
}
