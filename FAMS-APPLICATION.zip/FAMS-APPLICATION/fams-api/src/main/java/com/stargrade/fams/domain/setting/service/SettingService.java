package com.stargrade.fams.domain.setting.service;

import com.stargrade.fams.api.membersetting.MemberSettingDto;
import com.stargrade.fams.api.membersetting.UpdateNotificationRequestDto;

public interface SettingService {
    MemberSettingDto updateNotificationSettings(UpdateNotificationRequestDto updateNotificationRequest);

    MemberSettingDto toggleDarkMode(String action);

    MemberSettingDto toggleSecurityAlert(String action);
}
