package com.stargrade.fams.domain.support.service.impl;

import com.stargrade.fams.api.support.SupportDto;
import com.stargrade.fams.api.support.SupportMessageRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.support.model.Support;
import com.stargrade.fams.domain.support.model.SupportThread;
import com.stargrade.fams.domain.support.repository.SupportRepository;
import com.stargrade.fams.domain.support.repository.SupportThreadRepository;
import com.stargrade.fams.domain.support.service.SupportService;
import com.stargrade.fams.api.util.SupportObjectMapper;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SupportServiceImpl implements SupportService {
    private final SupportRepository supportRepository;
    private final UserService userService;
    private final SupportThreadRepository supportThreadRepository;
    private final SupportObjectMapper mapper;

    @Override
    public SupportDto createSupport(SupportMessageRequestDto supportMessageRequestDto) {
        User signedInUser = userService.getUserFromSession();
        Support supportTicket = new Support();
        supportTicket.setTicketId(CodeGenerator.generateUUID());
        supportTicket.setIsClosed(false);
        supportTicket.setUser(signedInUser);

        Support savedSupport = supportRepository.save(supportTicket);

        SupportThread supportThread = new SupportThread();
        supportThread.setMessage(supportMessageRequestDto.getMessage());
        supportThread.setMessageDate(new Date());
        supportThread.setThreadId(CodeGenerator.generateUUID());
        supportThread.setSupport(savedSupport);

        SupportThread savedSupportThread = supportThreadRepository.save(supportThread);

        return  mapper.toSupportDto(savedSupport, List.of(mapper.toSupportThreadDto(savedSupportThread)));
    }

    @Override
    public SupportDto viewSupport(String ticketId){
        Optional<Support> supportFromDb = supportRepository.findByTicketId(ticketId);
        if(supportFromDb.isEmpty())
            throw new ValidationException(String.format("No support ticket found with ticketId: %s ", ticketId));

        Support support = supportFromDb.get();

        List<SupportThread> supportThreadList = supportThreadRepository.findAllBySupport(support);

        return mapper.toSupportDto(support, supportThreadList
                .stream()
                .map(mapper::toSupportThreadDto)
                .collect(Collectors.toList())
        );
    }

    @Override
    public SupportDto addMessageToTicket(String ticketId, SupportMessageRequestDto supportMessageRequestDto){
        Optional<Support> supportFromDb = supportRepository.findByTicketId(ticketId);
        if(supportFromDb.isEmpty())
            throw new ValidationException(String.format("No support ticket found with ticketId: %s ", ticketId));

        Support support = supportFromDb.get();

        SupportThread supportThread = new SupportThread();
        supportThread.setMessage(supportMessageRequestDto.getMessage());
        supportThread.setMessageDate(new Date());
        supportThread.setSupport(support);

        supportThreadRepository.save(supportThread);

        List<SupportThread> supportThreadList = supportThreadRepository.findAllBySupport(support);

        return mapper.toSupportDto(support, supportThreadList
                .stream()
                .map(mapper::toSupportThreadDto)
                .collect(Collectors.toList())
        );
    }

    @Override
    public SupportDto replyMessageInTicket(String ticketId, String threadId, SupportMessageRequestDto replyMessageRequest){
        Optional<Support> supportFromDb = supportRepository.findByTicketId(ticketId);
        if(supportFromDb.isEmpty())
            throw new ValidationException(String.format("No support ticket found with ticketId: %s ", ticketId));

        Optional<SupportThread> supportThreadFromDb = supportThreadRepository.findByThreadId(threadId);
        if(supportThreadFromDb.isEmpty())
            throw new ValidationException(String.format("No support thread found with Id: %s ", threadId));

        Support support = supportFromDb.get();

        SupportThread supportThread = supportThreadFromDb.get();
        supportThread.setReply(replyMessageRequest.getMessage());
        supportThread.setReplyDate(new Date());

        supportThreadRepository.save(supportThread);

        List<SupportThread> supportThreadList = supportThreadRepository.findAllBySupport(support);

        return mapper.toSupportDto(support, supportThreadList
                .stream()
                .map(mapper::toSupportThreadDto)
                .collect(Collectors.toList())
        );
    }

    @Override
    public SupportDto closeSupportRequest(String ticketId){
        Optional<Support> supportFromDb = supportRepository.findByTicketId(ticketId);
        if(supportFromDb.isEmpty())
            throw new ValidationException(String.format("No support ticket found with ticketId: %s ", ticketId));

        Support support = supportFromDb.get();

        support.setIsClosed(true);
        support.setClosedAt(new Date());

        supportRepository.save(support);

        List<SupportThread> supportThreadList = supportThreadRepository.findAllBySupport(support);

        return mapper.toSupportDto(support, supportThreadList
                .stream()
                .map(mapper::toSupportThreadDto)
                .collect(Collectors.toList())
        );
    }

}
