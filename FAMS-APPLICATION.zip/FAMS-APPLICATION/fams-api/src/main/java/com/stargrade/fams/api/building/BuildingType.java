package com.stargrade.fams.api.building;

import com.fasterxml.jackson.annotation.JsonValue;

public enum BuildingType {
    APARTMENT("AP"), HOUSE("HS"),DUPLEX("DP"), FACILITY("FS");

    private final String type;

    BuildingType(String type){this.type = type;}

    @JsonValue
    public String getType(){return type;}
}
