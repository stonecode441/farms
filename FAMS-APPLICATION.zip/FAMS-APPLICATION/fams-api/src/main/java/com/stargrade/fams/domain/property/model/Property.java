package com.stargrade.fams.domain.property.model;

import com.stargrade.fams.api.property.PropertyType;
import com.stargrade.fams.domain.address.model.Address;
import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.organization.model.Organization;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Table(name = "property_table")
@Entity
@Getter
@Setter
@NoArgsConstructor
public class Property extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String propertyId;
    @ManyToOne
    private Organization organization;
    private String name;
    @ManyToOne
    private Address address;
    @Enumerated(value = EnumType.STRING)
    private PropertyType propertyType;

    public Property(String propertyId, Organization organization, String name, Address address, PropertyType propertyType) {
        this.propertyId = propertyId;
        this.organization = organization;
        this.name = name;
        this.address = address;
        this.propertyType = propertyType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Property property = (Property) o;
        return getId().equals(property.getId()) &&
                getPropertyId().equals(property.getPropertyId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPropertyId(), getOrganization().getOrganizationId());
    }
}
