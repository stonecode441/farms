package com.stargrade.fams.domain.usermanagement.service.impl;

import com.stargrade.fams.api.role.RoleDto;
import com.stargrade.fams.api.role.RoleRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.usermanagement.model.DefaultRole;
import com.stargrade.fams.domain.usermanagement.model.Role;
import com.stargrade.fams.domain.usermanagement.repository.RoleRepository;
import com.stargrade.fams.domain.usermanagement.service.RoleService;
import com.stargrade.fams.api.util.UserManagementObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoleServiceImpl implements RoleService {
    private final RoleRepository roleRepository;
    private final UserManagementObjectMapper mapper;

    @Override
    public long getRowsCount() {
        return roleRepository.count();
    }

    @Override
    public RoleDto createRole(RoleRequestDto createRoleRequest) {
        return mapper.toRoleDto(roleRepository.save(new Role(CodeGenerator.generateUUID(), createRoleRequest.getRoleName(), createRoleRequest.getDescription())));
    }

    @Override
    public List<RoleDto> getAllRoles() {
        return roleRepository
                .findAllByDeletedAtIsNull()
                .stream()
                .map(mapper::toRoleDto)
                .collect(Collectors.toList());
    }

    @Override
    public RoleDto getRole(String id) {
        Optional<Role> role = roleRepository.findByRoleIdAndDeletedAtIsNull(id);
        if(role.isEmpty())
            throw new ValidationException(String.format("Role with ID: %s does not exist", id));
        return mapper.toRoleDto(role.get());
    }

    @Override
    public Role getDbRole(String id) {
        Optional<Role> role = roleRepository.findByRoleIdAndDeletedAtIsNull(id);
        if(role.isEmpty())
            throw new ValidationException(String.format("Role with ID: %s does not exist", id));
        return role.get();
    }

    @Override
    public RoleDto editRole(String roleId, RoleRequestDto editRoleRequest) {
        Role role = this.getDbRole(roleId);
        role.setRoleName(editRoleRequest.getRoleName());
        role.setDescription(editRoleRequest.getDescription());
        return mapper.toRoleDto(roleRepository.save(role));
    }

    @Override
    public RoleDto deactivateRole(String roleId) {
        Role role = this.getDbRole(roleId);
        if(role.getRoleName().equalsIgnoreCase(DefaultRole.SUPER_ADMIN.name()))
            throw new ValidationException("Cannot disable administrator role");
        role.setIsActive(false);
        return mapper.toRoleDto(roleRepository.save(role));
    }

    @Override
    public RoleDto activateRole(String roleId) {
        Role role = this.getDbRole(roleId);
        role.setIsActive(true);
        return mapper.toRoleDto(roleRepository.save(role));
    }
}
