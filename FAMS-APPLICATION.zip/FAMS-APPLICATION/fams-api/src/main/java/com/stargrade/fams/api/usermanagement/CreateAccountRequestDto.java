package com.stargrade.fams.api.usermanagement;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

@Data
public class CreateAccountRequestDto implements Serializable {
    @NotEmpty(message = "First name is required")
    private String firstName;

    @NotEmpty(message = "Last name is required")
    private String lastName;

    @NotEmpty(message = "Email address is required")
    @Email(regexp = ".+[@].+[\\.].+", message = "Email address in invalid")
    private String emailAddress;

    @NotEmpty(message = "Role ID is required")
    private String roleId;

    private String unitId;

    private LocalDate leaseStart;

    private LocalDate leaseEnd;
}
