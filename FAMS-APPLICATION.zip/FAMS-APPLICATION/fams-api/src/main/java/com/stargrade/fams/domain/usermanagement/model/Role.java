package com.stargrade.fams.domain.usermanagement.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Role extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String roleId;
    @Column(unique = true)
    private String roleName;
    private String description;
    private Boolean isActive;

    public Role(String roleId, String roleName, String description) {
        this.roleId = roleId;
        this.roleName = roleName;
        this.description = description;
        this.isActive = true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Role role = (Role) o;
        return getId().equals(role.getId()) &&
                getRoleId().equals(role.getRoleId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getRoleId(), getRoleName());
    }
}
