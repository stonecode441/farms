package com.stargrade.fams.domain.usermanagement.service;

import com.stargrade.fams.api.admin.ChangeRoleRequestDto;
import com.stargrade.fams.api.membersetting.ChangePasswordRequestDto;
import com.stargrade.fams.api.usermanagement.*;
import com.stargrade.fams.api.userprofile.AddProfilePhotoRequestDto;
import com.stargrade.fams.api.userprofile.UpdateProfileRequestDto;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.usermanagement.model.User;

import java.util.List;

public interface UserService {
    AuthenticationDto authenticate(AuthenticationRequestDto authenticationRequest);

    PendingUserDto createAccount(CreateAccountRequestDto createAccountRequestDto);

    PendingUserDto getInvitedUser(String inviteCode);

    User getUserByIdFromDb(String userId);

    User getUserFromSession();

    UserDto getSignedInUser();

    List<UserDto> getAllUsersByRole(String roleId, Integer pageNumber, Integer pageSize);

    UserDto getUser(String userId);

    UserDto activateAccount(ActivateAccountRequestDto activateAccountRequestDto) throws FamsApplicationException;

    UserDto createUserInternal(String roleId, String firstName, String lastName, String emailAddress, String password, String confirmPassword);

    boolean forgotPassword(ForgotPasswordRequestDto forgotPasswordRequest);

    UserDto resetPassword(PasswordResetRequestDto passwordResetRequest);

    UserDto updateProfile(UpdateProfileRequestDto updateProfileRequest);

    UserDto addProfilePhoto(AddProfilePhotoRequestDto addProfilePhotoRequest) throws FamsApplicationException;

    UserDto removeProfilePhoto();

    UserDto deactivateAccount(String userId);

    UserDto activateAccount(String userId);

    UserDto deleteAccount(String userId);

    UserDto changeRole(String userId, ChangeRoleRequestDto changeRoleRequest);

    UserDto changePassword(ChangePasswordRequestDto changePasswordRequest);
}
