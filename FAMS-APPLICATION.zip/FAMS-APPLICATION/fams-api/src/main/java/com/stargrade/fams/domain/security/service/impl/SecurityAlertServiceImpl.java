package com.stargrade.fams.domain.security.service.impl;


import com.stargrade.fams.api.securityalert.SecurityAlertDto;
import com.stargrade.fams.api.securityalert.SecurityAlertRequestDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.security.model.SecurityAlert;
import com.stargrade.fams.domain.security.repository.SecurityAlertRepository;
import com.stargrade.fams.domain.security.service.SecurityAlertService;
import com.stargrade.fams.api.util.SecurityAlertObjectMapper;
import com.stargrade.fams.domain.usermanagement.model.User;
import com.stargrade.fams.domain.usermanagement.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SecurityAlertServiceImpl implements SecurityAlertService {
    private final UserService userService;
    private final SecurityAlertRepository securityAlertRepository;
    private final SecurityAlertObjectMapper mapper;

    @Override
    public SecurityAlertDto createSecurityAlert(SecurityAlertRequestDto securityAlertRequestDto) {
        User signedInUser = userService.getUserFromSession();
        SecurityAlert securityAlert = new SecurityAlert();// TODO should create an alert for all members and tie them to a group ID so whn updating, it would be a group level
        securityAlert.setAlertId(CodeGenerator.generateUUID());
        securityAlert.setUser(signedInUser);
        securityAlert.setMessage(securityAlertRequestDto.getMessage());
        securityAlert.setIsRead(false);

        securityAlertRepository.save(securityAlert);

        return mapper.toSecurityAlertDto(securityAlert);
    }

    @Override
    public SecurityAlertDto updateSecurityAlert(String alertId, SecurityAlertRequestDto updateSecurityAlertRequest) {
        Optional<SecurityAlert> securityAlertFromDb = securityAlertRepository.findByAlertId(alertId);
        if (securityAlertFromDb.isEmpty())
            throw new ValidationException(String.format("No security alert found with alertId: %s ", alertId));

        SecurityAlert securityAlert = securityAlertFromDb.get();

        securityAlert.setMessage(updateSecurityAlertRequest.getMessage());
        securityAlert.setIsRead(false);

        securityAlertRepository.save(securityAlert);

        return mapper.toSecurityAlertDto(securityAlert);
    }

    @Override
    public SecurityAlertDto deleteSecurityAlert(String alertId) {
        Optional<SecurityAlert> securityAlertFromDb = securityAlertRepository.findByAlertId(alertId);
        if (securityAlertFromDb.isEmpty())
            throw new ValidationException(String.format("No security alert found with alertId: %s ", alertId));

        SecurityAlert securityAlert = securityAlertFromDb.get();
        securityAlert.setDeletedAt(new Date());

        securityAlertRepository.save(securityAlert);

        return mapper.toSecurityAlertDto(securityAlert);
    }

    @Override
    public SecurityAlertDto viewSecurityAlert(String alertId) {
        Optional<SecurityAlert> securityAlertFromDb = securityAlertRepository.findByAlertId(alertId);
        if (securityAlertFromDb.isEmpty())
            throw new ValidationException(String.format("No security alert found with alertId: %s ", alertId));

        SecurityAlert securityAlert = securityAlertFromDb.get();

        securityAlert.setIsRead(true);
        securityAlertRepository.save(securityAlert);

        return mapper.toSecurityAlertDto(securityAlert);
    }

    @Override
    public List<SecurityAlertDto> viewUserSecurityAlerts() {
        User signedInUser = userService.getUserFromSession();
        List<SecurityAlert> securityAlerts = securityAlertRepository.findAllByUserAndDeletedAtIsNull(signedInUser);

        return securityAlerts
                .stream()
                .map(mapper::toSecurityAlertDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<SecurityAlertDto> clearUserSecurityAlerts() {
        User signedInUser = userService.getUserFromSession();
        securityAlertRepository.deleteAllByUser(signedInUser);
        return new ArrayList<>();
    }
}
