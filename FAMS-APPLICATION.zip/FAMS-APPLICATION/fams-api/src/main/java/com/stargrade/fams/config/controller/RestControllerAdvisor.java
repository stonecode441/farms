package com.stargrade.fams.config.controller;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.base.exception.FamsApplicationException;
import com.stargrade.fams.domain.base.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@Slf4j
@ControllerAdvice
public class RestControllerAdvisor extends ResponseEntityExceptionHandler {
    @ExceptionHandler(value ={ FamsApplicationException.class })
    protected ResponseEntity<?> handleFamsApplicationException(FamsApplicationException ex, WebRequest request){
        log.error("FamsApplicationException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage(ex.getMessage());
        return handleExceptionInternal(ex, apiResponse, new HttpHeaders(), HttpStatus.CONFLICT, request);
    }

    @ExceptionHandler(value ={ ValidationException.class })
    protected ResponseEntity<?> handleValidationException(ValidationException ex, WebRequest request){
        log.error("ValidationException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage(ex.getMessage());
        return handleExceptionInternal(ex, apiResponse, new HttpHeaders(), HttpStatus.CONFLICT, request);
    }

    @ExceptionHandler(value ={ UsernameNotFoundException.class })
    protected ResponseEntity<?> handleUsernameNotFoundExceptions(UsernameNotFoundException ex, WebRequest request){
        log.error("UsernameNotFoundException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage(ex.getMessage());
        return handleExceptionInternal(ex, apiResponse, new HttpHeaders(), HttpStatus.CONFLICT, request);
    }

    @ExceptionHandler(value ={ Exception.class })
    protected ResponseEntity<?> handleGeneralExceptions(Exception ex, WebRequest request){
        log.error("GeneralException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage(String.format("An internal server error occurred: %s", ex.getMessage()));
        return handleExceptionInternal(ex, apiResponse, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(value ={ BadCredentialsException.class })
    protected ResponseEntity<?> handleBadCredentialsExceptions(BadCredentialsException ex, WebRequest request){
        log.error("GeneralException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage("Invalid username or password");
        return handleExceptionInternal(ex, apiResponse, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        log.error("MethodArgumentNotValidException: ", ex);
        ApiResponse<?> apiResponse = new ApiResponse<>();
        apiResponse.withErrorMessage(ex.getBindingResult().getFieldError().getDefaultMessage());
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }
}
