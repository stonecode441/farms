package com.stargrade.fams.domain.organization.service.impl;

import com.stargrade.fams.api.organization.OrganizationDto;
import com.stargrade.fams.api.organization.OrganizationRequestDto;
import com.stargrade.fams.domain.address.service.AddressService;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.contact.service.ContactService;
import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.model.OrganizationSubscription;
import com.stargrade.fams.domain.organization.repository.OrganizationRepository;
import com.stargrade.fams.domain.organization.repository.OrganizationSubscriptionRepository;
import com.stargrade.fams.domain.organization.service.OrganizationService;
import com.stargrade.fams.api.util.OrganizationObjectMapper;
import com.stargrade.fams.domain.subscription.model.Subscription;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.email.EmailBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrganizationServiceImpl implements OrganizationService {
    private final OrganizationRepository organizationRepository;
    private final ContactService contactService;
    private final AddressService addressService;
    private final OrganizationSubscriptionRepository organizationSubscriptionRepository;
    private final OrganizationObjectMapper mapper;
    private final Mailer mailer;
    private final TemplateEngine templateEngine;

    @Value("${mail.smt.sendAsync:true}")
    private Boolean async;

    @Value("${mail.smt.sender:FAMS}")
    private String senderName;

    @Value("${mail.smt.senderEmail:}")
    private String senderEmail;

    @Value("${mail.smt.organizationInviteSubj:FAMS - ORGANIZATION ONBOARDING}")
    private String organizationInviteSubject;

    @Value("${fams.organization.invite.url:}")
    private String organizationInviteUrl;

    @Override
    public OrganizationDto inviteOrganization(OrganizationRequestDto organizationRequestDto) {
        Optional<Organization> organizationOptional = organizationRepository.findByName(organizationRequestDto.getName());

        if(organizationOptional.isPresent() && organizationOptional.get().getIsDisabled())
            throw new ValidationException("Unable to invite organization as a similar inactive organization exists");

        Organization organization = organizationOptional.orElseGet(() -> organizationRepository.save(new Organization(
                CodeGenerator.generateUUID(),
                organizationRequestDto.getName(),
                contactService.createContact(organizationRequestDto.getContact()),
                addressService.createAddress(organizationRequestDto.getAddress()))
        ));

        if(organization.getDeletedAt() != null) {
            organization.setDeletedAt(null);
            organizationRepository.save(organization);
        }

        OrganizationDto organizationDto = mapper.toOrganizationDto(organization);
        sendOrganizationInviteNotification(organizationDto);
        return organizationDto;
    }

    void sendOrganizationInviteNotification(OrganizationDto organization) {
        Context context = new Context();
        context.setVariable("organization", organization);
        context.setVariable("inviteUrl", String.format("%s?oid=%s", organizationInviteUrl, organization.getId()));
        String content = templateEngine.process("organization_invite_template", context);
        Email email = EmailBuilder.startingBlank()
                .from(senderName, senderEmail)
                .to(String.format("%s %s", organization.getContact().getFirstName(), organization.getContact().getLastName()), organization.getContact().getEmail())
                .withSubject(organizationInviteSubject)
                .withHTMLText(content).buildEmail();
        mailer.sendMail(email, async);
    }

    @Override
    public Organization getOrganizationById(String organizationId) {
        Optional<Organization> existingOrganization = organizationRepository.findByOrganizationIdAndDeletedAtIsNull(organizationId);
        if(existingOrganization.isEmpty())
            throw new ValidationException(String.format("Organization with ID: %s does not exist", organizationId));

        return existingOrganization.get();
    }

    @Override
    public OrganizationDto updateOrganization(String organizationId, OrganizationRequestDto organizationRequestDto) {
        Organization organization = getOrganizationById(organizationId);

        if(organization.getIsDisabled())
            throw new ValidationException(String.format("Unable to update inactive organization with ID: %s", organizationId));

        if(!StringUtils.isEmpty(organizationRequestDto.getName())) {
            Optional<Organization> similarOrganization = organizationRepository.findByName(organizationRequestDto.getName());
            if(similarOrganization.isPresent() && !similarOrganization.get().equals(organization))
                throw new ValidationException(String.format("A similar organization already exists with name: %s", organizationRequestDto.getName()));

            organization.setName(organizationRequestDto.getName());
        }

        if(organizationRequestDto.getAddress() != null) {
            organization.setAddress(addressService.createAddress(organizationRequestDto.getAddress()));
        }

        if(organizationRequestDto.getContact() != null) {
            organization.setContact(contactService.createContact(organizationRequestDto.getContact()));
        }

        return mapper.toOrganizationDto(organizationRepository.save(organization));
    }

    @Override
    public OrganizationDto deactivateOrganization(String organizationId) {
        Organization organization = getOrganizationById(organizationId);
        organization.setIsDisabled(true);
        return mapper.toOrganizationDto(organizationRepository.save(organization));
    }

    @Override
    public OrganizationDto activateOrganization(String organizationId) {
        Organization organization = getOrganizationById(organizationId);
        organization.setIsDisabled(false);
        return mapper.toOrganizationDto(organizationRepository.save(organization));
    }

    @Override
    public OrganizationDto viewOrganization(String organizationId) {
        return mapper.toOrganizationDto(getOrganizationById(organizationId));
    }

    @Override
    public List<OrganizationDto> viewOrganizations(Integer pageNo, Integer pageSize) {
        return organizationRepository.findAllByDeletedAtIsNull(PageRequest.of(pageNo, pageSize))
                .stream()
                .map(mapper::toOrganizationDto)
                .collect(Collectors.toList());
    }

    @Override
    public OrganizationDto deleteOrganization(String organizationId) {
        Organization organization = getOrganizationById(organizationId);
        organization.setDeletedAt(new Date());
        return mapper.toOrganizationDto(organizationRepository.save(organization));
    }

    @Override
    public OrganizationSubscription activateOrganizationSubscription(Organization organization, Subscription subscription) {
        Objects.requireNonNull(organization, "Organization cannot be null");
        Objects.requireNonNull(subscription, "Subscription cannot be null");
        Optional<OrganizationSubscription> organizationSubscriptionOptional = organizationSubscriptionRepository.findByOrganizationAndSubscription(organization, subscription);
        return organizationSubscriptionOptional.orElseGet(() -> organizationSubscriptionRepository.save(new OrganizationSubscription(organization, subscription)));
    }

    @Override
    public OrganizationSubscription changeOrganizationSubscription(Organization organization, Subscription subscription) {
        Objects.requireNonNull(organization, "Organization cannot be null");
        Objects.requireNonNull(subscription, "Subscription cannot be null");

        OrganizationSubscription organizationSubscription = getOrganizationSubscription(organization);
        organizationSubscriptionRepository.deleteByOrganizationId(organizationSubscription.getOrganization().getId());

        return organizationSubscriptionRepository.save(new OrganizationSubscription(organization, subscription));
    }

    @Override
    public void deleteOrganizationSubscription(Organization organization, Subscription subscription) {
        Objects.requireNonNull(organization, "Organization cannot be null");
        Objects.requireNonNull(subscription, "Subscription cannot be null");
        OrganizationSubscription organizationSubscription = getOrganizationSubscription(organization);
        organizationSubscriptionRepository.deleteByOrganizationId(organizationSubscription.getOrganization().getId());
    }

    OrganizationSubscription getOrganizationSubscription(Organization organization) {
        Optional<OrganizationSubscription> existingOrganizationSubscription = organizationSubscriptionRepository.findByOrganization(organization);

        if(existingOrganizationSubscription.isEmpty())
            throw new ValidationException(String.format("No existing subscription found for organization with ID: %s", organization.getOrganizationId()));

        return existingOrganizationSubscription.get();
    }

    @Override
    public void checkIfOrganizationSubscriptionSupportsMoreUnits(Organization organization, Long currentUnitCount) {
        OrganizationSubscription organizationSubscription = getOrganizationSubscription(organization);
        Subscription subscription = organizationSubscription.getSubscription();
        if(subscription.getMaxTenants() > (currentUnitCount + 1))
            throw new ValidationException("Organization has exceeded subscription limit");
    }
}
