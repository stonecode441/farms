package com.stargrade.fams.api.usermanagement;

import com.stargrade.fams.api.role.RoleDto;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

@Data
public class UserDto implements Serializable {
    private String userId;
    private RoleDto role;
    private String firstName;
    private String lastName;
    private LocalDate dob;
    private String emailAddress;
    private String phoneNumber;
    private String profilePhotoUrl;
    private String profilePhotoFormat;
    private Boolean isDisabled;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
}
