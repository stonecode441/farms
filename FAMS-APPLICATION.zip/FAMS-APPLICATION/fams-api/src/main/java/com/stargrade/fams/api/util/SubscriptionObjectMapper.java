package com.stargrade.fams.api.util;

import com.stargrade.fams.api.subscription.SubscriptionDto;
import com.stargrade.fams.domain.subscription.model.Subscription;
import org.springframework.stereotype.Component;

@Component
public class SubscriptionObjectMapper {
    public SubscriptionDto toSubscriptionDto(Subscription subscription) {
        SubscriptionDto subscriptionDto = new SubscriptionDto();
        subscriptionDto.setSubscriptionId(subscription.getSubscriptionId());
        subscriptionDto.setName(subscription.getName());
        subscriptionDto.setDescription(subscription.getDescription());
        subscriptionDto.setPrice(subscription.getPrice());
        subscriptionDto.setMinTenants(subscription.getMinTenants());
        subscriptionDto.setMaxTenants(subscription.getMaxTenants());

        subscriptionDto.setCreatedAt(subscription.getCreatedAt());
        subscriptionDto.setUpdatedAt(subscription.getUpdatedAt());
        subscriptionDto.setDeletedAt(subscription.getDeletedAt());
        return subscriptionDto;
    }
}
