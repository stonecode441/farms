package com.stargrade.fams.api.support;

import com.stargrade.fams.api.usermanagement.UserDto;
import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.api.util.MockHelper;
import com.stargrade.fams.domain.support.service.SupportService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RequestMapping("${app.route.prefix}/support")
@RestController
@RequiredArgsConstructor
public class SupportController {
    private final SupportService supportService;

    @Operation(summary = "Create a support ticket")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_SUPPORT_TICKET)")
    public ResponseEntity<ApiResponse<SupportDto>> createSupportRequest(@Valid @RequestBody SupportMessageRequestDto createSupportTicketRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Support request created successfully", supportService.createSupport(createSupportTicketRequest)));
    }

    @Operation(summary = "View a support ticket")
    @GetMapping("/{ticketId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).GET_SUPPORT_TICKET)")
    public ResponseEntity<ApiResponse<SupportDto>> viewSupportRequest(@PathVariable String ticketId) {
        return ResponseEntity.ok(new ApiResponse<>("Support request retrieved successfully", supportService.viewSupport(ticketId)));
    }

    @Operation(summary = "Add message to ticket")
    @PutMapping("/{ticketId}/add")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).GET_SUPPORT_TICKET)")
    public ResponseEntity<ApiResponse<SupportDto>> addMessageToTicket(@PathVariable String ticketId, @Valid @RequestBody SupportMessageRequestDto addMessageRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Message successfully added to support ticket", supportService.addMessageToTicket(ticketId,addMessageRequest)));
    }

    @Operation(summary = "Reply message in ticket")
    @PutMapping("/{ticketId}/reply/{threadId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).GET_SUPPORT_TICKET)")
    public ResponseEntity<ApiResponse<SupportDto>> replyMessageInTicket(@PathVariable String ticketId, @PathVariable String threadId, @Valid @RequestBody SupportMessageRequestDto replyMessageRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Reply successfully added to message in support ticket", supportService.replyMessageInTicket(ticketId, threadId, replyMessageRequest)));
    }

    @Operation(summary = "Resolve/close a support request")
    @DeleteMapping("/close/{ticketId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CLOSE_SUPPORT_TICKET)")
    public ResponseEntity<ApiResponse<SupportDto>> closeSupportRequest(@PathVariable String ticketId) {
        return ResponseEntity.ok(new ApiResponse<>("Support request closed successfully", supportService.closeSupportRequest(ticketId)));
    }
}
