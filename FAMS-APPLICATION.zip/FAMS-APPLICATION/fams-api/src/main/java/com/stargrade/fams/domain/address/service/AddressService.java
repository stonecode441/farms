package com.stargrade.fams.domain.address.service;

import com.stargrade.fams.api.organization.AddressDto;
import com.stargrade.fams.domain.address.model.Address;

public interface AddressService {
    Address createAddress(AddressDto addressDto);
}
