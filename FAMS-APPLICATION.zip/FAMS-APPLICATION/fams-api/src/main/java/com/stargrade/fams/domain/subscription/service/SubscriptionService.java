package com.stargrade.fams.domain.subscription.service;

import com.stargrade.fams.api.subscription.CancelSubscriptionRequestDto;
import com.stargrade.fams.api.subscription.CreateSubscriptionRequestDto;
import com.stargrade.fams.api.subscription.SubscriptionDto;
import com.stargrade.fams.api.subscription.SubscriptionRequestDto;

import java.util.List;

public interface SubscriptionService {
    SubscriptionDto createSubscription(CreateSubscriptionRequestDto createSubscriptionRequest);

    List<SubscriptionDto> getAllSubscriptions();

    SubscriptionDto getSubscription(String subscriptionId);

    SubscriptionDto deleteSubscription(String subscriptionId);

    SubscriptionDto activateSubscription(SubscriptionRequestDto subscriptionRequestDto);

    SubscriptionDto modifySubscription(SubscriptionRequestDto subscriptionRequestDto);

    SubscriptionDto cancelSubscription(CancelSubscriptionRequestDto cancelSubscriptionRequestDto);
}
