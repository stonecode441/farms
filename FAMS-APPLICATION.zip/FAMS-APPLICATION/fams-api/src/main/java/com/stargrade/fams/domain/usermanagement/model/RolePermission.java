package com.stargrade.fams.domain.usermanagement.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"role_id", "permission_id"}))
@Entity
@Getter
@Setter
@NoArgsConstructor
public class RolePermission extends BaseEntity {
    @ManyToOne
    private Role role;
    @ManyToOne
    private Permission permission;

    public RolePermission(Role role, Permission permission) {
        this.role = role;
        this.permission = permission;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolePermission rolePermission = (RolePermission) o;
        return getId().equals(rolePermission.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPermission().getPermissionId(), getRole().getRoleId());
    }
}
