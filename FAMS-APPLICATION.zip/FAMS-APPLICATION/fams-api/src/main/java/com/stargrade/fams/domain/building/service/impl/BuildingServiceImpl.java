package com.stargrade.fams.domain.building.service.impl;

import com.stargrade.fams.api.building.AddOccupantsRequestDto;
import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.building.CreateBuildingRequestDto;
import com.stargrade.fams.api.building.UpdateBuildingRequestDto;
import com.stargrade.fams.api.unit.UnitDto;
import com.stargrade.fams.domain.base.exception.ValidationException;
import com.stargrade.fams.domain.base.util.CodeGenerator;
import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.building.model.BuildingUnit;
import com.stargrade.fams.domain.building.repository.BuildingRepository;
import com.stargrade.fams.domain.building.repository.BuildingUnitRepository;
import com.stargrade.fams.domain.building.service.BuildingService;
import com.stargrade.fams.api.util.BuildingObjectMapper;
import com.stargrade.fams.domain.organization.model.Organization;
import com.stargrade.fams.domain.organization.service.OrganizationService;
import com.stargrade.fams.domain.property.model.Property;
import com.stargrade.fams.domain.property.service.PropertyService;
import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitLeaseRecord;
import com.stargrade.fams.domain.unit.model.UnitOccupant;
import com.stargrade.fams.domain.unit.service.UnitService;
import com.stargrade.fams.api.util.UnitObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BuildingServiceImpl implements BuildingService {
    private final BuildingRepository buildingRepository;
    private final BuildingUnitRepository buildingUnitRepository;
    private final BuildingObjectMapper mapper;
    private final UnitObjectMapper unitObjectMapper;
    private UnitService unitService;
    private final PropertyService propertyService;
    private final OrganizationService organizationService;

    public void setUnitService(UnitService unitService) {
        this.unitService = unitService;
    }
    @Override
    public List<BuildingDto> getAllBuildings(Property property) {
        Objects.requireNonNull(property, "Property cannot be null");
        List<Building> buildings = buildingRepository.findAllByPropertyAndDeletedAtIsNull(property);
        return buildings
                .stream()
                .map(this::getBuildingAndUnits)
                .collect(Collectors.toList());
    }

    BuildingDto getBuildingAndUnits(Building building) {
        Objects.requireNonNull(building, "Building cannot be null");
        List<BuildingUnit> buildingUnits = buildingUnitRepository.findAllByBuilding(building);
        List<UnitDto> unitDtoList = new ArrayList<>();
        for(BuildingUnit buildingUnit : buildingUnits) {
            Unit unit = buildingUnit.getUnit();
            List<UnitOccupant> unitOccupantsList = unitService.getAllUnitOccupants(unit);
            List<UnitLeaseRecord> unitLeaseRecordList = unitService.getAllUnitLeaseRecord(unit);
            UnitDto unitDto = unitObjectMapper.toUnitDto(
                    unit,
                    unitOccupantsList
                            .stream()
                            .map(UnitOccupant::getOccupant)
                            .collect(Collectors.toList()),
                    unitLeaseRecordList
            );
            unitDtoList.add(unitDto);
        }
        return mapper.toBuildingDto(building, unitDtoList);
    }

    @Override
    public BuildingDto createBuilding(String propertyId, CreateBuildingRequestDto createBuildingRequest) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Building building = buildingRepository.save(new Building(CodeGenerator.generateUUID(), property, createBuildingRequest.getName(), createBuildingRequest.getBuildingSize(), createBuildingRequest.getNoOfFloors(), createBuildingRequest.getBuildingType()));
        List<Unit> createdUnits = unitService.createUnits(createBuildingRequest.getUnits());
        createdUnits.forEach(cu -> buildingUnitRepository.save(new BuildingUnit(building, cu)));
        return getBuildingAndUnits(building);
    }

    @Override
    public BuildingDto updateBuilding(String propertyId, String buildingId, UpdateBuildingRequestDto updateBuildingRequest) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Optional<Building> buildingFromDb = buildingRepository.findByBuildingIdAndPropertyAndDeletedAtIsNull(buildingId, property);
        if(buildingFromDb.isEmpty())
            throw new ValidationException(String.format("Building with id: %s does not exist for property: %s", propertyId, property.getPropertyId()));
        Building building = buildingFromDb.get();

        if(!StringUtils.isEmpty(updateBuildingRequest.getName()))
            building.setName(updateBuildingRequest.getName());
        if(updateBuildingRequest.getBuildingSize() != null)
            building.setBuildingSize(updateBuildingRequest.getBuildingSize());
        if(updateBuildingRequest.getBuildingType() != null)
            building.setBuildingType(updateBuildingRequest.getBuildingType());
        if(updateBuildingRequest.getNoOfFloors() != null)
            building.setNoOfFloors(updateBuildingRequest.getNoOfFloors());

        return getBuildingAndUnits(buildingRepository.save(building));
    }

    @Override
    public BuildingDto addOccupantsToBuilding(String propertyId, String buildingId, AddOccupantsRequestDto addOccupantsRequest) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Optional<Building> buildingFromDb = buildingRepository.findByBuildingIdAndPropertyAndDeletedAtIsNull(buildingId, property);
        if(buildingFromDb.isEmpty())
            throw new ValidationException(String.format("Building with id: %s does not exist for property: %s", propertyId, property.getPropertyId()));
        Building building = buildingFromDb.get();

        Organization organization = property.getOrganization();
        organizationService.checkIfOrganizationSubscriptionSupportsMoreUnits(organization, getBuildingUnitCount(organization.getOrganizationId()));

        unitService.addOccupantsToUnit(addOccupantsRequest.getUnitId(), addOccupantsRequest);

        return getBuildingAndUnits(buildingRepository.save(building));
    }

    @Override
    public Building getBuildingByIdFromDb(String buildingId) {
        Optional<Building> building = buildingRepository.findByBuildingIdAndDeletedAtIsNull(buildingId);
        if(building.isEmpty())
            throw new ValidationException(String.format("Building with id: %s does not exist", buildingId));
        return building.get();
    }

    @Override
    public BuildingDto getBuilding(String propertyId, String buildingId) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Optional<Building> building = buildingRepository.findByBuildingIdAndPropertyAndDeletedAtIsNull(buildingId, property);
        if(building.isEmpty())
            throw new ValidationException(String.format("Building with id: %s does not exist", buildingId));
        return getBuildingAndUnits(building.get());
    }

    @Override
    public List<BuildingDto> getAllBuildings(String propertyId, Integer pageNumber, Integer pageSize) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Page<Building> building = buildingRepository.findAllByPropertyAndDeletedAtIsNull(property, PageRequest.of(pageNumber, pageSize));
        return building
                .stream()
                .map(this::getBuildingAndUnits)
                .collect(Collectors.toList());
    }

    @Override
    public BuildingDto deleteBuilding(String propertyId, String buildingId) {
        Property property = propertyService.getPropertyByIdFromDb(propertyId);
        Optional<Building> buildingFromDb = buildingRepository.findByBuildingIdAndPropertyAndDeletedAtIsNull(buildingId, property);
        if(buildingFromDb.isEmpty())
            throw new ValidationException(String.format("Building with id: %s does not exist", buildingId));
        Building building = buildingFromDb.get();
        building.setDeletedAt(new Date());
        return getBuildingAndUnits(buildingRepository.save(building));
    }

    @Override
    public BuildingUnit createBuildingUnit(Building building, Unit unit) {
        return buildingUnitRepository.save(new BuildingUnit(building, unit));
    }

    @Override
    public BuildingUnit getBuildingUnit(String buildingId, Unit unit) {
        Objects.requireNonNull(unit, "Unit cannot be null");
        Building building = getBuildingByIdFromDb(buildingId);
        Optional<BuildingUnit> buildingUnit = buildingUnitRepository.findByBuildingAndUnit(building, unit);
        if(buildingUnit.isEmpty())
            throw new ValidationException(String.format("No building unit with buildingId: %s and unitId: %s", buildingId, unit.getUnitId()));
        return buildingUnit.get();
    }

    @Override
    public List<BuildingUnit> getAllBuildingUnits(String buildingId) {
        Building building = getBuildingByIdFromDb(buildingId);
        return buildingUnitRepository.findAllByBuilding(building);
    }

    Long getBuildingUnitCount(String organizationId) {
        Long buildingUnitCount = buildingUnitRepository.countAllByOrganization(organizationId);
        if(buildingUnitCount == null)
            return 0L;
        return buildingUnitCount;
    }
}
