package com.stargrade.fams.api.unit;

import com.stargrade.fams.api.usermanagement.UserDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaseRecord implements Serializable {
    private LocalDate startDate;
    private LocalDate endDate;
    private List<UserDto> tenants;
}
