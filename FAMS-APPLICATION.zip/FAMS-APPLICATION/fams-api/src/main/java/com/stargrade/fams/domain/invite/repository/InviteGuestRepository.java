package com.stargrade.fams.domain.invite.repository;

import com.stargrade.fams.domain.invite.model.Guest;
import com.stargrade.fams.domain.invite.model.Invite;
import com.stargrade.fams.domain.invite.model.InviteGuest;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InviteGuestRepository extends JpaRepository<InviteGuest, Long> {
    List<InviteGuest> findAllByInvite(Invite invite);

    Optional<InviteGuest> findByInviteAndGuest(Invite invite, Guest guest);

    @Transactional
    @Modifying
    @Query("DELETE FROM InviteGuest k WHERE k.invite.id =:inviteId")
    void deleteAllByInviteId(@Param("inviteId") Long inviteId);
}
