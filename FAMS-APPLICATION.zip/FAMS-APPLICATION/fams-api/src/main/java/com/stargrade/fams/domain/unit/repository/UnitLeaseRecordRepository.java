package com.stargrade.fams.domain.unit.repository;

import com.stargrade.fams.domain.unit.model.Unit;
import com.stargrade.fams.domain.unit.model.UnitLeaseRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UnitLeaseRecordRepository extends JpaRepository<UnitLeaseRecord, Long> {
    List<UnitLeaseRecord> findAllByUnit(Unit unit);
}
