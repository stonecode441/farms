package com.stargrade.fams.domain.invite.service;

import com.stargrade.fams.api.invite.InviteCodeDto;
import com.stargrade.fams.api.invite.InviteDto;
import com.stargrade.fams.api.invite.InviteRequestDto;
import com.stargrade.fams.api.invite.UpdateInviteRequestDto;

import java.util.List;

public interface InviteService {
    InviteCodeDto generateInviteCode();

    InviteDto createInvite(InviteRequestDto inviteRequestDto);

    InviteDto updateInvite(String inviteId, UpdateInviteRequestDto updateInviteRequestDto);

    InviteDto getAnInvite(String inviteId);

    List<InviteDto> getAllInvites(Integer pageNo, Integer pageSize);

    InviteDto cancelInvite(String inviteId);

    InviteDto checkIn(String inviteId, String guestId);

    InviteDto checkOut(String inviteId, String guestId);
}
