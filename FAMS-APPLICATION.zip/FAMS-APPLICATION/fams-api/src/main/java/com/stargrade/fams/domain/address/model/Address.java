package com.stargrade.fams.domain.address.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Address extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String addressId;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private String countryCode;
    @Column(unique = true)
    private String addressLine;

    public Address(String addressId, String city, String state, String zipCode, String country, String countryCode, String addressLine) {
        this.addressId = addressId;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.country = country;
        this.countryCode = countryCode;
        this.addressLine = addressLine;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address obj = (Address) o;
        return getId().equals(obj.getId()) &&
                getAddressId().equals(obj.getAddressId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getAddressId(), getAddressLine());
    }
}
