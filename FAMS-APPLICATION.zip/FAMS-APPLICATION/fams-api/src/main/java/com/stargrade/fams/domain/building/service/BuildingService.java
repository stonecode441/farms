package com.stargrade.fams.domain.building.service;

import com.stargrade.fams.api.building.AddOccupantsRequestDto;
import com.stargrade.fams.api.building.BuildingDto;
import com.stargrade.fams.api.building.CreateBuildingRequestDto;
import com.stargrade.fams.api.building.UpdateBuildingRequestDto;
import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.building.model.BuildingUnit;
import com.stargrade.fams.domain.property.model.Property;
import com.stargrade.fams.domain.unit.model.Unit;

import java.util.List;

public interface BuildingService {
    List<BuildingDto> getAllBuildings(Property property);

    BuildingDto createBuilding(String propertyId, CreateBuildingRequestDto createBuildingRequest);

    BuildingDto updateBuilding(String propertyId, String buildingId, UpdateBuildingRequestDto updateBuildingRequest);

    BuildingDto addOccupantsToBuilding(String propertyId, String buildingId, AddOccupantsRequestDto addOccupantsRequest);

    Building getBuildingByIdFromDb(String buildingId);

    BuildingDto getBuilding(String propertyId, String buildingId);

    List<BuildingDto> getAllBuildings(String propertyId, Integer pageNumber, Integer pageSize);

    BuildingDto deleteBuilding(String propertyId, String buildingId);

    BuildingUnit createBuildingUnit(Building building, Unit unit);

    BuildingUnit getBuildingUnit(String buildingId, Unit unit);

    List<BuildingUnit> getAllBuildingUnits(String buildingId);
}
