package com.stargrade.fams.external.config;

import com.cloudinary.Cloudinary;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class CloudinaryConfiguration {
    @Value("${fams.cloudinary.cloudName:}")
    private String cloudName;

    @Value("${fams.cloudinary.apiKey:}")
    private String apiKey;

    @Value("${fams.cloudinary.apiSecret:}")
    private String apiSecret;

    @Bean
    public Cloudinary initialize(){
        Map<String, String> map = new HashMap<>();
        map.put("cloud_name", cloudName);
        map.put("api_key", apiKey);
        map.put("api_secret", apiSecret);
        return new Cloudinary(map);
    }
}
