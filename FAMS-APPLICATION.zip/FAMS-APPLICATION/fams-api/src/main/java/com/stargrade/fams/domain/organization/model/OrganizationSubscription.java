package com.stargrade.fams.domain.organization.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.building.model.Building;
import com.stargrade.fams.domain.building.model.BuildingUnit;
import com.stargrade.fams.domain.subscription.model.Subscription;
import com.stargrade.fams.domain.unit.model.Unit;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"organization_id", "subscription_id"}))
@Entity
@Getter
@Setter
@NoArgsConstructor
public class OrganizationSubscription extends BaseEntity {
    @OneToOne
    private Organization organization;
    @ManyToOne
    private Subscription subscription;

    public OrganizationSubscription(Organization organization, Subscription subscription) {
        this.organization = organization;
        this.subscription = subscription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrganizationSubscription organizationSubscription = (OrganizationSubscription) o;
        return getId().equals(organizationSubscription.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getOrganization().getOrganizationId(), getSubscription().getSubscriptionId());
    }
}
