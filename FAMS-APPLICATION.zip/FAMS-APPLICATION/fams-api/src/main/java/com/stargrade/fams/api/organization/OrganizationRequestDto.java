package com.stargrade.fams.api.organization;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;

@Data
public class OrganizationRequestDto implements Serializable {
    @NotEmpty(message = "Organization name is required")
    private String name;

    @NotNull(message = "Contact is required")
    private ContactDto contact;

    @NotNull(message = "Address is required")
    private AddressDto address;
}
