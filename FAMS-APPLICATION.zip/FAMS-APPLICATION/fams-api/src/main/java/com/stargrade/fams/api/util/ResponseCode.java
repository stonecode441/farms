package com.stargrade.fams.api.util;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ResponseCode {
    SUCCESS("00"), FAILURE("99"), PENDING("79");

    private final String code;

    ResponseCode(String code) {
        this.code = code;
    }

    @JsonValue
    public String getCode() {
        return code;
    }
}
