/**
 * Created By MisterJames
 */


package com.stargrade.fams.api.role;

import com.stargrade.fams.api.util.ApiResponse;
import com.stargrade.fams.domain.usermanagement.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("${app.route.prefix}/role")
@RestController
@RequiredArgsConstructor
public class RoleController {
    private final RoleService roleService;

    @Operation(summary = "Create a role")
    @PostMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).CREATE_ROLE)")
    public ResponseEntity<ApiResponse<RoleDto>> createRole(@Valid @RequestBody RoleRequestDto roleRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Role created successfully", roleService.createRole(roleRequest)));
    }

    @Operation(summary = "Update a role")
    @PutMapping("/{roleId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_ROLE)")
    public ResponseEntity<ApiResponse<RoleDto>> updateRole(@PathVariable String roleId, @Valid @RequestBody RoleRequestDto roleRequestDto) {
        return ResponseEntity.ok(new ApiResponse<>("Role updated successfully", roleService.editRole(roleId, roleRequestDto)));
    }

    @Operation(summary = "Deactivate a role")
    @PatchMapping("/deactivate/{roleId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_ROLE)")
    public ResponseEntity<ApiResponse<RoleDto>> deactivateRole(@PathVariable String roleId) {
        return ResponseEntity.ok((new ApiResponse<>("Role deactivated successfully", roleService.deactivateRole(roleId))));
    }

    @Operation(summary = "Activate a role")
    @PatchMapping("/activate/{roleId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).EDIT_ROLE)")
    public ResponseEntity<ApiResponse<RoleDto>> activateRole(@PathVariable String roleId) {
        return ResponseEntity.ok((new ApiResponse<>("Role activated successfully", roleService.activateRole(roleId))));
    }

    @Operation(summary = "View a role")
    @GetMapping("/{roleId}")
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_ROLE)")
    public ResponseEntity<ApiResponse<RoleDto>> viewRole(@PathVariable String roleId) {
        return ResponseEntity.ok(new ApiResponse<>("Role retrieved successfully", roleService.getRole(roleId)));
    }

    @Operation(summary = "View a list of roles")
    @GetMapping
    @PreAuthorize("hasAuthority(T(com.stargrade.fams.domain.usermanagement.model.MethodAccessPermission).VIEW_ROLE)")
    public ResponseEntity<ApiResponse<List<RoleDto>>> viewRoles() {
        return ResponseEntity.ok(new ApiResponse<>("Roles retrieved successfully", roleService.getAllRoles()));
    }
}
