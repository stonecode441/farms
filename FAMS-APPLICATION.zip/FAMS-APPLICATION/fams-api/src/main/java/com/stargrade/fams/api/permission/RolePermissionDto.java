package com.stargrade.fams.api.permission;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class RolePermissionDto {
    private String roleName;
    private List<PermissionDto> rolePermissions;
}
