package com.stargrade.fams.domain.building.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.unit.model.Unit;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"building_id", "unit_id"}))
@Entity
@Getter
@Setter
@NoArgsConstructor
public class BuildingUnit extends BaseEntity {
    @ManyToOne
    private Building building;
    @ManyToOne
    private Unit unit;

    public BuildingUnit(Building building, Unit unit) {
        this.building = building;
        this.unit = unit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BuildingUnit buildingUnit = (BuildingUnit) o;
        return getId().equals(buildingUnit.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUnit().getUnitId(), getBuilding().getBuildingId());
    }
}
