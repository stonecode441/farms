package com.stargrade.fams.domain.support.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class SupportThread extends BaseEntity {
    @Column(unique = true, nullable = false, updatable = false)
    private String threadId;
    @ManyToOne
    private Support support;
    private String message;
    private Date messageDate;
    private String reply;
    private Date replyDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupportThread supportThread = (SupportThread) o;
        return getId().equals(supportThread.getId()) &&
                getThreadId().equals(supportThread.getThreadId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getThreadId(), getSupport().getTicketId());
    }
}
