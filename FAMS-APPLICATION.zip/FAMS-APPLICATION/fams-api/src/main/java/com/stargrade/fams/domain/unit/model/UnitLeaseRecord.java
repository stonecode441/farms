package com.stargrade.fams.domain.unit.model;

import com.stargrade.fams.domain.base.model.BaseEntity;
import com.stargrade.fams.domain.usermanagement.model.User;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Objects;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class UnitLeaseRecord extends BaseEntity {
    private LocalDate startDate;
    private LocalDate endDate;
    @ManyToOne
    private Unit unit;
    @ManyToOne
    private User tenant;

    public UnitLeaseRecord(LocalDate startDate, LocalDate endDate, Unit unit, User tenant) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.unit = unit;
        this.tenant = tenant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UnitLeaseRecord unitLeaseRecord = (UnitLeaseRecord) o;
        return getId().equals(unitLeaseRecord.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUnit().getUnitId(), getTenant().getUserId());
    }
}
