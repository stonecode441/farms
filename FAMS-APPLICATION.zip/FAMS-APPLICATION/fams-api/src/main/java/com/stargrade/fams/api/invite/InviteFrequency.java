package com.stargrade.fams.api.invite;

import com.fasterxml.jackson.annotation.JsonValue;

public enum InviteFrequency {
    ONCE("OC"),DAILY("DL"), WEEKLY("WK"), MONTHLY("MT");

    private final String type;
    InviteFrequency( String type){ this.type = type;}
    @JsonValue
    public String getType(){ return type;}

    }
