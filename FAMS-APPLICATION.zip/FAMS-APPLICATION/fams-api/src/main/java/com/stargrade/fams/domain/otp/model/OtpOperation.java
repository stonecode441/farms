package com.stargrade.fams.domain.otp.model;

public enum OtpOperation {
    GENERIC
}
