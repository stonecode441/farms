package com.stargrade.fams.domain.base.util;

import java.util.Random;
import java.util.UUID;

public class CodeGenerator {
    public static String generateUUID() {
        return UUID.randomUUID().toString();
    }

    public static String generateInviteCode() {
        var inviteCodePrefix = "FAMS";
        Random random = new Random();
        int randomNumber = random.nextInt(999999);
        System.out.println("Random number is: " + randomNumber);
        var codeAsString = String.format("%06d", randomNumber);
        return String.format("%s-%s", inviteCodePrefix, codeAsString);
    }

    public static String generateCode(int numberOfDigits) {
        var numberSeries = "0123456789";
        StringBuilder sb = new StringBuilder(numberOfDigits);
        for (int i = 0; i < numberOfDigits; i++) {
            int index = (int) (numberSeries.length() * Math.random());
            sb.append(numberSeries.charAt(index));
        }
        return sb.toString();
    }
}
